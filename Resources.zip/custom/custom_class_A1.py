#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ************************************************************************
# * Software:  TBM Pre-process                                           *
# * Version:  1.0.7                                                      *
# * Date:  2024-06-24 22:27:58                                           *
# * Last  update: 2024-03-08 20:00:00                                    *
# * License:  LGPL v1.0                                                  *
# * Maintain  address:  https://pan.baidu.com/s/1WIr67y1pNQCgEyUnuj004w  *
# * Maintain  code:  STBM                                                *
# * Email: jgliu1001@163.com                                             *
# ************************************************************************

from pandas import Series, DataFrame


def function(cycle: DataFrame) -> str:
    """
    判断数据类型是不是__A1_premature__ (循环段掘进长度过短 L<0.3m)
    :param cycle: 循环段数据（DataFrame）
    :return: 异常类型（'Normal'/'A'）
    """
    print('custom-class-A1')
    return 'Normal'
