#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ************************************************************************
# * Software:  TBM Pre-process                                           *
# * Version:  1.0.7                                                      *
# * Date:  2024-06-24 22:27:58                                           *
# * Last  update: 2024-03-08 20:00:00                                    *
# * License:  LGPL v1.0                                                  *
# * Maintain  address:  https://pan.baidu.com/s/1WIr67y1pNQCgEyUnuj004w  *
# * Maintain  code:  STBM                                                *
# * Email: jgliu1001@163.com                                             *
# ************************************************************************

from numpy import ndarray


def function(data: dict) -> ndarray:
    """
    巴特沃斯滤波器
    :param data: 循环段数据（DataFrame）
    :return: 滤波后的循环段数据（DataFrame）
    """
    print('custom-filteer')
    return None
