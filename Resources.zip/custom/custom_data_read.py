#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ************************************************************************
# * Software:  TBM Pre-process                                           *
# * Version:  1.0.6                                                      *
# * Date:  2024-02-18 18:52:42                                           *
# * Last  update: 2023-11-08 20:00:00                                    *
# * License:  LGPL v1.0                                                  *
# * Maintain  address:  https://pan.baidu.com/s/1WIr67y1pNQCgEyUnuj004w  *
# * Maintain  code:  STBM                                                *
# * Email: jgliu1001@163.com                                             *
# ************************************************************************

import pandas as pd
from pandas import Series, DataFrame
import zipfile


def function(file_path: str) -> DataFrame:  # 规定file_path为字符型数据，返回值为（DataFrame）类型数组
    """
    调用默认文件读取模块（仅可读取csv数据类型）
    :param file_path: 文件路径
    :return: 读取的数据集（DataFrame）
    """
    with zipfile.ZipFile(file_path) as thezip:
        with thezip.open(thezip.namelist()[0], mode='r') as thefile:
            data = pd.read_csv(thefile, sep='\t', index_col=0)  # 设置列名和 默认以多个空格来识别数据
            user_index = list(data.index.values)  # 行标签
            user_col = list(data)  # 列标签
            data.insert(0, '1', user_index)
            data.drop(user_col[-1], axis=1, inplace=True)
            data.columns = user_col
            data = data.reset_index(drop=True)  # 重建提取数据的行索引
            return data
