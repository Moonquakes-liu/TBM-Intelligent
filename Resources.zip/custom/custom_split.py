#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ************************************************************************
# * Software:  TBM Pre-process                                           *
# * Version:  1.0.7                                                      *
# * Date:  2024-06-25 14:25:17                                           *
# * Last  update: 2024-03-08 20:00:00                                    *
# * License:  LGPL v1.0                                                  *
# * Maintain  address:  https://pan.baidu.com/s/1WIr67y1pNQCgEyUnuj004w  *
# * Maintain  code:  STBM                                                *
# * Email: jgliu1001@163.com                                             *
# ************************************************************************


def function(data: dict) -> dict:
    """自定义获取空推、上升、稳定、下降的关键点模块，若定义了相关功能，则优先运行此功能，若未定义相关功能，则运行默认模块
    :param data: {'循环段'：循环段名称（str）, 'data'：循环段数据（DataFrame）}
    :return: {'上升段起点': 上升段起点位置索引, '稳定段起点': 稳定段起点位置索引, '稳定段终点': 稳定段终点位置索引}
    """
    print('custom-split')
    return {'上升段起点': 0, '稳定段起点': 0, '稳定段终点': 0}
