#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ************************************************************************
# * Software:  TBM Pre-process                                           *
# * Version:  1.0.6                                                      *
# * Date:  2024-02-18 18:38:04                                           *
# * Last  update: 2023-11-08 20:00:00                                    *
# * License:  LGPL v1.0                                                  *
# * Maintain  address:  https://pan.baidu.com/s/1WIr67y1pNQCgEyUnuj004w  *
# * Maintain  code:  STBM                                                *
# * Email: jgliu1001@163.com                                             *
# ************************************************************************

from pandas import Series, DataFrame


def function(cycle: DataFrame) -> DataFrame:
    """判断数据类型是不是__B1_markAndModify__ (循环段速度值超限 V>120mm/min)
    :param cycle: 循环段数据（DataFrame）
    :return: 修正后循环段数据（DataFrame）
    """
    print('custom-clean-B1')
    return DataFrame()
