#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ************************************************************************
# * Software:  Check  for  Python                                        *
# * Version:  1.0.6                                                      *
# * Date:  2023-11-08 20:00:00                                           *
# * Last  update: 2023-03-05 20:00:00                                    *
# * License:  LGPL v1.0                                                  *
# * Maintain  address:  https://pan.baidu.com/s/1WIr67y1pNQCgEyUnuj004w  *
# * Maintain  code:  STBM                                                *
# ************************************************************************

import traceback


# noinspection PyBroadException
try:
    import Windows
except Exception as e:
    print('自检失败，错误信息如下：\n')
    print(traceback.format_exc())
    print('点击"确定"退出程序！')
