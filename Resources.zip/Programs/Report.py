#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ************************************************************************
# * Software:  TBM Pre-process                                           *
# * Version:  1.0.6                                                      *
# * Date:  2024-02-18 18:38:04                                           *
# * Last  update: 2023-11-08 20:00:00                                    *
# * License:  LGPL v1.0                                                  *
# * Maintain  address:  https://pan.baidu.com/s/1WIr67y1pNQCgEyUnuj004w  *
# * Maintain  code:  STBM                                                *
# * Email: jgliu1001@163.com                                             *
# ************************************************************************

import math
import runpy
import traceback
import copy
import datetime
import time
import os
import dill
import sys
import shutil
import numpy as np
import pandas as pd
import psutil
import warnings
import PyPDF2
from io import BytesIO
from functools import reduce
from PyPDF2 import PdfFileReader, PdfFileMerger, PdfMerger, PdfReader
from numpy import ndarray
from pandas import Series, DataFrame
from matplotlib import pyplot as plt, pyplot
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen.canvas import Canvas
from reportlab.platypus import Table
from reportlab.lib.utils import ImageReader


class TBM_REPORT(object):
    """
    参数绘图模块，完成对循环段数据生成PDF的功能
    ****必选参数：原始数据存放路径（input_path），若不传入输入路径，程序则抛出异常并终止运行;
                生成数据保存路径（out_path），若不传入输出路径，程序则抛出异常并终止运行;
                索引文件保存路径（index_path），若不传入输出路径，程序则抛出异常并终止运行;
                关键参数名称（par_name），若不传入参数，程序则抛出异常并终止运行;
    ****可选参数：添加封面（cover），可选选项为（True/False），默认为开启状态;
                添加目录（content），可选选项为（True/False），默认为开启状态;
                添加页眉（header），可选选项为（True/False），默认为开启状态;
                添加页脚（footer），可选选项为（True/False），默认为开启状态;
                添加水印（watermark），可选选项为（True/False），默认为开启状态;
                水印名称（watermark_info）;
                使用外部图片资源（pic_outer），可选选项为（True/False），默认为关闭状态;
                外部图片存放路径（input_pic）;
                程序调试/修复选项（debug），默认为关闭状态;
                直接运行程序（Run）， 默认为开启状态;
    """
    ROOT_DIRECTORY = os.path.dirname(os.path.abspath(__file__))
    if os.path.exists(os.path.join(os.path.dirname(ROOT_DIRECTORY), 'fonts', 'STSONG.TTF')):  # 判断字体文件是否存在
        pdfmetrics.registerFont(TTFont('SimSun', os.path.join(os.path.dirname(ROOT_DIRECTORY),
                                                              'fonts', 'STSONG.TTF')))  # 读取所需要的字体文件
    else:
        print('->\033[0;31mFont file(STSONG.TTF) not found!!!\033[0m')
        sys.exit()  # 抛出异常并终止程序
    plt.rcParams['font.sans-serif'] = ['SimHei']  # 设置字体
    plt.rcParams['axes.unicode_minus'] = False  # 坐标轴的负号正常显示
    plt.rcParams.update({'font.size': 17})  # 设置字体大小
    warnings.filterwarnings("ignore")  # 忽略警告信息
    ROCK_GRADE = {1: 'Ⅰ', 2: 'Ⅱ', 3: 'Ⅲ', 4: 'Ⅳ', 5: 'Ⅴ', 6: 'Ⅵ'}  # 定义围岩等级和与之对应的字符表达（字典类型）
    PARAMETERS = ['桩号', '日期', '推进位移', '刀盘转速', '推进速度', '刀盘扭矩',
                  '总推力', '刀盘贯入度', '刀盘转速设定值', '推进速度设定值']  # 默认参数示例
    CUSTOM_FUNCTIONS = {'plot': None}
    RAW_INDEX = pd.DataFrame()  # 保存原始索引数据

    def __init__(self, input_path=None, out_path=None, index_path=None, parameter=None,
                 input_pic=None, cover=False, content=True, header=True, footer=True,
                 watermark=False, pic_outer=False, watermark_info=None, custom_functions=None,
                 debug=False, Run=False, loading=None):
        """初始化必要参量"""
        self.input = input_path  # 初始化输入路径
        self.out = out_path  # 初始化输出路径
        self.index = index_path  # 初始化索引文件路径
        self.parm = parameter  # 参数列（参数名称）
        """初始化可选参量"""
        self.switch_cover = cover  # 初始化封面开关
        self.switch_content = content  # 初始化目录开关
        self.switch_footer = footer  # 初始化页脚开关
        self.switch_header = header  # 初始化页眉开关
        self.switch_watermark = watermark  # 初始化水印开关
        self.watermark_context = watermark_info  # 水印名称
        self.pic_outer = pic_outer  # 使用内部绘图模块添加图片资源
        self.input_pic = input_pic  # 初始化输入路径
        self.custom_functions = self.CUSTOM_FUNCTIONS if custom_functions is None else custom_functions  # 数据清理功能
        self.debug = debug  # 调试/修复程序
        self.loading = loading  # 进度条
        """初始化程序内部参量"""
        self.class_name = self.__class__.__name__  # 获取当前模块名称
        self.size_font = 8  # 页面字体大小为8
        self.type_font = 'SimSun'  # 页面字体类型
        self.page = 1  # 用于存储当前页
        self.content_value = {}  # 用于存储目录信息
        self.cover_path = os.path.join(self.ROOT_DIRECTORY, 'images', 'cover.png')  # 初始化封面图片路径
        self.fig, self.ax_left, self.ax_right = None, None, None
        self.__default_plot__(None, None, initialize=True)
        self.local_time = [time.time(), time.time()]  # 记录当前时间
        self.Time_val = []  # 初始化程序运行花费时间
        self.show_parm = True  # 将输入参数大音出来，便于进行核对
        self.debug_number = 1  # Debug模式下页面编号
        None if not Run else self.main()  # 运行主程序

    def __create_report_Dir__(self) -> None:  # 规定返回值无类型限定/无返回值
        """如果是第一次生成，需要创建相关文件夹，如果文件夹存在，则清空"""
        if not os.path.exists(self.out):
            os.mkdir(self.out)  # 创建相关文件夹
        else:
            shutil.rmtree(self.out)  # 清空文件夹
            os.mkdir(self.out)  # 创建相关文件夹

    def __load_library__(self) -> None:
        """
        加载程序必备的动态链接库
        :return: None
        """
        try:
            lib_path = os.path.join(os.path.dirname(self.ROOT_DIRECTORY), 'Lib', 'Hashlib.lib')
            with open(lib_path, 'rb') as f:
                dill.load(f).run()  # 导入动态链接库文件
        except Exception as e:
            info = f'Error in x00901,\n' \
                   f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                   f'{e},\n' \
                   f'Failed to load the dynamic link library!!!'
            if self.loading is not None:
                self.loading.show_info(key=info, type='error')
            else:
                print(f'-> {self.class_name}\033[0;31m{info}\033[0m')
            sys.exit()

    def __check_parm__(self) -> None:  # 规定返回值无类型限定/无返回值
        """检查传入参数是否正常"""
        info = None
        try:
            if not self.input:  # 检查必要参数
                info = f'Error in x00902,\n' \
                       f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                       f'The input folder is not defined, Please check!!!'
            elif not self.out:  # 检查必要参数
                info = f'Error in x00903,\n' \
                       f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                       f'The output folder is not defined, Please check!!!'
            elif not self.index:  # 检查必要参数
                info = f'Error in x00904,\n' \
                       f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                       f'The index path is not defined, Please check!!!'
            elif not self.parm or self.parm == ['']:  # 检查必要参数
                info = f'Error in x00905,\n' \
                       f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                       f'The parameters is not defined, Please check!!!'
            elif len(self.parm) < len(self.PARAMETERS):  # 检查必要参数
                info = f'Error in x00906,\n' \
                       f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                       f'The number of parameters is insufficient, Please check!!!'
            elif not os.path.exists(self.input):  # 检查必要参数
                info = f'Error in x00907,\n' \
                       f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                       f'The input folder path does not exist, Please check!!!'
            elif len(os.listdir(self.input)) <= 0:
                info = f'Error in x00908,\n' \
                       f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                       f'No file is found in <{self.input}>, Please check!!!'
        except Exception as e:
            info = f'Error in x00900,\n' \
                   f'Module({self.class_name}) initialization failed, Detail error are as follows: \n{e}!!!'
        finally:
            if info is not None:
                if self.loading is not None:
                    self.loading.show_info(key=info, type='error')
                else:
                    print(f'-> {self.class_name} \033[0;31m{info}\033[0m')
                sys.exit()  # 抛出异常并终止程序

    def __check_index__(self, all_location: list) -> None:
        """
        判断数据中是否存在重复列名，若存在重复列名，则需要输入位置索引
        :param all_location: 原始数据的所有标签名称
        :return: 无
        """
        info = None
        try:
            if reduce(lambda x, y: x * y, [type(name) == str for name in self.parm]):  # 判断是否为标签类型索引(名称)
                all_location = [name.split('.')[0] for name in all_location]  # 获取原始数据的标签名称
                mark = max([all_location.count(now_name) for now_name in self.parm])  # 检查标签名称中是否重复
                index = [all_location.index(now_name) for now_name in self.parm]
                if mark > 1:  # 标签名称不重复
                    info = f'Error in x00909,\n' \
                           f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                           f'Label index(loc) is not available, Please enter location index(iloc),\n' \
                           f'Location index(iloc) may be {index}, You can verify that!!!'
                    if self.loading is not None:
                        self.loading.show_info(key=info, type='error')
                    else:
                        print(f'-> {self.class_name}\033[0;31m{index}\033[0m')
                    sys.exit()
            if self.show_parm:  # 将输入参数打印出来，便于进行核对
                self.show_parm = False
                if self.loading is not None:
                    self.loading.show_info(key='-> %s 参数名称: %s' %
                                               (self.class_name, [all_location[i] for i in self.parm]), type='message')
                else:
                    print('-> %s \033[0;33m参数名称: %s \033[0m' %
                          (self.class_name, [all_location[i] for i in self.parm]))
        except Exception as e:
            info = f'Error in x00900,\n' \
                   f'Module({self.class_name}) initialization failed, Detail error are as follows: \n{e}!!!'
        finally:
            if info is not None:
                if self.loading is not None:
                    self.loading.show_info(key=info, type='warning')
                else:
                    print(f'-> {self.class_name} \033[0;31m{info}\033[0m')
                sys.exit()  # 抛出异常并终止程序

    def __prepare_custom_function__(self, option='add') -> None:
        """准备自定义函数"""
        custom_function_temp = os.path.join(self.ROOT_DIRECTORY, 'custom')
        if option == 'add':
            info = None
            try:
                for key in self.custom_functions.keys():
                    if self.custom_functions[key] is not None:
                        if not os.path.exists(custom_function_temp):
                            os.mkdir(custom_function_temp)  # 创建相关文件夹
                        shutil.copyfile(str(self.custom_functions[key]),
                                        os.path.join(custom_function_temp, key + '.py'))
            except Exception as e:
                for key in self.custom_functions.keys():
                    self.custom_functions[key] = None
                info = f'Warning in x00910,\n' \
                       f'Description failed to initialize the custom module, Detail error are as follows: \n{e}!!!'
            finally:
                if info is not None:
                    if self.loading is not None:
                        self.loading.show_info(key=info, type='error')
                    else:
                        print(f'-> {self.class_name} \033[0;33m{info}\033[0m')
        elif option == 'del':
            if os.path.exists(custom_function_temp):
                shutil.rmtree(custom_function_temp)  # 清空文件夹

    def __add_footer_info__(self, Obj) -> None:  # 规定返回值无类型限定/无返回值:
        """
        添加页脚信息
        :param Obj: Canvas容器
        :return: 无
        """
        sheet = Table([['Page%d' % self.page]], colWidths=[15 * mm], rowHeights=[5 * mm],  # 绘制页码框
                      style={("FONT", (0, 0), (-1, -1), self.type_font, self.size_font),  # 设置页码字体类型和大小
                             ('ALIGN', (0, 0), (-1, -1), 'CENTER'), ('VALIGN', (0, 0), (-1, -1), 'MIDDLE')})  # 页码居中
        sheet.wrapOn(Obj, 0, 0)  # 将页码框添加到Canvas中
        sheet.drawOn(Obj, 97.5 * mm, 12 * mm)  # 将页码框添加到Canvas中

    def __add_header_info__(self, Obj) -> None:
        """
        添加页眉信息
        :param Obj: Canvas容器
        :return: 无
        """
        Obj.setStrokeColor(colors.royalblue)  # 指定边缘颜色
        Obj.setFillColor(colors.royalblue)  # 指定填充颜色
        Obj.line(20 * mm, 277 * mm, 190 * mm, 277 * mm)  # 绘制一条线
        Obj.rect(25 * mm, 280 * mm, 7 * mm, 7 * mm, fill=1)  # 绘制一个矩形
        Obj.drawString(35 * mm, 282 * mm, 'REPORT')  # 添加页眉信息
        current_date = datetime.datetime.now().strftime('%Y.%m')
        sheet = Table([['%s  <数据预处理>  |  %d' % (current_date, self.page)]], colWidths=[50 * mm], rowHeights=[4 * mm],
                      style={("FONT", (0, 0), (-1, -1), self.type_font, self.size_font + 1),  # 设置字体类型和大小
                             ("TEXTCOLOR", (0, 0), (0, 0), colors.royalblue),  # 设置字体颜色
                             ('ALIGN', (0, 0), (-1, -1), 'RIGHT'), ('VALIGN', (0, 0), (-1, -1), 'MIDDLE')})  # 字体右对齐
        sheet.wrapOn(Obj, 0, 0)  # 将页码框添加到Canvas中
        sheet.drawOn(Obj, 140 * mm, 281 * mm)  # 将页码框添加到Canvas中

    def __add_watermark_info__(self, Obj) -> None:
        """
        添加水印信息
        :param Obj: Canvas容器
        :return: 无
        """
        Obj.setFont(self.type_font, self.size_font + 17)  # 设置字体类型及大小
        Obj.rotate(40)  # 旋转45度，坐标系被旋转
        Obj.setFillColorRGB(0, 0, 0.6)  # 指定填充颜色
        Obj.setFillAlpha(0.2)  # 设置透明度，0为透明，1为不透明
        Obj.drawString(55 * mm, 4 * mm, self.watermark_context)  # 添加水印名称1
        Obj.drawString(185 * mm, 4 * mm, self.watermark_context)  # 添加水印名称2
        Obj.drawString(123 * mm, 85 * mm, self.watermark_context)  # 添加水印名称3
        Obj.drawString(250 * mm, 85 * mm, self.watermark_context)  # 添加水印名称4

    def __add_cover_info__(self, Obj) -> None:
        """
        添加封面信息
        :param Obj: Canvas容器
        :return: 无
        """
        Obj.setStrokeColor(colors.skyblue)  # 指定边缘颜色
        Obj.setFillColor(colors.skyblue)  # 指定填充颜色
        Obj.roundRect(64 * mm, 53 * mm, 80 * mm, 10 * mm, fill=1, radius=10)  # 绘制一个矩形
        current_year = datetime.datetime.now().strftime('%Y')
        sheet = Table(data=[['%s' % current_year], ['TBM数据预处理报告书'], ['TBM DATA PREPROCESSING REPORT'], ['**机构信息**']],
                      colWidths=[150 * mm], rowHeights=[17 * mm, 17 * mm, 17 * mm, 17 * mm],  # 创建表格并写入信息
                      style={("FONT", (0, 0), (0, 0), self.type_font, 37),  # 字体类型
                             ("FONT", (0, 1), (0, 1), self.type_font, 30),  # 字体类型
                             ("FONT", (0, 2), (0, 2), self.type_font, 20),  # 字体类型
                             ("FONT", (0, 3), (0, 3), self.type_font, 15),  # 字体类型
                             ("TEXTCOLOR", (0, 0), (0, 0), colors.skyblue),  # 字体颜色为黑色
                             ("TEXTCOLOR", (0, 1), (0, 1), colors.black),  # 字体颜色为黑色
                             ("TEXTCOLOR", (0, 2), (0, 2), colors.gray),  # 字体颜色为黑色
                             ("TEXTCOLOR", (0, 3), (0, 3), colors.black),  # 字体颜色为黑色
                             ('ALIGN', (0, 0), (-1, -1), 'CENTER'), ('VALIGN', (0, 0), (-1, -1), 'MIDDLE')})  # 左右上下居中
        sheet.wrapOn(Obj, 0, 0)  # 将页码框添加到Canvas中
        sheet.drawOn(Obj, 30 * mm, 50 * mm)  # 将页码框添加到Canvas中
        if os.path.exists(self.cover_path):  # 若路径有效，则添加封面图片
            Obj.drawImage(image=self.cover_path, x=20 * mm, y=120 * mm, width=170 * mm, height=120 * mm, anchor='c')

    def __add_content_info__(self, Obj, value: dict, loc: int) -> None:  # 规定返回值无类型限定/无返回值
        """
        添加目录信息
        :param Obj:  Canvas容器
        :param value: 所要添加的单条目录信息，示例{'beg': '', 'end': '', 'stake': '', 'page': ''}
        :param loc: 所要添加的单条目录的放置位置（范围 1 ~ 50）
        :return: 无
        """
        table_w = [[136 * mm], [16 * mm, 3 * mm, 10 * mm, 95 * mm, 12 * mm]]  # 表格列宽信息
        table_h = [[8 * mm], [5.1 * mm]]  # 表格行高信息
        table_y = [280 * mm] + [(274.9 - 5.1 * i) * mm for i in range(50)]  # 表格位置信息
        inf = [['CATALOGUE'], ['%s-%s' % (value['beg'], value['end']), '',
                               value['stake'], '.' * 150, 'Page%s' % value['page']]]  # 表格内容信息
        if loc == 1:
            sheet = Table([inf[0]], colWidths=table_w[0], rowHeights=table_h[0],
                          style={("FONT", (0, 0), (-1, -1), self.type_font, self.size_font),  # 目录正文字体
                                 ("TEXTCOLOR", (0, 0), (-1, -1), colors.black),  # 字体颜色
                                 ('ALIGN', (0, 0), (-1, -1), 'CENTER'), ('VALIGN', (0, 0), (-1, -1), 'MIDDLE')})  # 内容居中
            sheet.wrapOn(Obj, 0, 0)  # 将表格添加到Canvas中
            sheet.drawOn(Obj, 36 * mm, table_y[0])  # 将表格添加到Canvas中
        sheet = Table([inf[1]], colWidths=table_w[1], rowHeights=table_h[1],
                      style={("FONT", (0, 0), (-1, -1), self.type_font, self.size_font),  # 目录正文字体
                             ("TEXTCOLOR", (0, 0), (-1, -1), colors.black),  # 字体颜色
                             ('ALIGN', (0, 0), (-1, -1), 'CENTER'), ('VALIGN', (0, 0), (-1, -1), 'MIDDLE')})  # 内容居中
        sheet.wrapOn(Obj, 0, 0)  # 将表格添加到Canvas中
        sheet.drawOn(Obj, 36 * mm, table_y[loc])  # 将表格添加到Canvas中

    def __add_text_info__(self, Obj, value: list, loc: int) -> None:  # 规定返回值无类型限定/无返回值
        """
        添加正文信息
        :param Obj:  Canvas容器
        :param value: 所要添加的单条正文信息
        :param loc: 所要添加的单条正文的放置位置（范围 1 ~ 6）
        :return: 无
        """
        table_x = [20 * mm, 105 * mm, 20 * mm, 105 * mm, 20 * mm, 105 * mm]  # 表格x位置信息
        table_y = [189 * mm, 189 * mm, 105 * mm, 105 * mm, 21 * mm, 21 * mm]  # 表格y位置信息
        value.append(['' for _ in range(6)])  #
        sheet = Table(data=value,
                      colWidths=[13 * mm, 9 * mm, 12 * mm, 13 * mm, 13 * mm, 25 * mm],  # 表格列宽信息
                      rowHeights=[8 * mm, 8 * mm, 68 * mm],  # 表格行高信息
                      style={("FONT", (0, 0), (-1, -1), self.type_font, self.size_font),  # 字体类型
                             ("TEXTCOLOR", (0, 0), (-1, -1), colors.black),  # 字体颜色为黑色
                             ('SPAN', (0, 2), (5, 2)),  # 合并单元格
                             ('ALIGN', (0, 0), (-1, -1), 'CENTER'), ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),  # 左右上下居中
                             ('INNERGRID', (0, 0), (-1, -1), 0.7, colors.black),  # 显示内部框线
                             ('BOX', (0, 0), (-1, -1), 0.7, colors.black)})  # 显示外部框线
        sheet.wrapOn(Obj, 0, 0)  # 将表格添加到Canvas中
        sheet.drawOn(Obj, table_x[loc], table_y[loc])  # 将表格添加到Canvas中

    def __add_pic_info__(self, Obj, name: str, value: 'list | DataFrame', loc: int) -> None:  # 规定返回值无类型限定/无返回值
        """
        添加图片信息
        :param Obj: Canvas容器
        :param name: 循环段名称
        :param value: 循环段数据/循环段对于的图片路径
        :param loc: 所要添加的图片的放置位置（范围 1 ~ 6）
        :return: 无
        """
        pic_x = [21 * mm, 107 * mm, 21 * mm, 107 * mm, 21 * mm, 107 * mm]  # 图片x位置信息
        pic_y = [190 * mm, 190 * mm, 106 * mm, 106 * mm, 22 * mm, 22 * mm]  # 图片y位置信息
        if isinstance(value, pd.DataFrame):
            img = self.__draw_pic__(name, value)  # 使用内置绘图模块进行绘图
            Obj.drawImage(image=img, x=pic_x[loc], y=pic_y[loc], width=82 * mm, height=66 * mm, anchor='c')
        elif isinstance(value, str):
            img = value  # 添加外部图片资源
            if os.path.exists(img):  # 若路径有效，则添加图片
                Obj.drawImage(image=img, x=pic_x[loc], y=pic_y[loc], width=82 * mm, height=66 * mm, anchor='c')

    def __draw_Canvas__(self, pdf_text, pdf_content, data: DataFrame, cycle: int,
                        name: str, All: list, end: bool) -> None:
        """
        调用各模块
        :param pdf_text: 存放正文pdf的Canvas
        :param pdf_content: 存放目录pdf的Canvas
        :param data: 循环段数据
        :param cycle: 循环段编号
        :param name: 循环段名称
        :param All: 所有循环段名称组成的列表
        :param end: 程序结束标志
        :return: 无
        """
        data_np = data.iloc[:, self.parm[:3]].values  # 提取与掘进状态判定有关的参数，并对其类型进行转换，以提高程序执行速度
        text_value = [['Number', ('%00005d' % (cycle + 1)),  # 获取循环段编号(Num)
                       'Start No', '%sm' % round(data_np[0][0], 1),  # 获取桩号记录
                       'Start Time', data_np[0][1]],  # 获取循环段开始时间
                      ['Rock mass', '---',  # 获取围岩等级(Rock_Mass)
                       'Length', '%4.2fm' % round((data_np[-1][2] - data_np[0][2]) / 1000, 2),  # 掘进长度
                       'End Time', data_np[-1][1]]]  # 获取结束时间
        self.__add_text_info__(pdf_text, text_value, (cycle + 1) % 6 - 1)  # 添加正文信息
        pic_val = os.path.join(self.input_pic, name[:-3] + 'png') if self.pic_outer else data  # 添加图片变量信息（数据/路径）
        self.__add_pic_info__(pdf_text, name, pic_val, (cycle + 1) % 6 - 1)  # 添加图片信息
        if (cycle + 1) % 6 == 1:
            self.local_time[0] = time.time()  # 记录程序执行开始时间
            self.content_value.update({'beg': text_value[0][1], 'stake': text_value[0][3][:-1], 'page': self.page})
        if (cycle + 1) % 6 == 0 or end:
            inf = ['第%d页' % self.page, '\n图片来源:', '外部图片' if self.pic_outer else '内部图片', '\n文件列表:'] + \
                  ['\n' + name for name in All[6 * (self.page - 1): ((6 * self.page) if not end else len(All))]]
            self.__detail__(name='Create PDF', debug=self.debug, end=end, key=inf)  # 展示细节
            self.content_value.update({'end': text_value[0][1]})  # 目录信息添加
            if self.switch_content:
                self.__add_content_info__(pdf_content, self.content_value, self.page % 50)  # 添加目录信息
            None if not self.switch_header else self.__add_header_info__(pdf_text)  # 添加页眉信息
            None if not self.switch_footer else self.__add_footer_info__(pdf_text)  # 添加页脚信息
            None if not self.switch_watermark else self.__add_watermark_info__(pdf_text)  # 添加水印信息
            pdf_text.showPage()  # 正文新增一页
            self.local_time[1] = time.time()  # 记录程序执行结束时间
            if self.loading is not None:
                self.loading.update(key='detail-count', file='第%d页' % self.page)
            else:
                self.__show_info__(use_time=self.local_time[1] - self.local_time[0], file_num=self.page,
                                   file_sum=math.ceil(len(All) / 6))
            self.page += 1  # 页脚页码自增
        if (cycle + 1) % 300 == 0 or end:
            pdf_content.showPage()  # 目录新增一页

    def __draw_pic__(self, name: str, data: DataFrame) -> ImageReader:
        """
        内部绘图模块
        :param name: 循环段名称
        :param data: 循环段数据
        :return: 绘制好的图片
        """
        Mark = self.__get_index__({'循环段': name})
        Plt = self.__custom_plot__(data, Mark)  # 自定义参数绘图模块
        if Plt is None:
            Plt = self.__default_plot__(data, Mark)  # 默认参数绘图模块
        Image_data = BytesIO()  # 将绘制的画布临时保存至内存中
        Plt.savefig(Image_data, bbox_inches='tight', format='png')
        Image_data.seek(0)  # rewind the data
        return ImageReader(Image_data)

    def __get_index__(self, info: dict) -> dict:
        """
        获取索引文件记录
        :param info: 包含循环段名称的dict，其中至少含有{‘name’：‘’}
        :return: 所有的上升段稳定段变化点索引值
        """
        try:  # 尝试读取索引文件，若索引文件存在，则将['循环段', '上升段起点', '稳定段起点', '稳定段终点']保存至Index_value中
            if self.RAW_INDEX.empty:  # 索引文件行位置记录
                self.RAW_INDEX = pd.read_csv(self.index, index_col=0, encoding='gb2312')  # 读取索引文件
                INDEX_NAME = ['上升段起点', '稳定段起点', '稳定段终点']  # 生成索引文件中标签信息
                self.RAW_INDEX = self.RAW_INDEX.loc[:, INDEX_NAME]  # 将关键点保存至Index_value
            mark = {} if self.RAW_INDEX is None else {'上升段起点': self.RAW_INDEX['上升段起点'][int(info['循环段'][:5])],
                                                      '稳定段起点': self.RAW_INDEX['稳定段起点'][int(info['循环段'][:5])],
                                                      '稳定段终点': self.RAW_INDEX['稳定段终点'][int(info['循环段'][:5])]}
        except (FileNotFoundError, KeyError, IndexError, TypeError):  # 若索引文件存在，则令Index_value为空[]
            mark = {}
        return mark

    def __default_plot__(self, data: DataFrame, _key_: dict, initialize=False) -> pyplot:  # 规定_key_为字典类型（dict）
        """
        完成掘进参数的绘图
        :param data: 循环段数据（DataFrame）
        :param _key_: 内部段划分信息
        :return: 绘制好的图片
        """
        if initialize:  # 初始化画布
            x = [i for i in range(100)]  # 'Time'
            y = np.array([0 for _ in range(100)])  # '刀盘转速'
            self.fig, self.ax_left = plt.subplots(figsize=(8, 6), dpi=120)  # 设置画布大小（10cm x 8cm）及分辨率（dpi=120）
            self.ax_left.scatter(x, y, label="n", color='mediumblue', marker='+')
            self.ax_left.scatter(x, y, label="n_set", color='k', marker='_')
            self.ax_left.scatter(x, y, label="V/10", color='y', marker='.', s=100)
            self.ax_left.scatter(x, y, label="V_set/10", color='saddlebrown', marker='.', s=50)
            self.ax_left.legend(bbox_to_anchor=(0.36, 1.1), loc=9, borderaxespad=-1, ncol=2, columnspacing=2,
                                frameon=False, fontsize=16, markerscale=1.5)
            self.ax_left.set_ylabel("刀盘转速、推进速度及其设定值", fontsize=20, labelpad=10)
            self.ax_left.set_xlabel("时间/s", fontsize=20)
            self.ax_left.set_ylim(0, 12)
            self.ax_right = self.ax_left.twinx()
            self.ax_right.scatter(x, y, label="T", color='deeppink', marker='^', s=30)
            self.ax_right.scatter(x, y, label="F/3", color='c', marker='v', s=30)
            self.ax_right.legend(bbox_to_anchor=(0.77, 1.1), loc=9, borderaxespad=-1.1, ncol=1, columnspacing=2,
                                 frameon=False, fontsize=16, markerscale=1.5)
            self.ax_right.set_ylabel("刀盘推力、刀盘扭矩", fontsize=20, labelpad=10)
            self.ax_right.set_ylim(0, 5010)
        else:
            x_time = data.iloc[:, self.parm[1]].values
            timestamps = (np.array([datetime.datetime.strptime(time_str, '%Y-%m-%d %H:%M:%S') for time_str in x_time])
                          - datetime.datetime.strptime(x_time[0], '%Y-%m-%d %H:%M:%S'))
            x_timestamp = timestamps.astype('timedelta64[s]').astype(float)
            y_n = data.iloc[:, self.parm[3]]  # '刀盘转速'
            y_n_set = data.iloc[:, self.parm[8]]  # '刀盘转速设定'
            y_V = data.iloc[:, self.parm[4]]  # '推进速度'
            y_V_set = data.iloc[:, self.parm[9]]  # '推进速度设定'
            y_T = data.iloc[:, self.parm[5]]  # '刀盘总扭矩'
            y_F = data.iloc[:, self.parm[6]]  # '推进总推力'
            self.ax_left.set_xlim(xmin=-int(0.02 * len(x_timestamp)),
                                  xmax=x_timestamp[-1] + int(0.02 * len(x_timestamp)))
            for scatter in self.ax_left.collections:
                scatter.remove()
            for scatter in self.ax_right.collections:
                scatter.remove()
            for line in self.ax_left.lines:
                line.remove()
            self.ax_left.scatter(x_timestamp, y_n, label="n", color='mediumblue', marker='+')
            self.ax_left.scatter(x_timestamp, y_n_set, label="n_set", color='k', marker='_')
            self.ax_left.scatter(x_timestamp, y_V / 10, label="V/10", color='y', marker='.', s=100)
            self.ax_left.scatter(x_timestamp, y_V_set / 10, label="V_set/10", color='saddlebrown', marker='.', s=50)
            self.ax_right.scatter(x_timestamp, y_T, label="T", color='deeppink', marker='^', s=30)
            self.ax_right.scatter(x_timestamp, y_F / 3, label="F/3", color='c', marker='v', s=30)
            if _key_:  # 如果索引文件中空推段、上升段和稳定段的变化点存在，则在图中绘出
                for name, value in zip(_key_.keys(), _key_.values()):
                    if value != 'Unknown':
                        self.ax_left.axvline(x=int(value), c="r", ls="-.")
            return self.fig

    def __custom_plot__(self, data: DataFrame, _key_: dict) -> pyplot:  # 规定_key_为字典类型（dict）,返回值为绘制好的plt
        """自定义绘图模块，若定义了相关功能，则优先运行此功能，若未定义相关功能，则运行默认绘图模块"""
        if self.custom_functions['plot'] is not None:
            info = None
            try:
                from custom.plot import function
                return function(data, _key_)
            except Exception as e:
                info = f'Warning in x00911,\n' \
                       f'Custom module call failed, default module will be used, Detail error are as follows: \n{e}!!!'
            finally:
                if info is not None:
                    if self.loading is not None:
                        self.loading.show_info(key=info, type='warning')
                    else:
                        print(f'-> {self.class_name} \033[0;33m{info}\033[0m')

    def __MergePDF__(self, pdf_path: list) -> None:  # 规定返回值无类型限定/无返回值
        """
        合并目录和正文成为一个PDF
        :param pdf_path: 带合并的 pdf路径，以列表形式存放
        :return: 无
        """
        try:
            merger = PdfFileMerger()  # 调用PDF编辑的类
            for file in pdf_path:
                merger.append(PdfFileReader(file))  # 合并pdf文件
                os.remove(file)  # 删除合并后的pdf文件
            merger.write(os.path.join(self.out, 'TBM-Data.pdf'))  # 将合并后的pdf写入到新文件
            merger.close()  # 关闭文件
        except PyPDF2.errors.DeprecationError:
            merger = PdfMerger()
            for file in pdf_path:
                merger.append(PdfReader(file))  # 合并pdf文件
                os.remove(file)  # 删除合并后的pdf文件
            merger.write(os.path.join(self.out, 'TBM-Data.pdf'))  # 将合并后的pdf写入到新文件
            merger.close()  # 关闭文件

    def __show_info__(self, use_time: float, file_num: int, file_sum: int) -> None:
        """
        实时输出程序运行状况
        :param use_time: 处理每个循环段数据花费的时间
        :param file_num: 当前的循环段编号
        :param file_sum: 总的循环段数量
        :return: 无
        """
        if self.debug:  # 若为调试模式，则不向索引文件写入内容
            return None
        cpu_percent = psutil.cpu_percent()  # CPU占用
        mem_percent = psutil.Process(os.getpid()).memory_percent()  # 内存占用
        self.Time_val.append(use_time)  # 对每个时间差进行保存，用于计算平均时间
        mean_time = sum(self.Time_val) / len(self.Time_val)  # 计算平均时间
        sum_time = round(sum(self.Time_val) / 3600, 3)  # 计算程序执行的总时间
        remain_time = round((mean_time * (file_sum - file_num - 1)) / 3600, 3)  # 预计剩余时间计算
        print('\r   [第%d个 / 共%d个]  ' % (file_num + 1, file_sum),
              '[所用时间%ds / 平均时间%ds]  ' % (int(use_time), int(mean_time)),
              '[CPU占用: %5.2f%% / 内存占用: %5.2f%%]  ' % (cpu_percent, mem_percent),
              '[累积运行时间: %6.3f小时 / 预计剩余时间: %6.3f小时]' % (sum_time, remain_time), end='')
        if file_num >= file_sum:
            print('\r-> %s \033[0;32mCreate PDF completed, which took %6.3f hours\033[0m' % (self.class_name, sum_time))

    def __detail__(self, name=None, key=None, end=False, debug=False):
        """展示程序细节信息"""
        if debug:
            if self.debug_number == 1:
                print("\033[0;33m{:·^100}\033[0m".format(name))
            for num, information in enumerate(key):
                print('\033[0;33m%-9s\033[0m' % str(information), end='')
            print('')
            if end:
                print("\033[0;33m{:·^100}\033[0m".format(name))
            self.debug_number += 1

    def main(self) -> None:  # 规定返回值无类型限定/无返回值
        """读取数据，并将数据转化为可识别的类型"""
        # noinspection PyBroadException
        try:
            self.__load_library__()  # 加载必备的动态链接库
            self.__check_parm__()  # 检查参数是否正常
            self.__create_report_Dir__()  # 创建相关文件夹
            self.__prepare_custom_function__(option='add')  # 准备自定义函数
            pdf = {'cover': Canvas(filename=os.path.join(self.out, 'cover.pdf'), bottomup=1, pageCompression=1),  # 创建封面
                   'content': Canvas(filename=os.path.join(self.out, 'content.pdf'), bottomup=1, pageCompression=1),
                   'text': Canvas(filename=os.path.join(self.out, 'text.pdf'), bottomup=1, pageCompression=1)}  # 创建正文
            all_file = os.listdir(self.input)  # 获取循环段列表
            self.loading.update(key='detail-sum',
                                value=math.ceil(len(all_file) / 6)) if self.loading is not None else None
            self.loading.update(key='total-count', file='REPORT') if self.loading is not None else None
            all_file.sort(key=lambda x: int(x[:5]))  # 对读取的文件列表进行重新排序
            for num, file in enumerate(all_file):
                while self.loading is not None and self.loading.get_pause():
                    time.sleep(1)
                finish = False if num != len(all_file) - 1 else True  # 程序结束标志
                try:  # 尝试采用编码'gb2312'读取数据
                    data = pd.read_csv(os.path.join(self.input, file), encoding='gb2312')  # 读取循环段数据，编码'gb2312'
                except UnicodeDecodeError:  # 若采用编码'gb2312'读取数据失败，则尝试采用默认编码读取数据
                    data = pd.read_csv(os.path.join(self.input, file))  # 读取循环段数据，编码使用默认值
                self.__check_index__(list(data))  # 检查参数是否重复
                self.__draw_Canvas__(pdf['text'], pdf['content'], data, num, file, all_file, finish)
            None if not self.switch_cover else self.__add_cover_info__(pdf['cover'])  # 添加目录信息
            pdf['text'].save(), pdf['content'].save(), pdf['cover'].save()  # pdf保存
            self.__MergePDF__([os.path.join(self.out, 'cover.pdf'), os.path.join(self.out, 'content.pdf'),
                              os.path.join(self.out, 'text.pdf')])  # 合并目录和正文
        except Exception:
            if self.loading is not None:
                self.loading.show_info(key=traceback.format_exc(), type='error')
            else:
                print(f'-> {self.class_name} \033[0;31m{traceback.format_exc()}\033[0m')
        finally:
            self.__prepare_custom_function__(option='del')


if __name__ == "__main__":
    TBM_REPORT(input_path=r'D:\17339902814\OneDrive\桌面\test\merge',
               out_path=r'D:\17339902814\OneDrive\桌面\test\report',
               index_path=r'D:\17339902814\OneDrive\桌面\test\index.csv',
               parameter=[0, 1, 23, 5, 7, 2, 8, 3, 4, 6, 1],
               Run=True)
