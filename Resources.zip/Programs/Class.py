#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ************************************************************************
# * Software:  TBM Pre-process                                           *
# * Version:  1.0.6                                                      *
# * Date:  2024-02-18 18:38:04                                           *
# * Last  update: 2023-11-08 20:00:00                                    *
# * License:  LGPL v1.0                                                  *
# * Maintain  address:  https://pan.baidu.com/s/1WIr67y1pNQCgEyUnuj004w  *
# * Maintain  code:  STBM                                                *
# * Email: jgliu1001@163.com                                             *
# ************************************************************************

import copy
import runpy
import traceback
import datetime
import time
import os
import dill
import sys
import shutil
import numpy as np
import pandas as pd
import psutil
import scipy
from functools import reduce
from pandas import Series, DataFrame
from scipy import fft
from scipy.fftpack import fft


class TBM_CLASS(object):
    """
    异常分类配置模块，主要完成异常循环段识别和分类的工作
    ****必选参数：原始数据存放路径（input_path），若不传入输入路径，程序则抛出异常并终止运行;
                生成数据保存路径（out_path），若不传入输入路径，程序则抛出异常并终止运行;
                索引文件保存路径（index_path），若不传入输出路径，程序则抛出异常并终止运行;
                程序运行所需要的关键参数名称（par_name），若不传入参数，程序则会终止运行;
    ****可选参数：工程类型（project_type）， 有'引松'、'引额-361'、'引额-362'、'引绰-667'、'引绰-668'几种;
                最小掘进长度（L_min），默认300mm;
                推进速度最大值（V_max），引松取 120mm/min，额河取 200mm/min;
                推进速度设定值变化幅值（V_set_var），默认15;
                数据缺失率（missing_ratio），默认0.2;
                程序调试/修复选项（debug），默认为关闭状态;
                直接运行程序（Run）， 默认为开启状态;
    """
    ROOT_DIRECTORY = os.path.dirname(os.path.abspath(__file__))
    PROJECT_COEFFICIENT = {'引松': 1.0 / 40.731, '引额-361': 1.227, '引额-362': 1.354, '引绰-667': 1.763, '引绰-668': 2.356}
    DEFAULT_FUNCTIONS = {'A1': True, 'B1': True, 'B2': True, 'C1': True, 'C2': True, 'D1': True, 'E1': True}
    CUSTOM_FUNCTIONS = {'split': None, 'class_A1': None, 'class_B1': None, 'class_B2': None,
                        'class_C1': None, 'class_C2': None, 'class_D1': None, 'class_E1': None}
    RESULT = {'A1': '', 'B1': '', 'B2': '', 'C1': '', 'C2': '', 'D1': '', 'E1': '', 'Normal': ''}
    SUB_FOLDERS = {'A1': 'A1class-data', 'B1': 'B1class-data', 'B2': 'B2class-data',
                   'C1': 'C1class-data', 'C2': 'C2class-data', 'D1': 'D1class-data',
                   'E1': 'E1class-data', 'Unknown': 'Unknown-data', 'Normal': 'Norclass-data'}  # 默认子文件夹
    PARAMETERS = ['桩号', '日期', '推进位移', '刀盘转速', '推进速度', '刀盘扭矩',
                  '总推力', '刀盘贯入度', '刀盘转速设定值', '推进速度设定值']  # 默认参数示例
    RAW_INDEX = pd.DataFrame()  # 保存原始索引数据
    NEW_INDEX = pd.DataFrame()  # 保存新的索引数据

    def __init__(self, input_path=None, out_path=None, index_path=None, parameter=None,
                 project_type='引绰-668', L_min=0.3,  V_max=120, missing_ratio=0.2,
                 constant_time=5, functions=None, custom_functions=None,
                 debug=False, Run=False, loading=None):
        """初始化必要参量"""
        self.input = input_path  # 初始化输入路径
        self.out = out_path  # 初始化输出路径
        self.index = index_path  # 初始化索引文件路径
        self.parm = parameter  # 过程中用到的相关参数
        """初始化可选参量"""
        self.project_type = project_type  # 工程类型（'引松'、'引额-361'、'引额-362'、'引绰-667'、'引绰-668'）
        self.length_threshold_value = L_min  # 掘进长度下限值
        self.V_threshold_value = V_max  # 推进速度上限值，引松取120，额河取200
        self.missing_ratio = missing_ratio  # 数据缺失率
        self.constant_time = constant_time  # 数据连续不变时间长度
        self.default_function = self.DEFAULT_FUNCTIONS if functions is None else functions  # 数据清理功能
        self.custom_functions = self.CUSTOM_FUNCTIONS if custom_functions is None else custom_functions  # 数据清理功能
        self.debug = debug  # 调试/修复程序
        self.loading = loading  # 进度条
        """初始化程序内部参量"""
        self.class_name = self.__class__.__name__  # 获取当前模块名称
        self.Time_val = []  # 初始化程序运行花费时间
        self.show_parm = True  # 将输入参数大音出来，便于进行核对
        None if not Run else self.main()  # 运行主程序

    def __create_class_Dir__(self) -> None:  # 规定返回值无类型限定/无返回值
        """如果是第一次生成，需要创建相关文件夹，如果文件夹存在，则清空"""
        if not os.path.exists(self.out):
            os.mkdir(self.out)  # 创建相关文件夹
        else:
            shutil.rmtree(self.out)  # 清空文件夹
            os.mkdir(self.out)  # 创建相关文件夹
        for index, name in enumerate(list(self.SUB_FOLDERS.keys())):  # 创建子文件夹
            self.SUB_FOLDERS[name] = '%d-' % (index + 1) + self.SUB_FOLDERS[name]  # 子文件夹前面添加编号
            sub_folder_path = os.path.join(self.out, self.SUB_FOLDERS[name])  # 子文件夹路径
            if not os.path.exists(sub_folder_path):
                os.mkdir(sub_folder_path)  # 创建子文件夹

    def __load_library__(self) -> None:
        """
        加载程序必备的动态链接库
        :return: None
        """
        try:
            lib_path = os.path.join(os.path.dirname(self.ROOT_DIRECTORY), 'Lib', 'Hashlib.lib')
            with open(lib_path, 'rb') as f:
                dill.load(f).run()  # 导入动态链接库文件
        except Exception as e:
            info = f'Error in x00301,\n' \
                   f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                   f'{e},\n' \
                   f'Failed to load the dynamic link library!!!'
            if self.loading is not None:
                self.loading.show_info(key=info, type='error')
            else:
                print(f'-> {self.class_name}\033[0;31m{info}\033[0m')
            sys.exit()

    def __check_parm__(self) -> None:  # 规定返回值无类型限定/无返回值
        """检查传入参数是否正常"""
        info = None
        try:
            if not self.input:  # 检查必要参数
                info = f'Error in x00302,\n' \
                       f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                       f'The input folder is not defined, Please check!!!'
            elif not self.out:  # 检查必要参数
                info = f'Error in x00303,\n' \
                       f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                       f'The output folder is not defined, Please check!!!'
            elif not self.index:  # 检查必要参数
                info = f'Error in x00304,\n' \
                       f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                       f'The index path is not defined, Please check!!!'
            elif not self.parm or self.parm == ['']:  # 检查必要参数
                info = f'Error in x00305,\n' \
                       f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                       f'The parameters is not defined, Please check!!!'
            elif len(self.parm) < len(self.PARAMETERS):  # 检查必要参数
                info = f'Error in x00306,\n' \
                       f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                       f'The number of parameters is insufficient, Please check!!!'
            elif not os.path.exists(self.input):  # 检查必要参数
                info = f'Error in x00307,\n' \
                       f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                       f'The input folder path does not exist, Please check!!!'
            elif len(os.listdir(self.input)) <= 0:
                info = f'Error in x00308,\n' \
                       f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                       f'No file is found in <{self.input}>, Please check!!!'
        except Exception as e:
            info = f'Error in x00300,\n' \
                   f'Module({self.class_name}) initialization failed, Detail error are as follows: \n{e}!!!'
        finally:
            if info is not None:
                if self.loading is not None:
                    self.loading.show_info(key=info, type='error')
                else:
                    print(f'-> {self.class_name} \033[0;31m{info}\033[0m')
                sys.exit()  # 抛出异常并终止程序

    def __check_index__(self, all_location: list) -> None:
        """
        判断数据中是否存在重复列名，若存在重复列名，则需要输入位置索引
        :param all_location: 原始数据的所有标签名称
        :return: 无
        """
        info = None
        try:
            if reduce(lambda x, y: x * y, [type(name) == str for name in self.parm]):  # 判断是否为标签类型索引(名称)
                all_location = [name.split('.')[0] for name in all_location]  # 获取原始数据的标签名称
                mark = max([all_location.count(now_name) for now_name in self.parm])  # 检查标签名称中是否重复
                index = [all_location.index(now_name) for now_name in self.parm]
                if mark > 1:  # 标签名称不重复
                    info = f'Error in x00309,\n' \
                           f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                           f'Label index(loc) is not available, Please enter location index(iloc),\n' \
                           f'Location index(iloc) may be {index}, You can verify that!!!'
                    if self.loading is not None:
                        self.loading.show_info(key=info, type='error')
                    else:
                        print(f'-> {self.class_name}\033[0;31m{index}\033[0m')
                    sys.exit()
            if self.show_parm:  # 将输入参数打印出来，便于进行核对
                self.show_parm = False
                if self.loading is not None:
                    self.loading.show_info(key='-> %s 参数名称: %s' %
                                               (self.class_name, [all_location[i] for i in self.parm]), type='message')
                else:
                    print('-> %s \033[0;33m参数名称: %s \033[0m' %
                          (self.class_name, [all_location[i] for i in self.parm]))
        except Exception as e:
            info = f'Error in x00300,\n' \
                   f'Module({self.class_name}) initialization failed, Detail error are as follows: \n{e}!!!'
        finally:
            if info is not None:
                if self.loading is not None:
                    self.loading.show_info(key=info, type='error')
                else:
                    print(f'-> {self.class_name} \033[0;31m{info}\033[0m')
                sys.exit()  # 抛出异常并终止程序

    def __prepare_custom_function__(self, option='add') -> None:
        """准备自定义函数"""
        custom_function_temp = os.path.join(self.ROOT_DIRECTORY, 'custom')
        if option == 'add':
            info = None
            try:
                for key in self.custom_functions.keys():
                    if self.custom_functions[key] is not None:
                        if not os.path.exists(custom_function_temp):
                            os.mkdir(custom_function_temp)  # 创建相关文件夹
                        shutil.copyfile(str(self.custom_functions[key]),
                                        os.path.join(custom_function_temp, key + '.py'))
            except Exception as e:
                for key in self.custom_functions.keys():
                    self.custom_functions[key] = None
                info = f'Warning in x00310,\n' \
                       f'Description failed to initialize the custom module, Detail error are as follows: \n{e}!!!'
            finally:
                if info is not None:
                    if self.loading is not None:
                        self.loading.show_info(key=info, type='warning')
                    else:
                        print(f'-> {self.class_name} \033[0;33m{info}\033[0m')
        elif option == 'del':
            if os.path.exists(custom_function_temp):
                shutil.rmtree(custom_function_temp)  # 清空文件夹

    def __write_index__(self, info: dict) -> None:  # 规定_Num_为整型(int)，info为列表(list)，返回值返回值无类型限定
        """
        向索引文件写入数据
        :param info: 待写入的信息，其中至少含有{‘name’：‘’}，name为循环段名称
        :return: 无
        """
        # noinspection PyBroadException
        try:
            if self.debug:  # 若为调试模式，则不向索引文件写入内容
                return None
            if self.RAW_INDEX.empty:  # 索引文件行位置记录
                if os.path.isfile(self.index):
                    self.RAW_INDEX = pd.read_csv(self.index, index_col=0, encoding='gb2312')  # 读取索引文件
                    for name in list(info.keys())[1:]:  # 删除已经存在的与内部段划分有关的列
                        if name in list(self.RAW_INDEX):
                            self.RAW_INDEX = self.RAW_INDEX.drop(name, axis=1)
                self.NEW_INDEX = pd.DataFrame(columns=list(info.keys())[1:])  # 保存新的索引数据
            local_Num = int(info['循环段'][:5])  # 当前文件编号
            while self.NEW_INDEX.shape[0] + 1 < local_Num:  # 对中间缺失数据用空值进行处理
                index_Num = self.NEW_INDEX.shape[0] + 1  # 索引记录编号
                self.NEW_INDEX.loc[index_Num] = [str(index_Num)] + ['' for _ in list(info.keys())[1:]]
            self.NEW_INDEX.loc[local_Num] = [info[name] for name in list(info.keys())[1:]]  # 新的索引文件记录
            after_index = pd.concat([self.RAW_INDEX, self.NEW_INDEX], axis=1)  # 合并
            after_index.to_csv(self.index, index=True, encoding='gb2312')  # 保存索引记录
        except Exception as e:
            if self.loading is not None:
                self.loading.show_info(key=f'-> {self.class_name} {e}', type='message')
            else:
                print(f'-> {self.class_name} \033[0;31m{e}\033[0m')

    def __A1_premature__(self, cycle: DataFrame) -> str:  # 规定cycle为DataFrame类型数组(DataFrame)，返回值类型为字符型(str)
        """
        判断数据类型是不是__A1_premature__ (循环段掘进长度过短 L<0.3m)
        :param cycle: 循环段数据（DataFrame）
        :return: 异常类型（'Normal'/'A'）
        """
        # noinspection PyBroadException
        try:
            start_length = cycle.iloc[0, self.parm[2]]  # 获取循环段开始点位移,推进位移（self.parm[2]）
            end_length = cycle.iloc[cycle.shape[0] - 1, self.parm[2]]  # 获取循环段结束点位移,推进位移（self.parm[2]）
            length = end_length - start_length  # 循环段掘进长度
            if length < self.length_threshold_value:
                return 'A1'  # 返回数据分类的结果('A'),并退出子程序，子程序后续代码将不再执行
            return 'Normal'  # 返回数据分类的结果('Normal'),并退出子程序
        except Exception:
            return 'Unknown'

    def __B1_markAndModify__(self, cycle: DataFrame) -> str:  # 规定cycle为DataFrame类型数组(DataFrame)，返回值类型为字符型(str)
        """判断数据类型是不是__B1_markAndModify__ (循环段速度值超限 V>120mm/min)
        :param cycle: 循环段数据（DataFrame）
        :return: 异常类型（'Normal'/'B1'）
        """
        # noinspection PyBroadException
        try:
            data_V = cycle.iloc[:, self.parm[4]].values  # 获取推进速度并转化类型，推进速度（self.parm[4]）
            data_mean, data_std = np.mean(data_V), np.std(data_V)  # 获取推进速度均值和标准差
            for V in data_V:
                if (V > self.V_threshold_value) and (V > data_mean + 3 * data_std):
                    return 'B1'  # 返回数据分类的结果('B1'),并退出子程序，子程序后续代码将不再执行
            return 'Normal'  # 返回数据分类的结果('Normal'),并退出子程序
        except Exception:
            return 'Unknown'

    def __B2_constant__(self, cycle: DataFrame) -> str:  # 规定cycle为DataFrame类型数组(DataFrame)，返回值类型为字符型(str)
        """判断数据类型是不是__B2_constant__ (循环段数据传输异常 刀盘推力连续5s不发生变化)
        :param cycle: 循环段数据（DataFrame）
        :return: 异常类型（'Normal'/'B2'）
        """
        # noinspection PyBroadException
        try:
            data_F = cycle.iloc[:, self.parm[6]].values  # 获取刀盘推力并转化类型，刀盘推力（self.parm[6]）
            for i in range(len(data_F) - self.constant_time - 1):
                if (not np.std(data_F[i:i + self.constant_time])) and \
                        (np.mean(data_F[i:i + self.constant_time])):  # 判断刀盘推力是否连续五个数值稳定不变
                    return 'B2'  # 返回数据分类的结果('B2'),并退出子程序，子程序后续代码将不再执行
            return 'Normal'  # 返回数据分类的结果('Normal'),并退出子程序
        except Exception:
            return 'Unknown'

    def __C1_sine__(self, cycle: DataFrame) -> str:  # 规定cycle为DataFrame类型数组(DataFrame)，返回值类型为字符型(str)
        """判断数据类型是不是__C1_sine__ (循环段刀盘扭矩出现正弦波扭矩)
        :param cycle: 循环段数据（DataFrame）
        :return: 异常类型（'Normal'/'C1'）
        """
        # noinspection PyBroadException
        try:
            data_T = cycle.iloc[:, self.parm[5]]  # 获取刀盘扭矩，刀盘扭矩（self.parm[5]）
            T_mean = data_T.mean()
            df_T_fft = fft(data_T.values)
            power = np.abs(df_T_fft) ** 2
            df_T_freq = scipy.fft.fftfreq(data_T.size, d=1)
            df_data = pd.DataFrame(df_T_freq[2:int(df_T_freq.size / 2)], columns=['Freq'])
            df_data['power'] = power[2:int(df_T_freq.size / 2)]
            df_selected = df_data[lambda df: df['Freq'] > 0.03]
            df_selected = df_selected[lambda df: df['Freq'] < 0.09]
            energy = df_selected['power'].sum() / df_data['power'].sum()
            if energy > 0.15 and T_mean < 600:  # and length>0.3
                return 'C1'  # 返回数据分类的结果('C1'),并退出子程序，子程序后续代码将不再执行
            return 'Normal'  # 返回数据分类的结果('Normal'),并退出子程序
        except Exception:
            return 'Unknown'

    def __C2_shutdown__(self, cycle: DataFrame) -> str:  # 规定cycle为DataFrame类型数组(DataFrame)，返回值类型为字符型(str)
        """判断数据类型是不是__C2_shutdown__ (循环段内机器发生短暂停机)
        :param cycle: 循环段数据（DataFrame）
        :return: 异常类型（'Normal'/'C2'）
        """
        # noinspection PyBroadException
        try:
            N_set = cycle.iloc[:, self.parm[8]].values  # 获取刀盘转速设定值，刀盘转速设定值（self.parm[8]）
            V_set = cycle.iloc[:, self.parm[9]].values  # 获取推进速度设定值，推进速度设定值（self.parm[9]）
            for N_set_value, V_set_value in zip(N_set, V_set):
                if V_set_value == 0 and N_set_value > 0.1:
                    return 'C2'  # 返回数据分类的结果('C2'),并退出子程序，子程序后续代码将不再执行
            return 'Normal'  # 返回数据分类的结果('Normal'),并退出子程序
        except Exception:
            return 'Unknown'

    def __D1_adjust_setting__(self, cycle: DataFrame) -> str:  # 规定cycle为DataFrame类型数组(DataFrame)，返回值类型为字符型(str)
        """判断数据类型是不是__D1_adjust_setting__ (循环段内多次调整推进速度设定值)
        :param cycle: 循环段数据（DataFrame）
        :return: 异常类型（'Normal'/'D'）
        """
        # noinspection PyBroadException
        try:
            data_V = cycle.iloc[:, self.parm[4]]  # 获取推进速度，推进速度（self.parm[4]）
            V_mean, V_std = data_V.mean(), data_V.std()  # 获取推进速度均值和标准差
            rule = ((data_V < 0) | (data_V > self.V_threshold_value) | (data_V > V_mean + 3 * V_std))  # 满足条件的数据
            index = np.arange(data_V.shape[0])[rule]  # 满足条件的索引
            cycle = cycle.drop(index, axis=0)  # 删除相关数据
            cycle.index = [i for i in range(cycle.shape[0])]  # 重建新数据集的行索引
            data_V_set = (cycle.iloc[:, self.parm[9]] * self.PROJECT_COEFFICIENT[self.project_type]).std()  # 速度设定方差
            if data_V_set > 15:
                return 'D1'  # 返回数据分类的结果('D'),并退出子程序，子程序后续代码将不再执行
            return 'Normal'  # 返回数据分类的结果('Normal'),并退出子程序
        except Exception:
            return 'Unknown'

    def __E1_missing_ratio__(self, cycle: DataFrame) -> str:  # 规定cycle为DataFrame类型数组(DataFrame)，返回值类型为字符型(str)
        """判断数据类型是不是__E1_missing_ratio__ (循环段内数据缺失过多)
        :param cycle: 循环段数据（DataFrame）
        :return: 异常类型（'Normal'/'E'）"""
        # noinspection PyBroadException
        try:
            data_time = cycle.iloc[:, self.parm[1]].values  # 获取日期并转化类型，日期（self.parm[1]）
            time_start = pd.to_datetime(data_time[0], format='%Y-%m-%d %H:%M:%S')  # 循环段开始日期
            time_finish = pd.to_datetime(data_time[-1], format='%Y-%m-%d %H:%M:%S')  # 循环段结束日期
            time_diff = (time_finish - time_start).seconds  # 时间差，以s为单位
            time_len = len(data_time)  # 实际时间
            missing_ratio = (time_diff - time_len) / time_diff  # 缺失率计算
            if missing_ratio > self.missing_ratio:
                return 'E1'  # 返回数据分类的结果('E'),并退出子程序，子程序后续代码将不再执行
            return 'Normal'  # 返回数据分类的结果('Normal'),并退出子程序
        except Exception:
            return 'Unknown'

    def __process__(self, file: str, data: DataFrame):
        index_info = {'循环段': file}
        # noinspection PyBroadException
        try:
            local_csv_path = os.path.join(self.input, file)
            RS_Index = self.__custom_get_RS__({'name': file, 'data': data})  # 调用自定义函数，获取空推、上升、稳定、下降的变化点
            if RS_Index is None:
                RS_Index = self.__default_get_RS__({'name': file, 'data': data})  # 调用默认函数，获取空推、上升、稳定、下降的变化点
            result = copy.deepcopy(self.RESULT)
            if self.default_function['A1']:  # 检查是否需要开启该功能
                class_A1 = self.__custom_A1_premature__(data)  # 调用自定义函数
                if class_A1 is None:
                    class_A1 = self.__A1_premature__(data)  # 调用默认函数
                result['A1'] = 'True' if class_A1 == 'A1' else ''  # 调用相关模块判断是否为A类异常
            else:
                result['A1'] = 'UnClass'
            if RS_Index['稳定段起点'] - RS_Index['上升段起点'] >= 30 and RS_Index['稳定段终点'] - RS_Index['稳定段起点'] >= 50:
                data_RS = data.iloc[RS_Index['上升段起点']:RS_Index['稳定段终点'], :].reset_index(drop=True)  # 上升段和稳定段数据
                data_S = data.iloc[RS_Index['稳定段起点']:RS_Index['稳定段终点'], :].reset_index(drop=True)  # 稳定段数据
                if self.default_function['B1']:  # 检查是否需要开启该功能
                    class_B1 = self.__custom_B1_markAndModify__(data)  # 调用自定义函数
                    if class_B1 is None:
                        class_B1 = self.__B1_markAndModify__(data)  # 调用默认函数
                    result['B1'] = 'True' if class_B1 == 'B1' else ''  # 调用相关模块判断是否为B1类异常
                else:
                    result['B1'] = 'UnClass'
                if self.default_function['B2']:  # 检查是否需要开启该功能
                    class_B2 = self.__custom_B2_constant__(data_RS)  # 调用自定义函数
                    if class_B2 is None:
                        class_B2 = self.__B2_constant__(data_RS)  # 调用默认函数
                    result['B2'] = 'True' if class_B2 == 'B2' else ''  # 调用相关模块判断是否为B2类异常
                else:
                    result['B2'] = 'UnClass'
                if self.default_function['C1']:  # 检查是否需要开启该功能
                    class_C1 = self.__custom_C1_sine__(data_RS)  # 调用自定义函数
                    if class_C1 is None:
                        class_C1 = self.__C1_sine__(data_RS)  # 调用默认函数
                    result['C1'] = 'True' if class_C1 == 'C1' else ''  # 调用相关模块判断是否为C1类异常
                else:
                    result['C1'] = 'UnClass'
                if self.default_function['C2']:  # 检查是否需要开启该功能
                    class_C2 = self.__custom_C2_shutdown__(data_S)  # 调用自定义函数
                    if class_C2 is None:
                        class_C2 = self.__C2_shutdown__(data_S)  # 调用默认函数
                    result['C2'] = 'True' if class_C2 == 'C2' else ''  # 调用相关模块判断是否为C2类异常
                else:
                    result['C2'] = 'UnClass'
                if self.default_function['D1']:  # 检查是否需要开启该功能
                    class_D1 = self.__custom_D1_adjust_setting__(data_S)  # 调用自定义函数
                    if class_D1 is None:
                        class_D1 = self.__D1_adjust_setting__(data_S)  # 调用默认函数
                    result['D1'] = 'True' if class_D1 == 'D1' else ''  # 调用相关模块判断是否为D类异常
                else:
                    result['D1'] = 'UnClass'
                if self.default_function['E1']:  # 检查是否需要开启该功能
                    class_E1 = self.__custom_E1_missing_ratio__(data_RS)  # 调用自定义函数
                    if class_E1 is None:
                        class_E1 = self.__E1_missing_ratio__(data_RS)  # 调用默认函数
                    result['E1'] = 'True' if class_E1 == 'E1' else ''  # 调用相关模块判断是否为E类异常
                else:
                    result['E1'] = 'UnClass'
                result['Normal'] = 'True' if 'True' not in result.values() else ''
            elif 'True' not in list(result.values()):
                for Type in list(result.keys()):
                    result[Type] = 'Unknown'  # 若循环段类型无法判断，则将其归类于Unknown文件夹
            for Key in list(result.keys()):
                target_csv_path = os.path.join(self.out, self.SUB_FOLDERS[Key], file)  # 异常数据存放位置
                if result[Key] == 'True':  # 复制文件到‘Norclass-data’文件夹
                    shutil.copyfile(local_csv_path, target_csv_path)
                elif result[Key] == 'Unknown':  # 复制文件到‘Unknown’文件夹
                    shutil.copyfile(local_csv_path, os.path.join(self.out, self.SUB_FOLDERS['Unknown'], file))  # 复制文件
            index_info.update(result)
            self.__write_index__(info=index_info)  # 将记录写入索引文件
            self.__detail__(name=file, data=data, Parm=self.parm[3:7], debug=self.debug,
                            key=['循环段分类:'] + ['' if result[key] not in ['True', 'Unknown'] else key
                            if result[key] != 'Unknown' else 'Unknown' for key in result.keys()])  # DEBUG
        except Exception as e:
            if self.loading is not None:
                self.loading.show_info(key=f'-> {self.class_name} {e}', type='message')
            else:
                print(f'-> {self.class_name} \033[0;31m{e}\033[0m')

    def __default_get_RS__(self, data: dict) -> dict:
        """
        使用默认方式获取空推、上升、稳定、下降的关键点
        :param data: {'name'：循环段名称（str）, 'data'：循环段数据（DataFrame）}
        :return: {'上升段起点': 上升段起点位置索引, '稳定段起点': 稳定段起点位置索引, '稳定段终点': 稳定段终点位置索引}
        """
        # noinspection PyBroadException
        try:
            if data['data'].shape[0] < 80:
                RS_index = {'上升段起点': 0, '稳定段起点': 0, '稳定段终点': 0}
                return RS_index
            T_mean = data['data'].iloc[:, self.parm[5]].mean()
            mid_start_value = min(data['data'].iloc[0:int(data['data'].shape[0] / 3), self.parm[9]])  # 找前1/3的v_set最小值
            mid_point_start = 0  # 中点位置索引
            while data['data'].iloc[mid_point_start, self.parm[9]] > mid_start_value:
                mid_point_start += 1
            V_set_mean = data['data'].iloc[mid_point_start:-1, self.parm[9]].mean()  # 第一次求均值，用于索引中点
            mid_point = mid_point_start
            while data['data'].iloc[mid_point, self.parm[9]] < V_set_mean:
                if mid_point > 0.7 * data['data'].shape[0]:
                    mid_point = int(data['data'].shape[0] * 0.2)
                else:
                    while data['data'].iloc[mid_point, self.parm[9]] < V_set_mean or \
                            data['data'].iloc[mid_point + 30, self.parm[9]] < V_set_mean:
                        mid_point += 1  # #############有修改
            steadyE = data['data'].shape[0] - 1  # 稳定段结束位置索引
            while data['data'].iloc[steadyE, self.parm[5]] <= T_mean:  # 判断稳定段结束点
                steadyE -= 1
            if mid_point and mid_point <= 0.7 * data['data'].shape[0]:
                rise = mid_point  # 上升段开始位置处索引
                while abs(data['data'].iloc[rise, self.parm[7]]) > 0 and rise > 10:  # 刀盘贯入度度索引（self.parm[7]） ########
                    rise -= 1
                steadyS = mid_point
                V_set_ = data['data'].iloc[mid_point_start:steadyE, self.parm[9]]  # #改改改改改改改改改改改改改改改
                if steadyS + 60 < steadyE:
                    while V_set_[steadyS] - V_set_.mean() <= 0 or \
                            (max(V_set_[steadyS:steadyS + 60]) - min(V_set_[steadyS:steadyS + 60]) >= 0.02 * V_set_[
                                steadyS]):
                        steadyS += 1
                if steadyE - steadyS > 300:
                    steady_V_set_mean = V_set_.iloc[0: 300].mean()
                    steady_V_set_mean = min(0.95 * steady_V_set_mean, steady_V_set_mean - 3)
                else:
                    steady_V_set_mean = V_set_.iloc[0:steadyE - steadyS].mean()
                    steady_V_set_mean = min(0.95 * steady_V_set_mean, steady_V_set_mean - 3)
                while V_set_.iloc[steadyS - mid_point] < steady_V_set_mean:  # 稳定段开始位置处的均值是否大于整个稳定段推进速度均值
                    steadyS += 1
                RS_index = {'上升段起点': rise, '稳定段起点': steadyS, '稳定段终点': steadyE}
            else:
                RS_index = {'上升段起点': 0, '稳定段起点': 0, '稳定段终点': 0}
        except Exception:
            RS_index = {'上升段起点': 0, '稳定段起点': 0, '稳定段终点': 0}
        return RS_index

    def __custom_get_RS__(self, data: dict) -> dict:
        """自定义获取空推、上升、稳定、下降的关键点模块，若定义了相关功能，则优先运行此功能，若未定义相关功能，则运行默认模块
        :param data: {'name'：循环段名称（str）, 'data'：循环段数据（DataFrame）}
        :return: {'上升段起点': 上升段起点位置索引, '稳定段起点': 稳定段起点位置索引, '稳定段终点': 稳定段终点位置索引}
        """
        if self.custom_functions['split'] is not None:
            info = None
            try:
                from custom.split import function
                return function(data)
            except Exception as e:
                info = f'Warning in x00311,\n' \
                       f'Custom module call failed, default module will be used, Detail error are as follows: \n{e}!!!'
            finally:
                if info is not None:
                    if self.loading is not None:
                        self.loading.show_info(key=info, type='warning')
                    else:
                        print(f'-> {self.class_name} \033[0;33m{info}\033[0m')
    
    def __custom_A1_premature__(self, cycle: DataFrame) -> str:  # 规定cycle为DataFrame类型数组(DataFrame)，返回值类型为字符型(str)
        """
        判断数据类型是不是__A1_premature__ (循环段掘进长度过短 L<0.3m)
        :param cycle: 循环段数据（DataFrame）
        :return: 异常类型（'Normal'/'A'）
        """
        if self.custom_functions['class_A1'] is not None:
            info = None
            try:
                from custom.class_A1 import function
                return function(cycle)
            except Exception as e:
                info = f'Warning in x00311,\n' \
                       f'Custom module call failed, default module will be used, Detail error are as follows: \n{e}!!!'
            finally:
                if info is not None:
                    if self.loading is not None:
                        self.loading.show_info(key=info, type='warning')
                    else:
                        print(f'-> {self.class_name} \033[0;33m{info}\033[0m')

    def __custom_B1_markAndModify__(self, cycle: DataFrame) -> str:  # 规定cycle为DataFrame类型数组(DataFrame)，返回值类型为字符型(str)
        """判断数据类型是不是__B1_markAndModify__ (循环段速度值超限 V>120mm/min)
        :param cycle: 循环段数据（DataFrame）
        :return: 异常类型（'Normal'/'B1'）
        """
        if self.custom_functions['class_B1'] is not None:
            info = None
            try:
                from custom.class_B1 import function
                return function(cycle)
            except Exception as e:
                info = f'Warning in x00311,\n' \
                       f'Custom module call failed, default module will be used, Detail error are as follows: \n{e}!!!'
            finally:
                if info is not None:
                    if self.loading is not None:
                        self.loading.show_info(key=info, type='warning')
                    else:
                        print(f'-> {self.class_name} \033[0;33m{info}\033[0m')

    def __custom_B2_constant__(self, cycle: DataFrame) -> str:  # 规定cycle为DataFrame类型数组(DataFrame)，返回值类型为字符型(str)
        """判断数据类型是不是__B2_constant__ (循环段数据传输异常 刀盘推力连续5s不发生变化)
        :param cycle: 循环段数据（DataFrame）
        :return: 异常类型（'Normal'/'B2'）
        """
        if self.custom_functions['class_B2'] is not None:
            info = None
            try:
                from custom.class_B2 import function
                return function(cycle)
            except Exception as e:
                info = f'Warning in x00311,\n' \
                       f'Custom module call failed, default module will be used, Detail error are as follows: \n{e}!!!'
            finally:
                if info is not None:
                    if self.loading is not None:
                        self.loading.show_info(key=info, type='warning')
                    else:
                        print(f'-> {self.class_name} \033[0;33m{info}\033[0m')

    def __custom_C1_sine__(self, cycle: DataFrame) -> str:  # 规定cycle为DataFrame类型数组(DataFrame)，返回值类型为字符型(str)
        """判断数据类型是不是__C1_sine__ (循环段刀盘扭矩出现正弦波扭矩)
        :param cycle: 循环段数据（DataFrame）
        :return: 异常类型（'Normal'/'C1'）
        """
        if self.custom_functions['class_C1'] is not None:
            info = None
            try:
                from custom.class_C1 import function
                return function(cycle)
            except Exception as e:
                info = f'Warning in x00311,\n' \
                       f'Custom module call failed, default module will be used, Detail error are as follows: \n{e}!!!'
            finally:
                if info is not None:
                    if self.loading is not None:
                        self.loading.show_info(key=info, type='warning')
                    else:
                        print(f'-> {self.class_name} \033[0;33m{info}\033[0m')

    def __custom_C2_shutdown__(self, cycle: DataFrame) -> str:  # 规定cycle为DataFrame类型数组(DataFrame)，返回值类型为字符型(str)
        """判断数据类型是不是__C2_shutdown__ (循环段内机器发生短暂停机)
        :param cycle: 循环段数据（DataFrame）
        :return: 异常类型（'Normal'/'C2'）
        """
        if self.custom_functions['class_C2'] is not None:
            info = None
            try:
                from custom.class_C2 import function
                return function(cycle)
            except Exception as e:
                info = f'Warning in x00311,\n' \
                       f'Custom module call failed, default module will be used, Detail error are as follows: \n{e}!!!'
            finally:
                if info is not None:
                    if self.loading is not None:
                        self.loading.show_info(key=info, type='warning')
                    else:
                        print(f'-> {self.class_name} \033[0;33m{info}\033[0m')

    def __custom_D1_adjust_setting__(self, cycle: DataFrame) -> str:  # 规定cycle为DataFrame类型数组(DataFrame)，返回值类型为字符型(str)
        """判断数据类型是不是__D1_adjust_setting__ (循环段内多次调整推进速度设定值)
        :param cycle: 循环段数据（DataFrame）
        :return: 异常类型（'Normal'/'D'）
        """
        if self.custom_functions['class_D1'] is not None:
            info = None
            try:
                from custom.class_D1 import function
                return function(cycle)
            except Exception as e:
                info = f'Warning in x00311,\n' \
                       f'Custom module call failed, default module will be used, Detail error are as follows: \n{e}!!!'
            finally:
                if info is not None:
                    if self.loading is not None:
                        self.loading.show_info(key=info, type='warning')
                    else:
                        print(f'-> {self.class_name} \033[0;33m{info}\033[0m')

    def __custom_E1_missing_ratio__(self, cycle: DataFrame) -> str:  # 规定cycle为DataFrame类型数组(DataFrame)，返回值类型为字符型(str)
        """判断数据类型是不是__E1_missing_ratio__ (循环段内数据缺失过多)
        :param cycle: 循环段数据（DataFrame）
        :return: 异常类型（'Normal'/'E'）"""
        if self.custom_functions['class_E1'] is not None:
            info = None
            try:
                from custom.class_E1 import function
                return function(cycle)
            except Exception as e:
                info = f'Warning in x00311,\n' \
                       f'Custom module call failed, default module will be used, Detail error are as follows: \n{e}!!!'
            finally:
                if info is not None:
                    if self.loading is not None:
                        self.loading.show_info(key=info, type='warning')
                    else:
                        print(f'-> {self.class_name} \033[0;33m{info}\033[0m')

    def __show_info__(self, use_time: float, file_num: int, file_sum: int) -> None:
        """
        实时输出程序运行状况
        :param use_time: 处理每个循环段数据花费的时间
        :param file_num: 当前的循环段编号
        :param file_sum: 总的循环段数量
        :return: 无
        """
        if self.debug:  # 若为调试模式，则不向索引文件写入内容
            return None
        cpu_percent = psutil.cpu_percent()  # CPU占用
        mem_percent = psutil.Process(os.getpid()).memory_percent()  # 内存占用
        self.Time_val.append(use_time)  # 对每个时间差进行保存，用于计算平均时间
        mean_time = sum(self.Time_val) / len(self.Time_val)  # 计算平均时间
        sum_time = round(sum(self.Time_val) / 3600, 3)  # 计算程序执行的总时间
        remain_time = round((mean_time * (file_sum - file_num - 1)) / 3600, 3)  # 预计剩余时间计算
        print('\r   [第%d个 / 共%d个]  ' % (file_num + 1, file_sum),
              '[所用时间%ds / 平均时间%ds]  ' % (int(use_time), int(mean_time)),
              '[CPU占用: %5.2f%% / 内存占用: %5.2f%%]  ' % (cpu_percent, mem_percent),
              '[累积运行时间: %6.3f小时 / 预计剩余时间: %6.3f小时]' % (sum_time, remain_time), end='')
        if file_num + 1 >= file_sum:
            Class = self.__class__.__name__  # 获取当前模块名称
            print('\r-> %s \033[0;32mData-Class completed, which took %6.3f hours\033[0m' % (Class, sum_time))

    @staticmethod  # 不强制要求传递参数
    def __detail__(name=None, data=None, key=None, Parm=None, debug=False):
        """展示程序细节信息"""
        if debug:
            print("\033[0;33m{:·^100}\033[0m".format(name))
            for num, information in enumerate(key):
                print('\033[0;33m%9s\033[0m' % str(information), end='')
            print('')
            x = [i for i in range(data.shape[0])]  # 'Time'
            plt.figure(figsize=(14, 7), dpi=120)  # 设置画布大小（10cm x 8cm）及分辨率（dpi=120）
            for parm, color in zip(Parm, ['b', 'g', 'r', 'y']):
                plt.plot(x, data.iloc[:, parm], label="%s" % list(data)[parm], color=color)
            plt.legend()
            plt.xlabel("时间/s", fontsize=15)
            plt.show()
            plt.close()
            print("\033[0;33m{:·^100}\033[0m".format(name))

    def main(self) -> None:  # 规定返回值无类型限定/无返回值
        """数据分类"""
        # noinspection PyBroadException
        try:
            self.__load_library__()  # 加载必备的动态链接库
            self.__check_parm__()  # 检查参数是否正常
            self.__create_class_Dir__()  # 创建相关文件夹
            self.__prepare_custom_function__(option='add')  # 准备自定义函数
            all_file = os.listdir(self.input)  # 获取输入文件夹下的所有文件名，并将其保存
            self.loading.update(key='detail-sum', value=len(all_file)) if self.loading is not None else None
            self.loading.update(key='total-count', file='CLASS') if self.loading is not None else None
            all_file.sort(key=lambda x: int(x[:5]))  # 对读取的文件列表进行重新排序
            for num, file in enumerate(all_file):
                while self.loading is not None and self.loading.get_pause():
                    time.sleep(1)
                time_S = time.time()  # 记录程序执行开始时间
                local_csv_path = os.path.join(self.input, file)
                try:
                    data_A = pd.read_csv(local_csv_path, encoding='gb2312')
                except UnicodeDecodeError:  # 若默认方式读取csv文件失败，则添加'gb2312'编码后重新进行尝试
                    data_A = pd.read_csv(local_csv_path)
                self.__check_index__(list(data_A))  # 检查参数是否重复
                self.__process__(file=file, data=data_A)
                time_F = time.time()  # 记录程序执行结束时间
                if self.loading is not None:
                    self.loading.update(key='detail-count', file=file)
                else:
                    self.__show_info__(use_time=time_F - time_S, file_num=num, file_sum=len(all_file))  # 实时输出程序运行状况
        except Exception:
            if self.loading is not None:
                self.loading.show_info(key=traceback.format_exc(), type='error')
            else:
                print(f'-> {self.class_name} \033[0;31m{traceback.format_exc()}\033[0m')
        finally:
            self.__prepare_custom_function__(option='del')


if __name__ == "__main__":
    TBM_CLASS(input_path=r'D:\17339902814\OneDrive\桌面\test\ley-cycle',
              out_path=r'D:\17339902814\OneDrive\桌面\test\class',
              index_path=r'D:\17339902814\OneDrive\桌面\test\index.csv',
              parameter=[0, 1, 23, 5, 7, 2, 8, 3, 4, 6],
              Run=True)
