#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ************************************************************************
# * Software:  TBM Pre-process                                           *
# * Version:  1.0.7                                                      *
# * Date:  2024-06-24 22:27:58                                           *
# * Last  update: 2024-03-08 20:00:00                                    *
# * License:  LGPL v1.0                                                  *
# * Maintain  address:  https://pan.baidu.com/s/1WIr67y1pNQCgEyUnuj004w  *
# * Maintain  code:  STBM                                                *
# * Email: jgliu1001@163.com                                             *
# ************************************************************************

import copy
import traceback
import datetime
import time
import os
import sys
import shutil
import numpy as np
import pandas as pd
import psutil
from functools import reduce
from numpy import ndarray
from pandas import Series, DataFrame


class TBM_CLEAN(object):
    """
    异常数据清理修正模块，主要完成异常循环段修正的工作
    ****必选参数：原始数据存放路径（input_path），若不传入输入路径，程序则抛出异常并终止运行
                生成数据保存路径（out_path），若不传入输入路径，程序则抛出异常并终止运行
                索引文件保存路径（index_path），若不传入输出路径，程序则抛出异常并终止运行
                程序运行所需要的关键参数名称（par_name），若不传入参数，程序则会终止运行
    ****可选参数：推进速度最大值（V_max），引松取 120mm/min，额河取 200mm/min;
                程序调试/修复选项（debug），默认为关闭状态
                直接运行程序（Run）， 默认为开启状态
    """
    global copy, traceback, datetime, time, os, sys, shutil, np, pd, psutil, reduce, ndarray, Series, DataFrame
    if getattr(sys, 'frozen', False):
        ROOT_DIRECTORY = os.path.dirname(sys.executable)  # 获取可执行文件所在文件夹路径
    else:
        ROOT_DIRECTORY = os.path.dirname(os.path.abspath(sys.argv[0]))
    DEFAULT_FUNCTIONS = {'A1': False, 'B1': True, 'B2': False, 'C1': False, 'C2': False, 'D1': False, 'E1': False}
    PARAMETERS = ['桩号', '日期', '推进位移', '刀盘转速', '推进速度', '刀盘扭矩',
                  '总推力', '刀盘贯入度', '刀盘转速设定值', '推进速度设定值']  # 默认参数示例
    SUB_FOLDERS = {'A1': 'NorA1class-data', 'B1': 'NorB1class-data', 'B2': 'NorB2class-data',
                   'C1': 'NorC1class-data', 'C2': 'NorC2class-data', 'D1': 'NorD1class-data',
                   'E1': 'NorE1class-data', 'Unknown': 'Unknown-data', 'Normal': 'Normclass-data'}  # 默认子文件夹
    INDEX_NAME = ['循环段', 'A1', 'B1', 'B2', 'C1', 'C2', 'D1', 'E1', 'Normal']
    CUSTOM_FUNCTIONS = {'clean_A1': None, 'clean_B1': None, 'clean_B2': None, 'clean_C1': None,
                        'clean_C2': None, 'clean_D1': None, 'clean_E1': None},
    RAW_INDEX = pd.DataFrame()  # 保存原始索引数据
    NEW_INDEX = pd.DataFrame()  # 保存新的索引数据

    def __init__(self, input_path=None, out_path=None, index_path=None, parameter=None,
                 V_max=120, functions=None, custom_functions=None,
                 debug=False, Run=False, loading=None):
        """初始化必要参量"""
        self.input = input_path  # 初始化输入路径
        self.index = index_path  # 初始化索引文件路径
        self.out = out_path  # 初始化输出路径
        self.parm = parameter  # 过程中用到的相关参数
        """初始化可选参量"""
        self.V_threshold_value = V_max  # 推进速度上限值，引松取120，额河取200
        self.default_function = self.DEFAULT_FUNCTIONS if functions is None else functions  # 数据清理功能
        self.custom_functions = self.CUSTOM_FUNCTIONS if custom_functions is None else custom_functions  # 数据清理功能
        self.debug = debug  # 调试/修复程序
        self.loading = loading  # 进度条
        """初始化程序内部参量"""
        self.class_name = self.__class__.__name__  # 获取当前模块名称
        self.Time_val = []  # 初始化程序运行花费时间
        self.show_parm = True  # 将输入参数大音出来，便于进行核对
        None if not Run else self.main()  # 运行主程序

    def __create_clean_Dir__(self) -> None:  # 规定返回值无类型限定/无返回值
        """如果是第一次生成，需要创建相关文件夹，如果文件夹存在，则清空"""
        if not os.path.exists(self.out):
            os.mkdir(self.out)  # 创建相关文件夹
        else:
            shutil.rmtree(self.out)  # 清空文件夹
            os.mkdir(self.out)  # 创建相关文件夹
        for index, name in enumerate(list(self.SUB_FOLDERS.keys())):  # 创建子文件夹
            self.SUB_FOLDERS[name] = '%d-' % (index + 1) + self.SUB_FOLDERS[name]  # 子文件夹前面添加编号
            sub_folder_path = os.path.join(self.out, self.SUB_FOLDERS[name])  # 子文件夹路径
            if not os.path.exists(sub_folder_path):
                os.mkdir(sub_folder_path)  # 创建子文件夹

    def __check_parm__(self) -> None:  # 规定返回值无类型限定/无返回值
        """检查传入参数是否正常"""
        info = None
        try:
            if not self.input:  # 检查必要参数
                info = f'Error in x00402,\n' \
                       f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                       f'The input folder is not defined, Please check!!!'
            elif not self.out:  # 检查必要参数
                info = f'Error in x00403,\n' \
                       f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                       f'The output folder is not defined, Please check!!!'
            elif not self.index:  # 检查必要参数
                info = f'Error in x00404,\n' \
                       f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                       f'The index path is not defined, Please check!!!'
            elif not self.parm or self.parm == ['']:  # 检查必要参数
                info = f'Error in x00405,\n' \
                       f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                       f'The parameters is not defined, Please check!!!'
            elif len(self.parm) < len(self.PARAMETERS):  # 检查必要参数
                info = f'Error in x00406,\n' \
                       f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                       f'The number of parameters is insufficient, Please check!!!'
            elif not os.path.exists(self.input):  # 检查必要参数
                info = f'Error in x00407,\n' \
                       f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                       f'The input folder path does not exist, Please check!!!'
            elif len(os.listdir(self.input)) <= 0:
                info = f'Error in x00408,\n' \
                       f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                       f'No file is found in <{self.input}>, Please check!!!'
        except Exception as e:
            info = f'Error in x00400,\n' \
                   f'Module({self.class_name}) initialization failed, Detail error are as follows: \n{e}!!!'
        finally:
            if info is not None:
                if self.loading is not None:
                    self.loading.set_message(message=info, type='error')
                else:
                    print(f'-> {self.class_name} \033[0;31m{info}\033[0m')
                sys.exit()  # 抛出异常并终止程序

    def __check_index__(self, all_location: list) -> None:
        """
        判断数据中是否存在重复列名，若存在重复列名，则需要输入位置索引
        :param all_location: 原始数据的所有标签名称
        :return: 无
        """
        info = None
        try:
            if reduce(lambda x, y: x * y, [type(name) == str for name in self.parm]):  # 判断是否为标签类型索引(名称)
                all_location = [name.split('.')[0] for name in all_location]  # 获取原始数据的标签名称
                mark = max([all_location.count(now_name) for now_name in self.parm])  # 检查标签名称中是否重复
                index = [all_location.index(now_name) for now_name in self.parm]
                if mark > 1:  # 标签名称不重复
                    info = f'Error in x00409,\n' \
                           f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                           f'Label index(loc) is not available, Please enter location index(iloc),\n' \
                           f'Location index(iloc) may be {index}, You can verify that!!!'
                    if self.loading is not None:
                        self.loading.set_message(message=info, type='error')
                    else:
                        print(f'-> {self.class_name}\033[0;31m{index}\033[0m')
                    sys.exit()
            if self.show_parm:  # 将输入参数打印出来，便于进行核对
                self.show_parm = False
                if self.loading is not None:
                    self.loading.set_message(message='-> %s 参数名称: %s' %
                                               (self.class_name, [all_location[i] for i in self.parm]), type='text')
                else:
                    print('-> %s \033[0;33m参数名称: %s \033[0m' %
                          (self.class_name, [all_location[i] for i in self.parm]))
        except Exception as e:
            info = f'Error in x00400,\n' \
                   f'Module({self.class_name}) initialization failed, Detail error are as follows: \n{e}!!!'
        finally:
            if info is not None:
                if self.loading is not None:
                    self.loading.set_message(message=info, type='error')
                else:
                    print(f'-> {self.class_name} \033[0;31m{info}\033[0m')
                sys.exit()  # 抛出异常并终止程序

    def __prepare_custom_function__(self, option='add') -> None:
        """准备自定义函数"""
        custom_function_temp = os.path.join(self.ROOT_DIRECTORY, 'custom')
        if option == 'add':
            info = None
            try:
                for key in self.custom_functions.keys():
                    if self.custom_functions[key] is not None:
                        if not os.path.exists(custom_function_temp):
                            os.mkdir(custom_function_temp)  # 创建相关文件夹
                        shutil.copyfile(str(self.custom_functions[key]),
                                        os.path.join(custom_function_temp, key + '.py'))
            except Exception as e:
                for key in self.custom_functions.keys():
                    self.custom_functions[key] = None
                info = f'Warning in x00410,\n' \
                       f'Description failed to initialize the custom module, Detail error are as follows: \n{e}!!!'
            finally:
                if info is not None:
                    if self.loading is not None:
                        self.loading.set_message(message=info, type='warning')
                    else:
                        print(f'-> {self.class_name} \033[0;33m{info}\033[0m')
        elif option == 'del':
            if os.path.exists(custom_function_temp):
                shutil.rmtree(custom_function_temp)  # 清空文件夹

    def __write_index__(self, info: dict) -> None:  # 规定_Num_为整型(int)，info为列表(list)，返回值返回值无类型限定
        """
        向索引文件写入数据
        :param info: 待写入的信息，其中至少含有{‘name’：‘’, 'Type'：‘’}，name为循环段名称, Type为异常类型
        :return: 无
        """
        # noinspection PyBroadException
        try:
            if self.debug:  # 若为调试模式，则不向索引文件写入内容
                return None
            if self.RAW_INDEX.empty:  # 索引文件行位置记录
                Type = {'A': str, 'B1': str, 'B2': str, 'C1': str, 'C2': str, 'D': str, 'E': str, 'Normal': str}
                self.RAW_INDEX = pd.read_csv(self.index, index_col=0, encoding='gb2312', dtype=Type)  # 读取索引文件
                self.NEW_INDEX = copy.deepcopy(self.RAW_INDEX)  # 复制一份索引文件
            self.RAW_INDEX[info['Type']][int(info['循环段'][:5])] = ''  # 修正后去掉异常循环段标识
            if (self.RAW_INDEX.loc[int(info['循环段'][:5]), self.INDEX_NAME[1:-1]] == 'True').sum() <= 0:
                self.NEW_INDEX['Normal'][int(info['循环段'][:5])] = 'True'  # 将修正后的索引修改为True
                self.NEW_INDEX.to_csv(self.index, encoding='gb2312')  # 保存索引记录
        except Exception as e:
            if self.loading is not None:
                self.loading.set_message(message=f'-> {self.class_name} {e}', type='message')
            else:
                print(f'-> {self.class_name} \033[0;31m{e}\033[0m')

    def __A1_premature_Modify__(self, cycle: DataFrame) -> DataFrame:  # 规定cycle为(DataFrame)类型数组，返回值为(DataFrame)类型数组
        """对A_premature (循环段掘进长度过短 L<0.3m)类异常数据进行修正
        :param cycle: 循环段数据（DataFrame）
        :return: 修正后循环段数据（DataFrame）
        """
        pass

    def __B1_mark_Modify__(self, cycle: DataFrame) -> DataFrame:  # 规定cycle为(DataFrame)类型数组，返回值为(DataFrame)类型数组
        """对B1_markAndModify (循环段速度值超限 V>120mm/min)类异常数据进行修正
        :param cycle: 循环段数据（DataFrame）
        :return: 修正后循环段数据（DataFrame）
        """
        data_V = cycle.iloc[:, self.parm[4]].values  # 推进速度（self.parm[4]）
        data_mean, data_std = np.mean(data_V), np.std(data_V)  # 获取推进速度均值和标准差
        for i in range(len(data_V)):
            if data_V[i] > self.V_threshold_value or (data_V[i] > data_mean + 3 * data_std):
                replace = sum(data_V[i - 10:i]) / 10.0  # 采用前10个推进速度的平均值进行替换
                cycle.iloc[i, self.parm[4]] = replace  # 采用前10个推进速度的平均值进行替换
        return cycle

    def __B2_constant_Modify__(self, cycle: DataFrame) -> DataFrame:  # 规定cycle为(DataFrame)类型数组，返回值为(DataFrame)类型数组
        """对B2_constant (循环段数据传输异常 刀盘推力连续5s不发生变化)类异常数据进行修正
        :param cycle: 循环段数据（DataFrame）
        :return: 修正后循环段数据（DataFrame）
        """
        pass

    def __C1_sine_Modify__(self, cycle: DataFrame) -> DataFrame:  # 规定cycle为(DataFrame)类型数组，返回值为(DataFrame)类型数组
        """对C1_sine (循环段刀盘扭矩出现正弦波扭矩)类异常数据进行修正
        :param cycle: 循环段数据（DataFrame）
        :return: 修正后循环段数据（DataFrame）
        """
        pass

    def __C2_shutdown_Modify__(self, cycle: DataFrame) -> DataFrame:  # 规定cycle为(DataFrame)类型数组，返回值为(DataFrame)类型数组
        """对C2_shutdown (循环段内机器发生短暂停机)类异常数据进行修正
        :param cycle: 循环段数据（DataFrame）
        :return: 修正后循环段数据（DataFrame）
        """
        pass

    def __D1_adjust_setting_Modify__(self, cycle: DataFrame) -> DataFrame:  # 规定cycle为(DataFrame)类型数组，返回(DataFrame)类型数组
        """对D_adjust_setting (循环段内多次调整推进速度设定值)类异常数据进行修正
        :param cycle: 循环段数据（DataFrame）
        :return: 修正后循环段数据（DataFrame）
        """
        pass

    def __E1_missing_ratio_Modify__(self, cycle: DataFrame) -> DataFrame:  # 规定cycle为(DataFrame)类型数组，返回值为(DataFrame)类型数组
        """对E_missing_ratio (循环段内数据缺失过多)类异常数据进行修正
        :param cycle: 循环段数据（DataFrame）
        :return: 修正后循环段数据（DataFrame）
        """
        pass

    def __show_info__(self, Use_time: float, Num: list, Sum: list) -> None:
        """
        实时输出程序运行状况
        :param Use_time: 处理每个循环段数据花费的时间
        :param Num: 当前的循环段编号
        :param Sum: 总的循环段数量
        :return: 无
        """
        if self.debug:  # 若为调试模式，则不向索引文件写入内容
            return None
        cpu_percent = psutil.cpu_percent()  # CPU占用
        mem_percent = psutil.Process(os.getpid()).memory_percent()  # 内存占用
        self.Time_val.append(Use_time)  # 对每个时间差进行保存，用于计算平均时间
        mean_time = sum(self.Time_val) / len(self.Time_val)  # 计算平均时间
        sum_time = round(sum(self.Time_val) / 3600, 3)  # 计算程序执行的总时间
        remain_time = round((mean_time * (Sum[1] - Num[1] - 1)) / 3600, 3)  # 预计剩余时间计算
        print('\r   [第%d个 / 共%d个]  ' % (Num[1] + 1, Sum[1]),
              '[所用时间%ds / 平均时间%ds]  ' % (int(Use_time), int(mean_time)),
              '[CPU占用: %5.2f%% / 内存占用: %5.2f%%]  ' % (cpu_percent, mem_percent),
              '[累积运行时间: %6.3f小时 / 预计剩余时间: %6.3f小时]' % (sum_time, remain_time), end='')
        if Num[0] + 1 >= Sum[0] and Num[1] + 1 >= Sum[1]:
            print('\r-> %s \033[0;32mData-Clean completed, which took %6.3f hours\033[0m' % (self.class_name, sum_time))

    @staticmethod  # 不强制要求传递参数
    def __detail__(name=None, data=None, key=None, Parm=None, debug=False):
        """展示程序细节信息"""
        if debug:
            print("\033[0;33m{:·^100}\033[0m".format(name))
            for num, information in enumerate(key):
                print('\033[0;33m%9s\033[0m' % str(information), end='')
            print('')
            x = [i for i in range(data.shape[0])]  # 'Time'
            plt.figure(figsize=(14, 7), dpi=120)  # 设置画布大小（10cm x 8cm）及分辨率（dpi=120）
            for parm, color in zip(Parm, ['b', 'g', 'r', 'y']):
                plt.plot(x, data.iloc[:, parm], label="%s" % list(data)[parm], color=color)
            plt.legend()
            plt.xlabel("时间/s", fontsize=15)
            plt.show()
            plt.close()
            print("\033[0;33m{:·^100}\033[0m".format(name))

    def __custom_A1_premature_Modify__(self, cycle: DataFrame) -> DataFrame:
        """
        判断数据类型是不是__A1_premature__ (循环段掘进长度过短 L<0.3m)
        :param cycle: 循环段数据（DataFrame）
        :return: 异常类型（'Normal'/'A'）
        """
        # noinspection PyTypeChecker
        if self.custom_functions['clean_A1'] is not None:
            info = None
            try:
                from custom.clean_A1 import function
                return function(cycle)
            except Exception as e:
                info = f'Warning in x00411,\n' \
                       f'Custom module call failed, default module will be used, Detail error are as follows: \n{e}!!!'
            finally:
                if info is not None:
                    if self.loading is not None:
                        self.loading.set_message(message=info, type='warning')
                    else:
                        print(f'-> {self.class_name} \033[0;33m{info}\033[0m')

    def __custom_B1_mark_Modify__(self, cycle: DataFrame) -> DataFrame:
        """判断数据类型是不是__B1_markAndModify__ (循环段速度值超限 V>120mm/min)
        :param cycle: 循环段数据（DataFrame）
        :return: 异常类型（'Normal'/'B1'）
        """
        # noinspection PyTypeChecker
        if self.custom_functions['clean_B1'] is not None:
            info = None
            try:
                from custom.clean_B1 import function
                return function(cycle)
            except Exception as e:
                info = f'Warning in x00411,\n' \
                       f'Custom module call failed, default module will be used, Detail error are as follows: \n{e}!!!'
            finally:
                if info is not None:
                    if self.loading is not None:
                        self.loading.set_message(message=info, type='warning')
                    else:
                        print(f'-> {self.class_name} \033[0;33m{info}\033[0m')

    def __custom_B2_constant_Modify__(self, cycle: DataFrame) -> DataFrame:
        """判断数据类型是不是__B2_constant__ (循环段数据传输异常 刀盘推力连续5s不发生变化)
        :param cycle: 循环段数据（DataFrame）
        :return: 异常类型（'Normal'/'B2'）
        """
        # noinspection PyTypeChecker
        if self.custom_functions['clean_B2'] is not None:
            info = None
            try:
                from custom.clean_B2 import function
                return function(cycle)
            except Exception as e:
                info = f'Warning in x00411,\n' \
                       f'Custom module call failed, default module will be used, Detail error are as follows: \n{e}!!!'
            finally:
                if info is not None:
                    if self.loading is not None:
                        self.loading.set_message(message=info, type='warning')
                    else:
                        print(f'-> {self.class_name} \033[0;33m{info}\033[0m')

    def __custom_C1_sine_Modify__(self, cycle: DataFrame) -> DataFrame:
        """判断数据类型是不是__C1_sine__ (循环段刀盘扭矩出现正弦波扭矩)
        :param cycle: 循环段数据（DataFrame）
        :return: 异常类型（'Normal'/'C1'）
        """
        # noinspection PyTypeChecker
        if self.custom_functions['clean_C1'] is not None:
            info = None
            try:
                from custom.clean_C1 import function
                return function(cycle)
            except Exception as e:
                info = f'Warning in x00411,\n' \
                       f'Custom module call failed, default module will be used, Detail error are as follows: \n{e}!!!'
            finally:
                if info is not None:
                    if self.loading is not None:
                        self.loading.set_message(message=info, type='warning')
                    else:
                        print(f'-> {self.class_name} \033[0;33m{info}\033[0m')

    def __custom_C2_shutdown_Modify__(self, cycle: DataFrame) -> DataFrame:
        """判断数据类型是不是__C2_shutdown__ (循环段内机器发生短暂停机)
        :param cycle: 循环段数据（DataFrame）
        :return: 异常类型（'Normal'/'C2'）
        """
        # noinspection PyTypeChecker
        if self.custom_functions['clean_C2'] is not None:
            info = None
            try:
                from custom.clean_C2 import function
                return function(cycle)
            except Exception as e:
                info = f'Warning in x00411,\n' \
                       f'Custom module call failed, default module will be used, Detail error are as follows: \n{e}!!!'
            finally:
                if info is not None:
                    if self.loading is not None:
                        self.loading.set_message(message=info, type='warning')
                    else:
                        print(f'-> {self.class_name} \033[0;33m{info}\033[0m')

    def __custom_D1_adjust_setting_Modify__(self, cycle: DataFrame) -> DataFrame:
        """判断数据类型是不是__D1_adjust_setting__ (循环段内多次调整推进速度设定值)
        :param cycle: 循环段数据（DataFrame）
        :return: 异常类型（'Normal'/'D'）
        """
        # noinspection PyTypeChecker
        if self.custom_functions['clean_D1'] is not None:
            info = None
            try:
                from custom.clean_D1 import function
                return function(cycle)
            except Exception as e:
                info = f'Warning in x00411,\n' \
                       f'Custom module call failed, default module will be used, Detail error are as follows: \n{e}!!!'
            finally:
                if info is not None:
                    if self.loading is not None:
                        self.loading.set_message(message=info, type='warning')
                    else:
                        print(f'-> {self.class_name} \033[0;33m{info}\033[0m')

    def __custom_E1_missing_ratio_Modify__(self, cycle: DataFrame) -> DataFrame:
        """判断数据类型是不是__E1_missing_ratio__ (循环段内数据缺失过多)
        :param cycle: 循环段数据（DataFrame）
        :return: 异常类型（'Normal'/'E'）"""
        # noinspection PyTypeChecker
        if self.custom_functions['clean_E1'] is not None:
            info = None
            try:
                from custom.clean_E1 import function
                return function(cycle)
            except Exception as e:
                info = f'Warning in x00411,\n' \
                       f'Custom module call failed, default module will be used, Detail error are as follows: \n{e}!!!'
            finally:
                if info is not None:
                    if self.loading is not None:
                        self.loading.set_message(message=info, type='warning')
                    else:
                        print(f'-> {self.class_name} \033[0;33m{info}\033[0m')

    def main(self) -> None:  # 规定返回值无类型限定/无返回值
        """将数据类型进行汇总并保存"""
        # noinspection PyBroadException
        try:
            self.__check_parm__()  # 检查参数是否正常
            self.__create_clean_Dir__()  # 创建相关文件夹
            self.__prepare_custom_function__(option='add')  # 准备自定义函数
            all_dir = os.listdir(self.input)  # 获取输入文件夹下的所有文件夹名称，并将其保存
            mission_count = sum([len(files) for root, dirs, files in os.walk(self.input)])
            self.loading.set_process(key='detail-sum', value=mission_count) if self.loading is not None else None
            self.loading.set_process(key='total-count', file='CLEAN') if self.loading is not None else None
            for dir_num, (Key, Dir) in enumerate(zip(list(self.SUB_FOLDERS.keys()), all_dir)):
                all_file = os.listdir(os.path.join(self.input, Dir))  # 获取输入文件夹下的所有文件名称，并将其保存
                all_file.sort(key=lambda x: int(x[:5]))  # 对读取的文件列表进行重新排序
                for file_num, file in enumerate(all_file):  # 遍历输入文件夹下的所有子文件夹
                    while self.loading is not None and self.loading.get_state():
                        time.sleep(1)
                    time_S = time.time()  # 记录程序执行开始时间
                    local_csv_path = os.path.join(self.input, Dir, file)  # 当前文件路径
                    target_csv_path = os.path.join(self.out, self.SUB_FOLDERS[Key], file)  # 目标文件路径
                    try:
                        data = pd.read_csv(local_csv_path, encoding='gb2312')  # 读取异常循环段数据，编码为'gb2312'
                    except UnicodeDecodeError:
                        data = pd.read_csv(local_csv_path)  # 读取异常循环段数据，编码为默认
                    self.__check_index__(list(data))  # 检查参数是否重复
                    # noinspection PyBroadException
                    try:
                        function = {'A1': None, 'B1': None, 'B2': None, 'C1': None, 'C2': None, 'D1': None, 'E1': None,
                                    'Unknown': None, 'Normal': None}  # 保存修正后循环段数据
                        if self.default_function['A1']:  # 检查是否需要开启该功能
                            function['A1'] = self.__custom_A1_premature_Modify__(data)  # 调用自定义函数
                            if function['A1'] is None:
                                function['A1'] = self.__A1_premature_Modify__(data)  # 调用默认函数
                        if self.default_function['B1']:  # 检查是否需要开启该功能
                            function['B1'] = self.__custom_B1_mark_Modify__(data)  # 调用自定义函数
                            if function['B1'] is None:
                                function['B1'] = self.__B1_mark_Modify__(data)  # 调用默认函数
                        if self.default_function['B2']:  # 检查是否需要开启该功能
                            function['B2'] = self.__custom_B2_constant_Modify__(data)  # 调用自定义函数
                            if function['B2'] is None:
                                function['B2'] = self.__B2_constant_Modify__(data)  # 调用默认函数
                        if self.default_function['C1']:  # 检查是否需要开启该功能
                            function['C1'] = self.__custom_C1_sine_Modify__(data)  # 调用自定义函数
                            if function['C1'] is None:
                                function['C1'] = self.__C1_sine_Modify__(data)  # 调用默认函数
                        if self.default_function['C2']:  # 检查是否需要开启该功能
                            function['C2'] = self.__custom_C2_shutdown_Modify__(data)  # 调用自定义函数
                            if function['C2'] is None:
                                function['C2'] = self.__C2_shutdown_Modify__(data)  # 调用默认函数
                        if self.default_function['D1']:  # 检查是否需要开启该功能
                            function['D1'] = self.__custom_D1_adjust_setting_Modify__(data)  # 调用自定义函数
                            if function['D1'] is None:
                                function['D1'] = self.__D1_adjust_setting_Modify__(data)  # 调用默认函数
                        if self.default_function['E1']:  # 检查是否需要开启该功能
                            function['E1'] = self.__custom_E1_missing_ratio_Modify__(data)  # 调用自定义函数
                            if function['E1'] is None:
                                function['E1'] = self.__E1_missing_ratio_Modify__(data)  # 调用默认函数
                        if function[Key] is not None:  # 调用相对应的修正函数对异常数据进行修正
                            function[Key].to_csv(target_csv_path, index=False, encoding='gb2312')  # 保存修正后'A'类循环段数据
                            self.__write_index__({'循环段': file, 'Type': Key})  # 修正索引文件
                            self.__detail__(name=file, data=data, key=['循环段修正：'] + ['%s  ->  修正为  ->  Normal' % Key],
                                            Parm=self.parm[3:7], debug=self.debug)  # 显示细节信息
                        if Key == 'Normal':
                            shutil.copyfile(local_csv_path, target_csv_path)  # 将正常循环段数据复制到'Normclass-data'文件夹
                    except Exception as e:
                        if self.loading is not None:
                            self.loading.set_message(message=f'-> {self.class_name} {e}', type='message')
                        else:
                            print(f'-> {self.class_name} \033[0;31m{e}\033[0m')
                    time_F = time.time()  # 记录程序执行结束时间
                    if self.loading is not None:
                        self.loading.set_process(key='detail-count', file=file)
                    else:
                        self.__show_info__(Use_time=time_F - time_S, Num=[dir_num, file_num],
                                           Sum=[len(all_dir), len(all_file)])
        except Exception:
            if self.loading is not None:
                self.loading.set_message(message=traceback.format_exc(), type='error')
            else:
                print(f'-> {self.class_name} \033[0;31m{traceback.format_exc()}\033[0m')
        finally:
            self.__prepare_custom_function__(option='del')


if __name__ == "__main__":
    TBM_CLEAN(input_path=r'D:\17339902814\OneDrive\桌面\test\class',
              out_path=r'D:\17339902814\OneDrive\桌面\test\clean',
              index_path=r'D:\17339902814\OneDrive\桌面\test\index.csv',
              parameter=[0, 1, 23, 5, 7, 2, 8, 3, 4, 6, 1],
              Run=True)
