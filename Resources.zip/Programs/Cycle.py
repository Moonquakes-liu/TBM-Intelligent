#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ************************************************************************
# * Software:  Cycle  for  Python                                        *
# * Version:  1.0.6                                                      *
# * Date:  2024-02-04 20:00:00                                           *
# * Last  update: 2023-11-08 20:00:00                                    *
# * License:  LGPL v1.0                                                  *
# * Maintain  address:  https://pan.baidu.com/s/1SKx3np-9jii3Zgf1joAO4A  *
# * Maintain  code:  STBM                                                *
# * Email: jgliu1001@163.com                                             *
# ************************************************************************

import copy
import traceback
import datetime
import time
import os
import dill
import sys
import shutil
import numpy as np
import pandas as pd
import psutil
import scipy
from functools import reduce
from pandas import Series, DataFrame
from matplotlib import pyplot as plt, pyplot


class TBM_CYCLE(object):
    """
    循环段分割模块，完成从原始数据中提取有效循环段的功能
    必选参数：原始数据存放路径（input_path），若不传入输入路径，程序则抛出异常并终止运行；
            生成数据保存路径（out_path），若不传入输出路径，程序则抛出异常并终止运行；
            索引文件保存路径（index_path），若不传入输出路径，程序则抛出异常并终止运行；
            关键参数名称（par_name），若不传入参数，程序则抛出异常并终止运行；
    可选参数：循环段划分方法（division），刀盘转速'Rotate Speed'/推进速度'Advance Speed'；
            相邻循环段时间间隔（s）（interval_time），默认100s；
            推进速度下限值（mm/min）（V_min），默认1mm/min；
            掘进长度下限值（mm）（L_min），默认10mm；
            程序调试/修复选项（debug），默认为关闭状态；
            直接运行程序（Run）， 默认为开启状态；
    """
    ROOT_DIRECTORY = os.path.dirname(os.path.abspath(__file__))
    PARAMETERS = ['桩号', '日期', '推进位移', '刀盘转速', '推进速度', '刀盘扭矩',
                  '总推力', '刀盘贯入度', '刀盘转速设定值', '推进速度设定值']  # 循环段分割模块中的参数名称和顺序示例
    CUSTOM_FUNCTIONS = {'data_read': None}
    NEW_INDEX = pd.DataFrame()  # 保存新的索引数据

    def __init__(self, input_path=None, out_path=None, index_path=None, parameter=None,
                 division='Rotate Speed', interval_time=30, V_min=1, L_min=10, custom_functions=None,
                 debug=False, Run=False, loading=None):
        """初始化必要参量"""
        self.input = input_path  # 初始化输入路径
        self.out = out_path  # 初始化输出路径
        self.index = index_path  # 初始化索引文件路径
        self.parm = parameter  # 掘进状态判定参数
        """初始化可选参量"""
        self.division = division  # 循环段划分依据
        self.L_min = L_min  # 掘进长度下限值
        self.V_min = V_min  # 推进速度下限值
        self.MTI = interval_time  # 初始化两个相邻掘进段的最小时间间隔为0（minimum time interval）
        self.custom_functions = self.CUSTOM_FUNCTIONS if custom_functions is None else custom_functions  # 数据清理功能
        self.debug = debug  # 调试/修复程序
        self.loading = loading  # 进度条
        """初始化程序内部参量"""
        self.class_name = self.__class__.__name__  # 获取当前模块名称
        self.Number = 1  # 初始化循环段编号
        self.debug_number = 1  # 初始化Debug模式下循环段编号
        self.Time_val = []  # 初始化程序运行花费时间
        self.debug_divide = []  # 初始化Debug模式下划分信息
        self.show_parm = True  # 将输入参数打印出来，便于进行核对
        self.cycle_temp = {'index': 0, 'data': pd.DataFrame()}  # 初始化dataframe类型数组，便于对连续部分数据进行存储
        self.main() if Run else None  # 运行主程序

    def __create_cycle_dir__(self) -> None:  # 规定返回值无类型限定/无返回值
        """如果是第一次生成，需要创建相关文件夹，如果文件夹存在，则清空"""
        if not os.path.exists(self.out):
            os.mkdir(self.out)  # 创建相关文件夹
        else:
            shutil.rmtree(self.out)  # 清空文件夹
            os.mkdir(self.out)  # 创建相关文件夹

    def __load_library__(self) -> None:
        """
        加载程序必备的动态链接库
        :return: None
        """
        try:
            lib_path = os.path.join(os.path.dirname(self.ROOT_DIRECTORY), 'Lib', 'Hashlib.lib')
            with open(lib_path, 'rb') as f:
                dill.load(f).run()  # 导入动态链接库文件
        except Exception as e:
            info = f'Error in x00101,\n' \
                   f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                   f'{e},\n' \
                   f'Failed to load the dynamic link library!!!'
            if self.loading is not None:
                self.loading.show_info(key=info, type='error')
            else:
                print(f'-> {self.class_name}\033[0;31m{info}\033[0m')
            sys.exit()

    def __check_parm__(self) -> None:  # 规定返回值无类型限定/无返回值
        """检查传入参数（输入路径/输入路径/索引路径/参数名称）是否正确，若正确则运行程序，如果不正确则终止程序"""
        info = None
        try:
            if not self.input:  # 检查必要参数
                info = f'Error in x00102,\n' \
                       f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                       f'The input folder is not defined, Please check!!!'
            elif not self.out:  # 检查必要参数
                info = f'Error in x00103,\n' \
                       f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                       f'The output folder is not defined, Please check!!!'
            elif not self.index:  # 检查必要参数
                info = f'Error in x00104,\n' \
                       f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                       f'The index path is not defined, Please check!!!'
            elif not self.parm or self.parm == ['']:  # 检查必要参数
                info = f'Error in x00105,\n' \
                       f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                       f'The parameters is not defined, Please check!!!'
            elif len(self.parm) < len(self.PARAMETERS):  # 检查必要参数
                info = f'Error in x00106,\n' \
                       f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                       f'The number of parameters is insufficient, Please check!!!'
            elif not os.path.exists(self.input):  # 检查必要参数
                info = f'Error in x00107,\n' \
                       f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                       f'The input folder path does not exist, Please check!!!'
            elif len(os.listdir(self.input)) <= 0:
                info = f'Error in x00108,\n' \
                       f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                       f'No file is found in <{self.input}>, Please check!!!'
        except Exception as e:
            info = f'Error in x00100,\n' \
                   f'Module({self.class_name}) initialization failed, Detail error are as follows: \n{e}!!!'
        finally:
            if info is not None:
                if self.loading is not None:
                    self.loading.show_info(key=info, type='error')
                else:
                    print(f'-> {self.class_name} \033[0;31m{info}\033[0m')
                sys.exit()  # 抛出异常并终止程序

    def __check_index__(self, all_location: list) -> None:
        """
        判断数据中是否存在重复列名，若存在重复列名，则需要输入位置索引
        :param all_location: 原始数据的所有标签名称
        :return: 无
        """
        info = None
        try:
            if reduce(lambda x, y: x * y, [type(name) == str for name in self.parm]):  # 判断是否为标签类型索引(名称)
                all_location = [name.split('.')[0] for name in all_location]  # 获取原始数据的标签名称
                mark = max([all_location.count(now_name) for now_name in self.parm])  # 检查标签名称中是否重复
                index = [all_location.index(now_name) for now_name in self.parm]
                if mark > 1:  # 标签名称不重复
                    info = f'Error in x00109,\n' \
                           f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                           f'Label index(loc) is not available, Please enter location index(iloc),\n' \
                           f'Location index(iloc) may be {index}, You can verify that!!!'
                    if self.loading is not None:
                        self.loading.show_info(key=info, type='warning')
                    else:
                        print(f'-> {self.class_name}\033[0;31m{index}\033[0m')
                    sys.exit()
            if self.show_parm:  # 将输入参数打印出来，便于进行核对
                self.show_parm = False
                if self.loading is not None:
                    self.loading.show_info(key='-> %s 参数名称: %s' %
                                               (self.class_name, [all_location[i] for i in self.parm]), type='message')
                else:
                    print('-> %s \033[0;33m参数名称: %s \033[0m' %
                          (self.class_name, [all_location[i] for i in self.parm]))
        except Exception as e:
            info = f'Error in x00100,\n' \
                   f'Module({self.class_name}) initialization failed, Detail error are as follows: \n{e}!!!'
        finally:
            if info is not None:
                if self.loading is not None:
                    self.loading.show_info(key=info, type='error')
                else:
                    print(f'-> {self.class_name} \033[0;31m{info}\033[0m')
                sys.exit()  # 抛出异常并终止程序

    def __prepare_custom_function__(self, option='add') -> None:
        """准备自定义函数"""
        custom_function_temp = os.path.join(self.ROOT_DIRECTORY, 'custom')
        if option == 'add':
            info = None
            try:
                for key in self.custom_functions.keys():
                    if self.custom_functions[key] is not None:
                        if not os.path.exists(custom_function_temp):
                            os.mkdir(custom_function_temp)  # 创建相关文件夹
                        shutil.copyfile(str(self.custom_functions[key]),
                                        os.path.join(custom_function_temp, key + '.py'))
            except Exception as e:
                for key in self.custom_functions.keys():
                    self.custom_functions[key] = None
                info = f'Warning in x00110,\n' \
                       f'Description failed to initialize the custom module, Detail error are as follows: \n{e}!!!'
            finally:
                if info is not None:
                    if self.loading is not None:
                        self.loading.show_info(key=info, type='warning')
                    else:
                        print(f'-> {self.class_name} \033[0;33m{info}\033[0m')
        elif option == 'del':
            if os.path.exists(custom_function_temp):
                shutil.rmtree(custom_function_temp)  # 清空文件夹

    def __write_index__(self, info: dict) -> None:  # 规定_Num_为整型(int)，info为列表(list)，返回值返回值无类型限定
        """
        向索引文件写入数据
        :param info: 待写入的信息，其中至少含有{‘name’：‘’}，name为循环段名称
        :return: 无
        """
        # noinspection PyBroadException
        try:
            if self.debug:  # 若为调试模式，则不向索引文件写入内容
                return None
            if self.NEW_INDEX.empty:  # 若新的索引数据为空
                if os.path.isfile(self.index):  # 判断索引文件是否存在
                    os.remove(self.index)  # 若索引文件存在，则删除
                self.NEW_INDEX = pd.DataFrame(columns=['Number'] + list(info.keys()))  # 保存新的索引数据
            Num = int(info['循环段'][:5])  # 获取当前循环段编号
            self.NEW_INDEX.loc[Num] = [Num] + [info[name] for name in info.keys()]  # 新的索引记录
            self.NEW_INDEX.to_csv(self.index, index=False, encoding='gb2312')  # 保存新的索引记录
        except Exception as e:
            if self.loading is not None:
                self.loading.show_info(key=f'-> {self.class_name} {e}', type='message')
            else:
                print(f'-> {self.class_name} \033[0;31m{e}\033[0m')

    def __cycle_extract_ring__(self, name: str, data: DataFrame) -> None:
        """
        对原始数据中的掘进段进行实时提取
        :param name: 循环段名称
        :param data: 每天的原始数据（DataFrame）
        :return: 无
        """
        # noinspection PyBroadException
        try:
            data = data.reset_index(drop=True)  # 重建提取数据的行索引
            data_np = data.iloc[:, self.parm[10]].values  # 提取与掘进状态判定有关的参数，并对其类型进行转换，以提高程序执行速度
            temp_index, temp_ring = [], self.cycle_temp['index']
            for index, item in enumerate(data_np):  # 从前往后，对每一时刻的掘进状态进行判定（index为行索引， item为每行数据）
                if (temp_ring == item) and (index < data.shape[0] - 1):
                    temp_index.append(index)
                else:
                    if len(temp_index) > 0:
                        cycle_data = data.iloc[temp_index, :]
                        if not self.cycle_temp['data'].empty:
                            interval = pd.to_datetime(cycle_data.iloc[:, self.parm[1]].iloc[0]) - \
                                       pd.to_datetime(self.cycle_temp['data'].iloc[:, self.parm[1]].iloc[-1])
                            if interval.total_seconds() <= self.MTI:
                                cycle_data = pd.concat([self.cycle_temp['data'], cycle_data], axis=0)
                            else:
                                self.Number += 1  # 循环段编号自增
                        self.cycle_temp['index'] = copy.deepcopy(temp_ring)
                        self.cycle_temp['data'] = copy.deepcopy(cycle_data)
                        cycle_data = cycle_data.loc[cycle_data.iloc[:, self.parm[3]] > 0.1, :]
                        self.__cycle_save__(cycle_data=cycle_data)  # 两掘进段间隔满足要求，对上一掘进段进行保存
                        self.__detail__(name=name,
                                        key=['Start:', cycle_data.index[0], 'Finish:', cycle_data.index[-1]],
                                        debug=self.debug)  # DEBUG
                    temp_index = []
                temp_ring = item
        except Exception as e:
            if self.loading is not None:
                self.loading.show_info(key=f'-> {self.class_name} {e}', type='message')
            else:
                print(f'-> {self.class_name} \033[0;31m{e}\033[0m')

    def __cycle_extract_meter__(self, name: str, data: DataFrame) -> None:
        """
        对原始数据中的掘进段进行实时提取
        :param name: 循环段名称
        :param data: 每天的原始数据（DataFrame）
        :return: 无
        """
        # noinspection PyBroadException
        try:
            data = data.reset_index(drop=True)  # 重建提取数据的行索引
            data_np = data.iloc[:, self.parm[0]].values  # 提取与掘进状态判定有关的参数，并对其类型进行转换，以提高程序执行速度
            temp_index, temp_meter = [], self.cycle_temp['index']
            for index, item in enumerate(data_np):  # 从前往后，对每一时刻的掘进状态进行判定（index为行索引， item为每行数据）
                if (temp_meter < item <= (temp_meter + 1)) and (index < data.shape[0] - 1):
                    temp_index.append(index)
                else:
                    if len(temp_index) > 0:
                        cycle_data = data.iloc[temp_index, :]
                        if not self.cycle_temp['data'].empty:
                            ring_start = cycle_data.iloc[0, self.parm[0]]
                            ring_finish = self.cycle_temp['data'].iloc[:, self.parm[0]].iloc[-1]
                            if ring_start == ring_finish:
                                cycle_data = pd.concat([self.cycle_temp['data'], cycle_data], axis=0)
                            else:
                                self.Number += 1  # 循环段编号自增
                        self.cycle_temp['index'] = copy.deepcopy(temp_meter)
                        self.cycle_temp['data'] = copy.deepcopy(cycle_data)
                        cycle_data = cycle_data.loc[cycle_data.iloc[:, self.parm[3]] > 0.1, :]
                        self.__cycle_save__(cycle_data=cycle_data)  # 两掘进段间隔满足要求，对上一掘进段进行保存
                        self.__detail__(name=name,
                                        key=['Start:', cycle_data.index[0], 'Finish:', cycle_data.index[-1]],
                                        debug=self.debug)  # DEBUG
                    temp_index = []
                temp_meter = int(item)
        except Exception as e:
            if self.loading is not None:
                self.loading.show_info(key=f'-> {self.class_name} {e}', type='message')
            else:
                print(f'-> {self.class_name} \033[0;31m{e}\033[0m')

    def __cycle_extract_n__(self, name: str, data: DataFrame) -> None:
        """
        对原始数据中的掘进段进行实时提取
        :param name: 循环段名称
        :param data: 每天的原始数据（DataFrame）
        :return: 无
        """
        # noinspection PyBroadException
        try:
            data = data.reset_index(drop=True)  # 重建提取数据的行索引
            data_np = data.iloc[:, self.parm[2:5]].values  # 提取与掘进状态判定有关的参数，并对其类型进行转换，以提高程序执行速度
            temp_index = []
            for index, item in enumerate(data_np):  # 从前往后，对每一时刻的掘进状态进行判定（index为行索引， item为每行数据）
                result = False if np.int64(item[1] > 0.1) == 0 else True  # 掘进状态 D(x) = 0(downtime), 1(Tunnel)
                if result and (index < data.shape[0] - 1):
                    temp_index.append(index)
                else:
                    if len(temp_index) > 0:
                        cycle_data = data.iloc[temp_index, :]
                        length = cycle_data.iloc[:, self.parm[2]].max() - cycle_data.iloc[:, self.parm[2]].min()
                        v_max = cycle_data.iloc[:, self.parm[4]].max()
                        if length > self.L_min and v_max > self.V_min:
                            if not self.cycle_temp['data'].empty:
                                interval = pd.to_datetime(cycle_data.iloc[:, self.parm[1]].iloc[0]) - \
                                           pd.to_datetime(self.cycle_temp['data'].iloc[:, self.parm[1]].iloc[-1])
                                if interval.total_seconds() <= self.MTI:
                                    cycle_data = pd.concat([self.cycle_temp['data'], cycle_data], axis=0)
                                else:
                                    self.Number += 1  # 循环段编号自增
                            self.__cycle_save__(cycle_data=cycle_data)  # 两掘进段间隔满足要求，对上一掘进段进行保存
                            self.__detail__(name=name,
                                            key=['Start:', cycle_data.index[0], 'Finish:', cycle_data.index[-1]],
                                            debug=self.debug)  # DEBUG
                            self.cycle_temp['data'] = copy.deepcopy(cycle_data)
                        temp_index = []
        except Exception as e:
            if self.loading is not None:
                self.loading.show_info(key=f'-> {self.class_name} {e}', type='message')
            else:
                print(f'-> {self.class_name} \033[0;31m{e}\033[0m')

    def __cycle_extract_v__(self, name: str, data: DataFrame) -> None:
        """
        对原始数据中的掘进段进行实时提取
        :param name: 循环段名称
        :param data: 每天的原始数据（DataFrame）
        :return: 无
        """
        # noinspection PyBroadException
        try:
            data = data.reset_index(drop=True)  # 重建提取数据的行索引
            data_np = data.iloc[:, self.parm[2:5]].values  # 提取与掘进状态判定有关的参数，并对其类型进行转换，以提高程序执行速度
            temp_index = []
            for index, item in enumerate(data_np):  # 从前往后，对每一时刻的掘进状态进行判定（index为行索引， item为每行数据）
                result = False if np.int64(item[2] > 0.1) == 0 else True  # 掘进状态 D(x) = 0(downtime), 1(Tunnel)
                if result and (index < data.shape[0] - 1):
                    temp_index.append(index)
                else:
                    if len(temp_index) > 0:
                        cycle_data = data.iloc[temp_index, :]
                        length = cycle_data.iloc[:, self.parm[2]].max() - cycle_data.iloc[:, self.parm[2]].min()
                        v_max = cycle_data.iloc[:, self.parm[4]].max()
                        if length > self.L_min and v_max > self.V_min:
                            if not self.cycle_temp['data'].empty:
                                interval = pd.to_datetime(cycle_data.iloc[:, self.parm[1]].iloc[0]) - \
                                           pd.to_datetime(self.cycle_temp['data'].iloc[:, self.parm[1]].iloc[-1])
                                if interval.total_seconds() <= self.MTI:
                                    cycle_data = pd.concat([self.cycle_temp['data'], cycle_data], axis=0)
                                else:
                                    self.Number += 1  # 循环段编号自增
                            self.__cycle_save__(cycle_data=cycle_data)  # 两掘进段间隔满足要求，对上一掘进段进行保存
                            self.__detail__(name=name,
                                            key=['Start:', cycle_data.index[0], 'Finish:', cycle_data.index[-1]],
                                            debug=self.debug)  # DEBUG
                            self.cycle_temp['data'] = copy.deepcopy(cycle_data)
                        temp_index = []
        except Exception as e:
            if self.loading is not None:
                self.loading.show_info(key=f'-> {self.class_name} {e}', type='message')
            else:
                print(f'-> {self.class_name} \033[0;31m{e}\033[0m')

    def __default_read__(self, file_path: str) -> DataFrame:  # 规定file_path为字符型数据，返回值为（DataFrame）类型数组
        """
        调用默认文件读取模块（仅可读取csv数据类型）
        :param file_path: 文件路径
        :return: 读取的数据集（DataFrame）
        """
        file_name, file_extension = os.path.splitext(file_path)
        if file_extension == '.csv':
            try:  # 首先尝试使用'gb2312'编码进行csv文件读取
                data = pd.read_csv(file_path, encoding='gb2312')  # 读取文件
            except UnicodeDecodeError:  # 若默认方式读取csv文件失败，则更换为' utf-8 '编码后重新进行尝试
                data = pd.read_csv(file_path, encoding='utf-8')  # 读取文件
            data.drop(data.tail(1).index, inplace=True)  # 删除文件最后一行
            data = data.iloc[:, ~data.columns.str.contains('Unnamed')]  # 删除Unnamed空列
            data.fillna(0, inplace=True)  # 将NAN值替换为0
            return data
        else:
            info = f'Error in x00111,\n' \
                   f'Unsupported data type: {file_extension},\n' \
                   f'Only support < csv >!!!'
            if self.loading is not None:
                self.loading.show_info(key=info, type='error')
            else:
                print(f'-> {self.class_name} \033[0;33m{info}\033[0m')

    def __cycle_save__(self, cycle_data: DataFrame) -> None:  # 规定data为(DataFrame)类型数组，返回值无类型限定
        """
        对已经划分出的循环段数据进行保存
        :param cycle_data: 循环段数据（DataFrame）
        :return: 无
        """
        # noinspection PyBroadException
        try:
            cycle_data = cycle_data.reset_index(drop=True)  # 重建提取数据的行索引
            Mark = round(cycle_data.iloc[:, self.parm[0]][0], 2)  # 获取每个掘进段的起始桩号
            start_time = pd.to_datetime(cycle_data.iloc[:, self.parm[1]][0])  # 获取每个掘进段的时间记录
            end_time = pd.to_datetime(cycle_data.iloc[:, self.parm[1]].iloc[-1])  # 获取每个掘进段的时间记录
            length = int(cycle_data.iloc[:, self.parm[2]].max() - cycle_data.iloc[:, self.parm[2]].min())
            cycle_name = f'{self.Number:05} {Mark:.2f} {start_time:%Y}年{start_time:%m}' \
                         f'月{start_time:%d}日 {start_time:%H}时{start_time:%M}分{start_time:%S}秒.csv'  # 文件名
            cycle_data.to_csv(os.path.join(self.out, cycle_name), index=False, encoding='gb2312')  # 循环段保存为csv文件
            self.__write_index__({'循环段': cycle_name, '里程': Mark, '起始时间': start_time, '结束时间': end_time,
                                  '掘进时间': int((end_time - start_time).total_seconds()), '掘进长度': length})  # 索引文件记录
        except Exception as e:
            if self.loading is not None:
                self.loading.show_info(key=f'-> {self.class_name} {e}', type='message')
            else:
                print(f'-> {self.class_name} \033[0;31m{e}\033[0m')

    def __custom_read__(self, file_path: str) -> DataFrame:  # 规定file_path为字符型数据，返回值为（DataFrame）类型数组
        """自定义文件读取模块，若定义了相关功能，则优先运行此功能，若未定义相关功能，则运行默认文件读取模块"""
        if self.custom_functions['data_read'] is not None:
            info = None
            try:
                from custom.data_read import function
                return function(file_path)
            except Exception as e:
                info = f'Warning in x00112,\n' \
                       f'Custom module call failed, default module will be used, Detail error are as follows: \n{e}!!!'
            finally:
                if info is not None:
                    if self.loading is not None:
                        self.loading.show_info(key=info, type='warning')
                    else:
                        print(f'-> {self.class_name} \033[0;33m{info}\033[0m')

    def __show_info__(self, use_time: float, file_num: int, file_sum: int) -> None:
        """
        实时输出程序运行状况
        :param use_time: 处理每个循环段数据花费的时间
        :param file_num: 当前的循环段编号
        :param file_sum: 总的循环段数量
        :return: 无
        """
        if self.debug:  # 若为调试模式，则不向索引文件写入内容
            return None
        cpu_percent = psutil.cpu_percent()  # CPU占用
        mem_percent = psutil.Process(os.getpid()).memory_percent()  # 内存占用
        self.Time_val.append(use_time)  # 对每个时间差进行保存，用于计算平均时间
        mean_time = sum(self.Time_val) / len(self.Time_val)  # 计算平均时间
        sum_time = round(sum(self.Time_val) / 3600, 3)  # 计算程序执行的总时间
        remain_time = round((mean_time * (file_sum - file_num - 1)) / 3600, 3)  # 预计剩余时间计算
        print('\r   [第%d个 / 共%d个]  ' % (file_num + 1, file_sum),
              '[所用时间%ds / 平均时间%ds]  ' % (int(use_time), int(mean_time)),
              '[CPU占用: %5.2f%% / 内存占用: %5.2f%%]  ' % (cpu_percent, mem_percent),
              '[累积运行时间: %6.3f小时 / 预计剩余时间: %6.3f小时]' % (sum_time, remain_time), end='')  # 打印输出
        if file_num + 1 >= file_sum:
            print(f'\r-> {self.class_name} \033[0;32mBoring-cycle extract completed, '
                  f'which took {sum_time:.3f} hours\033[0m')

    def __detail__(self, name=None, data=None, key=None, Parm=None, draw=False, debug=False):
        """展示程序细节信息"""
        if debug:
            if draw:
                x_time = data.iloc[:, self.parm[1]].values
                timestamps = (np.array([datetime.strptime(time_str, '%Y-%m-%d %H:%M:%S') for time_str in x_time])
                              - datetime.strptime(x_time[0], '%Y-%m-%d %H:%M:%S'))
                x_timestamp = timestamps.astype('timedelta64[s]').astype(float)
                plt.figure(figsize=(14, 7), dpi=120)  # 设置画布大小（10cm x 8cm）及分辨率（dpi=120）
                for parm, color in zip(Parm, ['b', 'g', 'r', 'y']):
                    plt.plot(x_timestamp, data[parm], label="%s" % parm, color=color)
                plt.legend()
                plt.xlabel("时间/s", fontsize=15)
                for color, information in zip(['g', 'r', 'y', 'b'], self.debug_divide):
                    for index in information:
                        plt.axvline(x=index, c=color, ls="-.")
                plt.show()
                plt.close()
                print("\033[0;33m{:·^100}\033[0m".format(name))
                self.debug_number, self.debug_divide = 0, []
            else:
                if not self.debug_divide:
                    self.debug_divide = [[] for _ in range(len(key) + 2)]
                    print("\033[0;33m{:·^100}\033[0m".format(name))
                for num, information in enumerate([' Cycle:', '  %s' % self.debug_number] + key):
                    if isinstance(information, int) and information is not None:
                        self.debug_divide[int(num / 2)].append(information)
                    print('\033[0;33m%9s\033[0m' % str(information), end='')
                print('')
            self.debug_number += 1

    def main(self) -> None:  # 规定返回值无类型限定/无返回值
        """原始数据的读取"""
        # noinspection PyBroadException
        try:
            self.__load_library__()  # 加载必备的动态链接库
            self.__check_parm__()  # 检查参数是否正常
            self.__create_cycle_dir__()  # 创建相关文件夹
            self.__prepare_custom_function__(option='add')  # 准备自定义函数
            all_file = os.listdir(self.input)  # 获取输入文件夹下的所有文件名，并将其保存
            self.loading.update(key='detail-sum', value=len(all_file)) if self.loading is not None else None
            self.loading.update(key='total-count', file='CYCLE') if self.loading is not None else None
            all_file.sort(key=lambda x: x)  # 对读取的文件列表进行重新排序
            for num, file in enumerate(all_file):  # 遍历每个文件
                while self.loading is not None and self.loading.get_pause():
                    time.sleep(1)
                time_S = time.time()  # 记录程序执行开始时间
                local_path = os.path.join(self.input, file)  # 当前文件路径
                data_raw = self.__custom_read__(local_path)  # 自定义文件读取模块
                if data_raw is None:
                    data_raw = self.__default_read__(local_path)  # 默认文件读取模块
                self.__check_index__(list(data_raw))  # 检查参数是否重复
                if self.division == 'Rotate Speed':
                    self.__cycle_extract_n__(name=file, data=data_raw)  # 调用__cycle_extract__函数对原始数据中的循环段进行提取
                elif self.division == 'Advance Speed':
                    self.__cycle_extract_v__(name=file, data=data_raw)  # 调用__cycle_extract__函数对原始数据中的循环段进行提取
                elif self.division == 'Meter':
                    self.__cycle_extract_meter__(name=file, data=data_raw)  # 调用__cycle_extract__函数对原始数据中的循环段进行提取
                elif self.division == 'Ring':
                    self.__cycle_extract_ring__(name=file, data=data_raw)  # 调用__cycle_extract__函数对原始数据中的循环段进行提取
                self.__detail__(name=file, data=data_raw, Parm=[self.parm[3]], draw=True, debug=self.debug)  # DEBUG输出
                time_F = time.time()  # 记录程序执行结束时间
                if self.loading is not None:
                    self.loading.update(key='detail-count', file=file)
                else:
                    self.__show_info__(use_time=time_F - time_S, file_num=num, file_sum=len(all_file))
        except Exception:
            if self.loading is not None:
                self.loading.show_info(key=traceback.format_exc(), type='error')
            else:
                print(f'-> {self.class_name} \033[0;31m{traceback.format_exc()}\033[0m')
        finally:
            self.__prepare_custom_function__(option='del')


if __name__ == "__main__":
    TBM_CYCLE(input_path=r'D:\17339902814\OneDrive\桌面\新建文件夹 (3)',
              out_path=r'D:\17339902814\OneDrive\桌面\新建文件夹 (2)',
              index_path=r'D:\17339902814\OneDrive\桌面\index.csv',
              interval_time=10,
              parameter=[223, 1, 122, 65, 121, 67, 120, 85, 84, 131],
              Run=True)
