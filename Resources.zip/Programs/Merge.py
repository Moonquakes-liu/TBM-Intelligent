#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ************************************************************************
# * Software:  Merge  for  Python                                        *
# * Version:  1.0.6                                                      *
# * Date:  2024-02-04 20:00:00                                           *
# * Last  update: 2023-11-08 20:00:00                                    *
# * License:  LGPL v1.0                                                  *
# * Maintain  address:  https://pan.baidu.com/s/1SKx3np-9jii3Zgf1joAO4A  *
# * Maintain  code:  STBM                                                *
# * Email: jgliu1001@163.com                                             *
# ************************************************************************

import copy
import runpy
import traceback
import datetime
import time
import tarfile
import os
import sys
import shutil
import numpy as np
import pandas as pd
import psutil
from functools import reduce
from numpy import ndarray
from pandas import Series, DataFrame


class TBM_MERGE(object):
    """
    修正后数据合并模块，主要完成将修正后的数据集合并的工作
    ****必选参数：原始数据存放路径（input_path），若不传入输入路径，程序则抛出异常并终止运行
                生成数据保存路径（out_path），若不传入输入路径，程序则抛出异常并终止运行
                索引文件保存路径（index_path），若不传入输出路径，程序则抛出异常并终止运行
                程序运行所需要的关键参数名称（par_name），若不传入参数，程序则会终止运行
    ****可选参数：程序调试/修复选项（debug），默认为关闭状态
                直接运行程序（Run）， 默认为开启状态
    """
    ROOT_DIRECTORY = os.path.dirname(os.path.abspath(__file__))
    PARAMETERS = ['None']  # 默认参数示例
    CUSTOM_FUNCTIONS = {}
    RAW_INDEX = pd.DataFrame()  # 保存原始索引数据

    def __init__(self, input_path=None, out_path=None, index_path=None, parameter=None,
                 custom_functions=None,
                 debug=False, Run=False, loading=None):
        """初始化必要参量"""
        self.input = input_path  # 初始化输入路径
        self.out = out_path  # 初始化输出路径
        self.index = index_path  # 初始化索引文件路径
        self.parm = parameter  # 过程中用到的相关参数
        """初始化可选参量"""
        self.custom_functions = self.CUSTOM_FUNCTIONS if custom_functions is None else custom_functions  # 数据清理功能
        self.debug = debug  # 调试/修复程序
        self.loading = loading  # 进度条
        """初始化程序内部参量"""
        self.class_name = self.__class__.__name__  # 获取当前模块名称
        self.Time_val = []  # 初始化程序运行花费时间
        self.show_parm = True  # 将输入参数大音出来，便于进行核对
        None if not Run else self.main()  # 运行主程序

    def __create_merge_Dir__(self) -> None:  # 规定返回值无类型限定/无返回值
        """如果是第一次生成，需要创建相关文件夹，如果文件夹存在，则清空"""
        if not os.path.exists(self.out):
            os.mkdir(self.out)  # 创建相关文件夹
        else:
            shutil.rmtree(self.out)  # 清空文件夹
            os.mkdir(self.out)  # 创建相关文件夹

    def __prepare_custom_function__(self, option='add') -> None:
        """准备自定义函数"""
        custom_function_temp = os.path.join(self.ROOT_DIRECTORY, 'custom')
        if option == 'add':
            info = None
            try:
                for key in self.custom_functions.keys():
                    if self.custom_functions[key] is not None:
                        if not os.path.exists(custom_function_temp):
                            os.mkdir(custom_function_temp)  # 创建相关文件夹
                        shutil.copyfile(str(self.custom_functions[key]),
                                        os.path.join(custom_function_temp, key + '.py'))
            except Exception as e:
                info = f'Warning in x00507,\n' \
                       f'Description failed to initialize the custom module, Detail error are as follows: \n{e}!!!'
            finally:
                if info is not None:
                    if self.loading is not None:
                        self.loading.show_info(key=info, type='warning')
                    else:
                        print(f'-> {self.class_name} \033[0;33m{info}\033[0m')
        elif option == 'del':
            if os.path.exists(custom_function_temp):
                shutil.rmtree(custom_function_temp)  # 清空文件夹

    def __check_parm__(self) -> None:  # 规定返回值无类型限定/无返回值
        """检查传入参数是否正常"""
        info = None
        try:
            if not self.input:  # 检查必要参数
                info = f'Error in x00501,\n' \
                       f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                       f'The input folder is not defined, Please check!!!'
            elif not self.out:  # 检查必要参数
                info = f'Error in x00502,\n' \
                       f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                       f'The output folder is not defined, Please check!!!'
            elif not self.index:  # 检查必要参数
                info = f'Error in x00503,\n' \
                       f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                       f'The index path is not defined, Please check!!!'
            elif not os.path.exists(self.input):  # 检查必要参数
                info = f'Error in x00504,\n' \
                       f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                       f'The input folder path does not exist, Please check!!!'
            elif len(os.listdir(self.input)) <= 0:
                info = f'Error in x00505,\n' \
                       f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                       f'No file is found in <{self.input}>, Please check!!!'
        except Exception as e:
            info = f'Error in x00500,\n' \
                   f'Module({self.class_name}) initialization failed, Detail error are as follows: \n{e}!!!'
        finally:
            if info is not None:
                if self.loading is not None:
                    self.loading.show_info(key=info, type='warning')
                else:
                    print(f'-> {self.class_name} \033[0;31m{info}\033[0m')
                sys.exit()  # 抛出异常并终止程序

    def __check_index__(self, all_location: list) -> None:
        """
        判断数据中是否存在重复列名，若存在重复列名，则需要输入位置索引
        :param all_location: 原始数据的所有标签名称
        :return: 无
        """
        info = None
        if reduce(lambda x, y: x * y, [type(name) == str for name in self.parm]):  # 判断是否为标签类型索引(名称)
            all_location = [name.split('.')[0] for name in all_location]  # 获取原始数据的标签名称
            mark = max([all_location.count(now_name) for now_name in self.parm])  # 检查标签名称中是否重复
            index = [all_location.index(now_name) for now_name in self.parm]
            if mark > 1:  # 标签名称不重复
                info = f'Error in x00506,\n' \
                       f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                       f'Label index(loc) is not available, Please enter location index(iloc),\n' \
                       f'Location index(iloc) may be {index}, You can verify that!!!'
                if self.loading is not None:
                    self.loading.show_info(key=info, type='warning')
                else:
                    print(f'-> {self.class_name}\033[0;31m{index}\033[0m')
                sys.exit()
        if self.show_parm:  # 将输入参数打印出来，便于进行核对
            self.show_parm = False
            if self.loading is not None:
                self.loading.show_info(key='-> %s 参数名称: %s' %
                                           (self.class_name, [all_location[i] for i in self.parm]), type='message')
            else:
                print('-> %s \033[0;33m参数名称: %s \033[0m' %
                      (self.class_name, [all_location[i] for i in self.parm]))
        try:
            if reduce(lambda x, y: x * y, [type(name) == str for name in self.parm]):  # 判断是否为标签类型索引(名称)
                all_location = [name.split('.')[0] for name in all_location]  # 获取原始数据的标签名称
                mark = max([all_location.count(now_name) for now_name in self.parm])  # 检查标签名称中是否重复
                index = [all_location.index(now_name) for now_name in self.parm]
                if mark > 1:  # 标签名称不重复
                    info = f'Error in x00506,\n' \
                           f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                           f'Label index(loc) is not available, Please enter location index(iloc),\n' \
                           f'Location index(iloc) may be {index}, You can verify that!!!'
                    if self.loading is not None:
                        self.loading.show_info(key=info, type='warning')
                    else:
                        print(f'-> {self.class_name}\033[0;31m{index}\033[0m')
                    sys.exit()
            if self.show_parm:  # 将输入参数打印出来，便于进行核对
                self.show_parm = False
                if self.loading is not None:
                    self.loading.show_info(key='-> %s 参数名称: %s' %
                                               (self.class_name, [all_location[i] for i in self.parm]), type='message')
                else:
                    print('-> %s \033[0;33m参数名称: %s \033[0m' %
                          (self.class_name, [all_location[i] for i in self.parm]))
        except Exception as e:
            info = f'Error in x00500,\n' \
                   f'Module({self.class_name}) initialization failed, Detail error are as follows: \n{e}!!!'
        finally:
            if info is not None:
                if self.loading is not None:
                    self.loading.show_info(key=info, type='warning')
                else:
                    print(f'-> {self.class_name} \033[0;31m{info}\033[0m')
                sys.exit()  # 抛出异常并终止程序

    def __get_index__(self, info: dict) -> dict:
        """获取索引文件记录  info中至少含有{‘name’：‘’}"""
        # noinspection PyBroadException
        try:  # 尝试读取索引文件，若索引文件存在，则将['循环段', '上升段起点', '稳定段起点', '稳定段终点']保存至Index_value中
            if self.RAW_INDEX.empty:  # 索引文件行位置记录
                self.RAW_INDEX = pd.read_csv(self.index, index_col=0, encoding='gb2312', dtype={'Normal': str})  # 获取索引
                self.RAW_INDEX = self.RAW_INDEX.loc[:, 'Normal']  # 将关键点保存至Index_value
            mark = '' if self.RAW_INDEX is None else self.RAW_INDEX[int(info['循环段'][:5])]
        except Exception:  # 若索引文件存在，则令Index_value为空[]
            mark = 'True'
        return mark

    def __show_info__(self, Use_time: float, Num: list, Sum: list) -> None:
        """
        实时输出程序运行状况
        :param Use_time: 处理每个循环段数据花费的时间
        :param Num: 当前的循环段编号
        :param Sum: 总的循环段数量
        :return: 无
        """
        if self.debug:  # 若为调试模式，则不向索引文件写入内容
            return None
        cpu_percent = psutil.cpu_percent()  # CPU占用
        mem_percent = psutil.Process(os.getpid()).memory_percent()  # 内存占用
        self.Time_val.append(Use_time)  # 对每个时间差进行保存，用于计算平均时间
        mean_time = sum(self.Time_val) / len(self.Time_val)  # 计算平均时间
        sum_time = round(sum(self.Time_val) / 3600, 3)  # 计算程序执行的总时间
        remain_time = round((mean_time * (Sum[1] - Num[1] - 1)) / 3600, 3)  # 预计剩余时间计算
        print('\r   [第%d个 / 共%d个]  ' % (Num[1] + 1, Sum[1]),
              '[所用时间%ds / 平均时间%ds]  ' % (int(Use_time), int(mean_time)),
              '[CPU占用: %5.2f%% / 内存占用: %5.2f%%]  ' % (cpu_percent, mem_percent),
              '[累积运行时间: %6.3f小时 / 预计剩余时间: %6.3f小时]' % (sum_time, remain_time), end='')
        if Num[0] + 1 >= Sum[0] and Num[1] + 1 >= Sum[1]:
            print('\r-> %s \033[0;32mData-Merge completed, which took %6.3f hours\033[0m' % (self.class_name, sum_time))

    def main(self) -> None:  # 规定返回值无类型限定/无返回值
        """合并形成机器学习数据集"""
        # noinspection PyBroadException
        try:
            lib_path = os.path.join(os.path.dirname(self.ROOT_DIRECTORY), 'Lib', 'Hashlib.lib')
            if os.path.exists(lib_path):
                runpy.run_path(lib_path)  # 导入动态链接库文件
            self.__check_parm__()  # 检查参数是否正常
            self.__create_merge_Dir__()  # 创建相关文件夹
            self.__prepare_custom_function__(option='add')  # 准备自定义函数
            all_dir = os.listdir(self.input)  # 获取输入路径下的所有子文件夹
            mission_count = sum([len(files) for root, dirs, files in os.walk(self.input)])
            self.loading.update(key='detail-sum', value=mission_count) if self.loading is not None else None
            self.loading.update(key='total-count') if self.loading is not None else None
            for dir_num, Dir in enumerate(all_dir):  # 遍历输入路径下的所有子文件夹
                Dir_path = os.path.join(self.input, Dir)  # 子文件夹路径
                all_file = os.listdir(Dir_path)
                for file_num, file in enumerate(all_file):
                    while self.loading is not None and self.loading.get_pause():
                        time.sleep(1)
                    time_S = time.time()  # 记录程序执行开始时间
                    local_csv_path = os.path.join(self.input, Dir, file)  # 当前文件路径
                    target_csv_path = os.path.join(self.out, file)  # 目标文件路径
                    # noinspection PyBroadException
                    try:
                        if self.__get_index__({'循环段': file}) == 'True':
                            shutil.copyfile(local_csv_path, target_csv_path)  # 复制文件值目标路径
                    except Exception as e:
                        if self.loading is not None:
                            self.loading.show_info(key=f'-> {self.class_name} {e}', type='message')
                        else:
                            print(f'-> {self.class_name} \033[0;31m{e}\033[0m')
                    time_F = time.time()  # 记录程序执行结束时间
                    if self.loading is not None:
                        self.loading.update(key='detail-count')
                    else:
                        self.__show_info__(Use_time=time_F - time_S, Num=[dir_num, file_num],
                                           Sum=[len(all_dir), len(all_file)])
        except Exception:
            if self.loading is not None:
                self.loading.show_info(key=traceback.format_exc(), type='error')
            else:
                print(f'-> {self.class_name} \033[0;31m{traceback.format_exc()}\033[0m')
        finally:
            self.__prepare_custom_function__(option='del')


if __name__ == "__main__":
    TBM_MERGE(input_path=r'D:\17339902814\OneDrive\桌面\test\clean',
              out_path=r'D:\17339902814\OneDrive\桌面\test\merge',
              index_path=r'D:\17339902814\OneDrive\桌面\test\index.csv',
              parameter=[0, 1, 23, 5, 7, 2, 8, 3, 4, 6, 1],
              Run=True)
