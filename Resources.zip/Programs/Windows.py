#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ************************************************************************
# * Software:  TBM Pre-process                                           *
# * Version:  1.0.6                                                      *
# * Date:  2024-02-18 18:38:04                                           *
# * Last  update: 2023-11-08 20:00:00                                    *
# * License:  LGPL v1.0                                                  *
# * Maintain  address:  https://pan.baidu.com/s/1WIr67y1pNQCgEyUnuj004w  *
# * Maintain  code:  STBM                                                *
# * Email: jgliu1001@163.com                                             *
# ************************************************************************

import sys
import random
import os
import dill
import glob
import shutil
import io
import configparser
import tarfile
import subprocess
import time
import zipfile
import tempfile
import requests
import threading
import psutil
import itertools
import pyzipper
import tkinter.font as tkfont
import webbrowser as web
from datetime import datetime
from PIL import Image, ImageTk
from tkinter import Tk, BooleanVar, StringVar, IntVar, BOTH, Button, Frame, Checkbutton, ttk
from tkinter import N, Label, Entry, Radiobutton, LabelFrame, Text, messagebox, Canvas, simpledialog
from tkinter.ttk import Style, Notebook, Progressbar, Style, Combobox
from tkinter.filedialog import askdirectory, asksaveasfilename, askopenfilename
from Cycle import TBM_CYCLE
from Extract import TBM_EXTRACT
from Class import TBM_CLASS
from Clean import TBM_CLEAN
from Merge import TBM_MERGE
from Split import TBM_SPLIT
from Filter import TBM_FILTER
from Plot import TBM_PLOT
from Report import TBM_REPORT


def run(models):
    for model in models:
        if model['run']:
            model['model'].main()


if __name__ == "__main__":
    print('-> \033[0;32mOperating System: %s  Current Program: %s\033[0m' % (sys.platform, os.path.basename(__file__)))
    ROOT_DIRECTORY = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    with open(os.path.join(ROOT_DIRECTORY, 'Lib', 'Win32.lib'), 'rb') as wf:
        window = dill.load(wf)  # 导入动态链接库文件，完成对程序的配置
        window.path = ROOT_DIRECTORY  # 导入动态链接库文件，完成对程序的配置
        CONF = window.run().config  # 导入动态链接库文件，完成对程序的配置
    if bool(CONF['update']['state']):
        subprocess.Popen(os.path.join(ROOT_DIRECTORY, 'temp', 'recovery.bat'),
                         cwd=os.path.join(ROOT_DIRECTORY, 'temp'),
                         shell=True)
        sys.exit()
    total_mission = sum((model['state'] if isinstance(model, dict) else False) for model in CONF.values())
    with open(os.path.join(ROOT_DIRECTORY, 'Lib', 'Loading.lib'), 'rb') as wf:
        class_loading = dill.load(wf)  # 导入动态链接库文件，完成对程序的配置
        class_loading.path = ROOT_DIRECTORY  # 导入动态链接库文件，完成对程序的配置
        loading = class_loading.run()  # 导入动态链接库文件，完成对程序的配置
        loading.update(key='total-sum', value=total_mission)
        loading.run()
    target_cycle = TBM_CYCLE(input_path=CONF['cycle']['input'], out_path=CONF['cycle']['output'],
                             index_path=CONF['index'], parameter=CONF['cycle']['parameter'],
                             division=CONF['cycle']['division-way'], interval_time=CONF['cycle']['interval-time'],
                             V_min=CONF['cycle']['velocity-min'], L_min=CONF['cycle']['length-min'],
                             debug=CONF['cycle']['debug'], custom_functions=CONF['cycle']['custom-function'],
                             loading=loading)
    target_extract = TBM_EXTRACT(input_path=CONF['extract']['input'], out_path=CONF['extract']['output'],
                                 index_path=CONF['index'], key_parm=CONF['extract']['parameter'],
                                 debug=CONF['extract']['debug'], custom_functions=CONF['extract']['custom-function'],
                                 loading=loading)
    target_class = TBM_CLASS(input_path=CONF['class']['input'], out_path=CONF['class']['output'],
                             index_path=CONF['index'], parameter=CONF['class']['parameter'],
                             project_type=CONF['class']['project'], L_min=CONF['class']['length-min'],
                             V_max=CONF['class']['velocity-max'], constant_time=CONF['class']['constant-time'],
                             missing_ratio=CONF['class']['missing_ratio'], debug=CONF['class']['debug'],
                             functions={'A1': CONF['class']['id-a1'], 'B1': CONF['class']['id-b1'],
                                        'B2': CONF['class']['id-b2'], 'C1': CONF['class']['id-c1'],
                                        'C2': CONF['class']['id-c2'], 'D1': CONF['class']['id-d1'],
                                        'E1': CONF['class']['id-e1']},
                             custom_functions=CONF['class']['custom-function'], loading=loading)
    target_clean = TBM_CLEAN(input_path=CONF['clean']['input'], out_path=CONF['clean']['output'],
                             index_path=CONF['index'], parameter=CONF['clean']['parameter'],
                             V_max=CONF['clean']['velocity-max'], debug=CONF['clean']['debug'],
                             functions={'A1': CONF['clean']['correct-a1'], 'B1': CONF['clean']['correct-b1'],
                                        'B2': CONF['clean']['correct-b2'], 'C1': CONF['clean']['correct-c1'],
                                        'C2': CONF['clean']['correct-c2'], 'D1': CONF['clean']['correct-d1'],
                                        'E1': CONF['clean']['correct-e1']},
                             custom_functions=CONF['clean']['custom-function'], loading=loading)
    target_merge = TBM_MERGE(input_path=CONF['merge']['input'], out_path=CONF['merge']['output'],
                             index_path=CONF['index'], parameter=CONF['merge']['parameter'],
                             debug=CONF['merge']['debug'], custom_functions=CONF['merge']['custom-function'],
                             loading=loading)
    target_split = TBM_SPLIT(input_path=CONF['split']['input'], out_path=CONF['split']['output'],
                             index_path=CONF['index'], parameter=CONF['split']['parameter'],
                             partition=CONF['split']['partition-method'], min_time=CONF['split']['time-min'],
                             debug=CONF['split']['debug'], custom_functions=CONF['split']['custom-function'],
                             loading=loading)
    target_filter = TBM_FILTER(input_path=CONF['filter']['input'], out_path=CONF['filter']['output'],
                               index_path=CONF['index'], parameter=CONF['filter']['parameter'],
                               debug=CONF['filter']['debug'], custom_functions=CONF['filter']['custom-function'],
                               loading=loading)
    target_plot = TBM_PLOT(input_path=CONF['plot']['input'], out_path=CONF['plot']['output'],
                           index_path=CONF['index'], parameter=CONF['plot']['parameter'],
                           height=CONF['plot']['height'], weight=CONF['plot']['weight'],
                           dpi=CONF['plot']['dpi'], Format=CONF['plot']['format'],
                           debug=CONF['plot']['debug'], custom_functions=CONF['plot']['custom-function'],
                           loading=loading)
    target_report = TBM_REPORT(input_path=CONF['report']['input'], out_path=CONF['report']['output'],
                               index_path=CONF['index'], parameter=CONF['report']['parameter'],
                               input_pic=CONF['report']['plot-path'], cover=CONF['report']['cover'],
                               content=CONF['report']['content'], header=CONF['report']['header'],
                               footer=CONF['report']['footer'], watermark=CONF['report']['watermark'],
                               pic_outer=CONF['report']['outer'], watermark_info=CONF['report']['watermark-info'],
                               debug=CONF['report']['debug'], custom_functions=CONF['report']['custom-function'],
                               loading=loading)
    params = [{'run': CONF['cycle']['state'], 'model': target_cycle},
              {'run': CONF['extract']['state'], 'model': target_extract},
              {'run': CONF['class']['state'], 'model': target_class},
              {'run': CONF['clean']['state'], 'model': target_clean},
              {'run': CONF['merge']['state'], 'model': target_merge},
              {'run': CONF['split']['state'], 'model': target_split},
              {'run': CONF['filter']['state'], 'model': target_filter},
              {'run': CONF['plot']['state'], 'model': target_plot},
              {'run': CONF['report']['state'], 'model': target_report}]
    threading.Thread(target=run, args=(params,)).start()
    loading.Windows()
