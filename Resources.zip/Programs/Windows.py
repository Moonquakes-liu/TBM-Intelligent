#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ************************************************************************
# * Software:  Windows  for  Python                                      *
# * Version:  1.0.6                                                      *
# * Date:  2024-02-04 20:00:00                                           *
# * Last  update: 2023-11-08 20:00:00                                    *
# * License:  LGPL v1.0                                                  *
# * Maintain  address:  https://pan.baidu.com/s/1WIr67y1pNQCgEyUnuj004w  *
# * Maintain  code:  STBM                                                *
# * Email: jgliu1001@163.com                                             *
# ************************************************************************

import sys
import runpy
import os
import glob
import shutil
import io
import configparser
import tarfile
import time
import zipfile
import tempfile
import requests
import threading
import psutil
from datetime import datetime
import tkinter.font as tkfont
import webbrowser as web
from tkinter import Tk, BooleanVar, StringVar, IntVar, BOTH, Button, Frame, Checkbutton, ttk
from tkinter import N, Label, Entry, Radiobutton, LabelFrame, Text, messagebox, Canvas, simpledialog
from tkinter.ttk import Style, Notebook, Progressbar, Style, Combobox
from tkinter.filedialog import askdirectory, asksaveasfilename, askopenfilename
from Cycle import TBM_CYCLE
from Extract import TBM_EXTRACT
from Class import TBM_CLASS
from Clean import TBM_CLEAN
from Merge import TBM_MERGE
from Split import TBM_SPLIT
from Filter import TBM_FILTER
from Plot import TBM_PLOT
from Report import TBM_REPORT


class MESSAGE(object):
    """TK图像用户界面"""
    Text = ('宋体', 11)  # 界面字体大小
    current_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    update_url = "https://github.com/Moonquakes-liu/TBM-Intelligent/archive/refs/heads/main.zip"
    custom_function_var = {}

    def __init__(self):
        self.root = Tk()
        self.var = {'index': {'path': StringVar()},
                    'cycle': {'state': BooleanVar(), 'debug': BooleanVar(), 'input': StringVar(),
                              'output': StringVar(), 'parameter': StringVar(),
                              'example': '桩号, 日期, 推进位移, 刀盘转速, 推进速度, 刀盘扭矩, 刀盘推力, 贯入度, 刀盘转速设定值, 推进速度设定值',
                              'default-input-dir': ' ',
                              'default-output-dir': '[划分]-AllDataSet',
                              'division-way': StringVar(), 'interval-time': IntVar(),
                              'velocity-min': IntVar(), 'length-min': IntVar(),
                              'division-way-option': ['刀盘转速', '推进速度', '环号', '里程(每米)'],
                              'custom-function': {'data_read': StringVar()},
                              'description': "1、两循环段间时间间隔建议设置在 (1 - 100)s\n"
                                             "2、掘进长度下限值建议设置在 (0 - 100)mm\n"
                                             "3、掘进速度下限值下限值建议设置在 (0 - 100)mm/min"},
                    'extract': {'state': BooleanVar(), 'debug': BooleanVar(), 'input': StringVar(),
                                'output': StringVar(), 'parameter': StringVar(),
                                'example': '根据需要自定义输入数据',
                                'default-input-dir': '[划分]-AllDataSet',
                                'default-output-dir': '[提取]-KeyDataSet',
                                'custom-function': {},
                                'description': "无"},
                    'class': {'state': BooleanVar(), 'debug': BooleanVar(), 'input': StringVar(),
                              'output': StringVar(), 'parameter': StringVar(),
                              'example': '桩号, 日期, 推进位移, 刀盘转速, 推进速度, 刀盘扭矩, 刀盘推力, 贯入度, 刀盘转速设定值, 推进速度设定值',
                              'default-input-dir': '[提取]-KeyDataSet',
                              'default-output-dir': '[分类]-ClassDataSet',
                              'id-a1': BooleanVar(), 'id-b1': BooleanVar(), 'id-b2': BooleanVar(),
                              'id-c1': BooleanVar(), 'id-c2': BooleanVar(), 'id-d1': BooleanVar(),
                              'id-e1': BooleanVar(), 'project': StringVar(), 'length-min': IntVar(),
                              'velocity-max': IntVar(), 'constant-time': IntVar(), 'missing_ratio': IntVar(),
                              'project-option': ['引松', '引额-361', '引额-362', '引绰-667', '引绰-668'],
                              'custom-function': {'split': StringVar(), 'class_A1': StringVar(),
                                                  'class_B1': StringVar(), 'class_B2': StringVar(),
                                                  'class_C1': StringVar(), 'class_C2': StringVar(),
                                                  'class_D1': StringVar(), 'class_E1': StringVar()},
                              'description': "1、最小掘进长度建议设置为：(1 - 300)mm\n"
                                             "2、推进速度上限值建议设置为：引松取 120mm/min / 额河取 200mm/min\n"
                                             "3、数据缺失率建议设置为：(1 - 20)%"},
                    'clean': {'state': BooleanVar(), 'debug': BooleanVar(), 'input': StringVar(),
                              'output': StringVar(), 'parameter': StringVar(),
                              'example': '桩号, 日期, 推进位移, 刀盘转速, 推进速度, 刀盘扭矩, 刀盘推力, 贯入度, 刀盘转速设定值, 推进速度设定值',
                              'default-input-dir': '[分类]-ClassDataSet',
                              'default-output-dir': '[修正]-CleanDataSet',
                              'correct-a1': BooleanVar(), 'correct-b1': BooleanVar(), 'correct-b2': BooleanVar(),
                              'correct-c1': BooleanVar(), 'correct-c2': BooleanVar(), 'correct-d1': BooleanVar(),
                              'correct-e1': BooleanVar(), 'velocity-max': IntVar(),
                              'custom-function': {'clean_A1': StringVar(), 'clean_B1': StringVar(),
                                                  'clean_B2': StringVar(), 'clean_C1': StringVar(),
                                                  'clean_C2': StringVar(), 'clean_D1': StringVar(),
                                                  'clean_E1': StringVar()},
                              'description': "1、推进速度上限值可设置为：引松取 120mm/min / 额河取 200mm/min"},
                    'merge': {'state': BooleanVar(), 'debug': BooleanVar(), 'input': StringVar(),
                              'output': StringVar(), 'parameter': StringVar(),
                              'example': '桩号, 日期, 推进位移, 刀盘转速, 推进速度, 刀盘扭矩, 刀盘推力, 贯入度, 刀盘转速设定值, 推进速度设定值',
                              'default-input-dir': '[修正]-CleanDataSet',
                              'default-output-dir': '[合并]-MergeDataSet',
                              'custom-function': {},
                              'description': "1、若索引文件存在，则根据索引文件合并文件"},
                    'split': {'state': BooleanVar(), 'debug': BooleanVar(), 'input': StringVar(),
                              'output': StringVar(), 'parameter': StringVar(),
                              'example': '桩号, 日期, 推进位移, 刀盘转速, 推进速度, 刀盘扭矩, 刀盘推力, 贯入度, 刀盘转速设定值, 推进速度设定值',
                              'default-input-dir': '[合并]-MergeDataSet',
                              'default-output-dir': '[分割]-SplitDataSet',
                              'partition-method': StringVar(), 'time-min': IntVar(),
                              'partition-method-option': ['平均值', '核密度估计'],
                              'custom-function': {'split': StringVar()},
                              'description': "1、最小时间记录可设置为：(50 - 500)s\n"},
                    'filter': {'state': BooleanVar(), 'debug': BooleanVar(), 'input': StringVar(),
                               'output': StringVar(), 'parameter': StringVar(),
                               'example': '桩号, 日期, 推进位移, 刀盘转速, 推进速度, 刀盘扭矩, 刀盘推力, 贯入度, 刀盘转速设定值, 推进速度设定值',
                               'default-input-dir': '[合并]-MergeDataSet',
                               'default-output-dir': '[降噪]-FilterDataSet',
                               'custom-function': {'filter': StringVar()},
                               'description': "无"},
                    'plot': {'state': BooleanVar(), 'debug': BooleanVar(), 'input': StringVar(),
                             'output': StringVar(), 'parameter': StringVar(),
                             'example': '桩号, 日期, 推进位移, 刀盘转速, 推进速度, 刀盘扭矩, 刀盘推力, 贯入度, 刀盘转速设定值, 推进速度设定值',
                             'default-input-dir': '[合并]-MergeDataSet',
                             'default-output-dir': '[绘图]-PicDataSet',
                             'weight': IntVar(), 'height': IntVar(), 'dpi': IntVar(), 'format': StringVar(),
                             'format-option': ['png', 'eps', 'jpeg', 'jpg', 'pdf', 'pgf', 'ps', 'raw', 'svg', 'tif'],
                             'dpi-option': [72, 120, 150, 300, 600],
                             'custom-function': {'plot': StringVar()},
                             'description': "1、图片高度建议设置为：(10 - 90)mm\n"
                                            "2、图片宽度建议设置为：(10 - 160)mm"},
                    'report': {'state': BooleanVar(), 'debug': BooleanVar(), 'input': StringVar(),
                               'output': StringVar(), 'parameter': StringVar(),
                               'example': '桩号, 日期, 推进位移, 刀盘转速, 推进速度, 刀盘扭矩, 刀盘推力, 贯入度, 刀盘转速设定值, 推进速度设定值',
                               'default-input-dir': '[合并]-MergeDataSet',
                               'default-output-dir': '[报表]-PdfDataSet',
                               'cover': BooleanVar(), 'content': BooleanVar(), 'header': BooleanVar(),
                               'footer': BooleanVar(), 'watermark': BooleanVar(), 'watermark-info': StringVar(),
                               'outer': BooleanVar(), 'plot-path': StringVar(),
                               'custom-function': {'plot': StringVar()},
                               'description': "1、若使用外部图片资源，则需保证图片名称和循环段名称一致"},
                    'backup-recovery': {'backup': StringVar(), 'recovery': StringVar(), 'update': StringVar()}}
        self.config = {}
        self.tab = {}
        self.notebook = None
        self.update = {}
        self.get_config()
        self.check_update()
        self.main()  # 运行主程序

    def creative_config(self):
        # noinspection PyBroadException
        try:
            new_var = {}
            for model in self.var.keys():
                temp = {}
                for key in self.var[model].keys():
                    if not isinstance(self.var[model][key], (str, list, dict)):
                        temp[key] = self.var[model][key].get()
                new_var[model] = temp
            Time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            Config = configparser.ConfigParser()
            Config['program'] = {'Time': str(Time), 'Name': os.path.basename(__file__)}
            Config['index'] = new_var['index']
            Config['cycle'] = new_var['cycle']
            Config['extract'] = new_var['extract']
            Config['class'] = new_var['class']
            Config['clean'] = new_var['clean']
            Config['merge'] = new_var['merge']
            Config['filter'] = new_var['filter']
            Config['split'] = new_var['split']
            Config['plot'] = new_var['plot']
            Config['report'] = new_var['report']
            if not os.path.exists(os.path.join(self.current_path, 'config')):  # 判断文件夹是否存在
                os.makedirs(os.path.join(self.current_path, 'config'))  # 如果不存在，则创建文件夹
            with open(os.path.join(self.current_path, 'config', 'config.ini'), 'w+', encoding='GBK') as cfg:
                Config.write(cfg)
        except Exception:
            messagebox.showwarning(title='警告', message=f'配置文件创建失败，设置信息未保存！')  # 消息提醒弹

    def get_config(self):
        """定义读取配置文件函数，分别读取各个分栏的配置参数，包含ints、floats、strings"""
        lib_path = os.path.join(self.current_path, 'Lib', 'Hashlib.lib')
        if os.path.exists(lib_path):
            runpy.run_path(lib_path)  # 导入动态链接库文件
        parser = configparser.ConfigParser()
        if not os.path.exists(os.path.join(self.current_path, 'config', 'config.ini')):
            self.default_var()
        # noinspection PyBroadException
        try:
            parser.read(os.path.join(self.current_path, 'config', 'config.ini'), encoding='GBK')  # 读取文件
            for model in parser.sections():
                if model not in ['program']:
                    for key in parser.options(model):
                        self.var[model][key].set(parser.get(model, key))
            self.var['backup-recovery']['backup'].set('--未选择任何文件--')
            self.var['backup-recovery']['recovery'].set('--未选择任何文件--')
            self.var['backup-recovery']['update'].set('--未选择任何文件--')
        except Exception:
            self.default_var()

    def default_var(self):
        default = {'index': {'path': '--请选择--'},
                   'cycle': {'state': False, 'debug': False, 'input': '--请选择--', 'output': '--请选择--',
                             'parameter': '--请选择--', 'division-way': 'Rotate Speed', 'interval-time': 30,
                             'velocity-min': 1, 'length-min': 10},
                   'extract': {'state': False, 'debug': False, 'input': '--请选择--', 'output': '--请选择--',
                               'parameter': '--请选择--'},
                   'class': {'state': False, 'debug': False, 'input': '--请选择--', 'output': '--请选择--',
                             'parameter': '--请选择--', 'project': '引松', 'id-a1': True, 'id-b1': True,
                             'id-b2': True, 'id-c1': True, 'id-c2': True, 'id-d1': True, 'id-e1': True,
                             'length-min': 10, 'velocity-max': 120, 'constant-time': 5, 'missing_ratio': 20},
                   'clean': {'state': False, 'debug': False, 'input': '--请选择--', 'output': '--请选择--',
                             'parameter': '--请选择--', 'correct-a1': False, 'correct-b1': True,
                             'correct-b2': False, 'correct-c1': False, 'correct-c2': False, 'correct-d1': False,
                             'correct-e1': False, 'velocity-max': 120},
                   'merge': {'state': False, 'debug': False, 'input': '--请选择--', 'output': '--请选择--',
                             'parameter': '--请选择--'},
                   'split': {'state': False, 'debug': False, 'input': '--请选择--', 'output': '--请选择--',
                             'parameter': '--请选择--', 'partition-method': 'Average', 'time-min': 200},
                   'filter': {'state': False, 'debug': False, 'input': '--请选择--', 'output': '--请选择--',
                              'parameter': '--请选择--'},
                   'plot': {'state': False, 'debug': False, 'input': '--请选择--', 'output': '--请选择--',
                            'parameter': '--请选择--', 'weight': 80, 'height': 60, 'dpi': 120, 'format': 'png'},
                   'report': {'state': False, 'debug': False, 'input': '--请选择--', 'output': '--请选择--',
                              'parameter': '--请选择--', 'cover': False, 'content': True, 'header': True,
                              'footer': True, 'watermark': False, 'watermark-info': '--请输入水印名称--',
                              'outer': False, 'plot-path': '--请选择外部图片路径--'},
                   'backup-recovery': {'backup': '--未选择任何文件--', 'recovery': '--未选择任何文件--',
                                       'update': '--未选择任何文件--'}}
        for model in default.keys():
            for key in default[model].keys():
                self.var[model][key].set(default[model][key])

    def main(self):
        self.root.geometry('700x760+500+10')
        self.root.title('数据预处理')
        self.root.resizable(0, 0)  # 防止用户调整尺寸
        lib_path = os.path.join(self.current_path, 'Lib', 'Hashlib.lib')
        if os.path.exists(lib_path):
            runpy.run_path(lib_path)  # 导入动态链接库文件
        # noinspection PyBroadException
        try:
            style = Style()
            style.configure('my.TNotebook', tabposition='wn')  # 'se'再改nw,ne,sw,se,w,e,wn,ws,en,es,n,s试试
            style.configure('TNotebook.Tab', background='black', font=('宋体', 13))
            self.notebook = Notebook(self.root, style='my.TNotebook')  # 1 创建Notebook组件
            self.notebook.pack(padx=10, pady=5, fill=BOTH, expand=True)
            self.root.protocol("WM_DELETE_WINDOW", lambda: self.cancel_event())
            if self.update['new-version'] > self.update['local-version']:
                Button(self.root, text='发现新版本New！', command=lambda: self.new_version_event(),
                       font=('宋体', 9), bd=0, fg='green').place(x=12, y=610, width=90, height=25)
            Button(self.root, text='版本信息', command=lambda: self.version_event(),
                   font=self.Text, bd=1).place(x=17, y=645, width=70, height=25)
            Button(self.root, text='恢复默认', command=lambda: self.reset_event(),
                   font=self.Text, bd=1).place(x=17, y=680, width=70, height=25)
            Button(self.root, text=' 帮 助 ', command=lambda: self.help_event(),
                   font=self.Text, bd=1).place(x=17, y=715, width=70, height=25)
            self.model_cycle(notebook=self.notebook)
            self.model_extract(notebook=self.notebook)
            self.model_class(notebook=self.notebook)
            self.model_clean(notebook=self.notebook)
            self.model_merge(notebook=self.notebook)
            self.model_split(notebook=self.notebook)
            self.model_filter(notebook=self.notebook)
            self.model_plot(notebook=self.notebook)
            self.model_report(notebook=self.notebook)
            self.model_backup_recovery(notebook=self.notebook)
        except Exception as e:
            messagebox.showerror(title='错误', message=f'发生致命错误，程序即将退出！{e}')  # 消息提醒弹
            self.cancel_event()
        self.root.mainloop()

    def input_event(self, key):
        """获取输入路径"""
        newDir = askdirectory(title='打开目录').replace('/', '\\')
        if newDir:
            self.var[key]['input'].set(newDir)
            recommend_dir = os.path.dirname(newDir)  # 推荐文件夹
            self.var[key]['output'].set(os.path.join(recommend_dir, str(self.var[key]['default-output-dir'])))  # 推荐文件夹
            if key == 'cycle':
                for key in ['extract', 'class', 'clean', 'merge', 'split', 'filter', 'plot', 'report']:
                    self.var[key]['input'].set(os.path.join(recommend_dir, str(self.var[key]['default-input-dir'])))
                    self.var[key]['output'].set(os.path.join(recommend_dir, str(self.var[key]['default-output-dir'])))

    def output_event(self, key):
        """获取输出路径"""
        newDir = askdirectory(title='另存目录').replace('/', '\\')
        None if not newDir else self.var[key]['output'].set(newDir)

    def parm_event(self, key):
        """获取文本变量"""

        def get_info(frame):
            information = frame.get('0.0', 'end')[:-1]
            self.var[key]['parameter'].set(information)
            window.destroy()

        def clear_info(frame):
            frame.delete('1.0', 'end')

        window = Tk()
        window.geometry('700x270+500+350')
        window.resizable(0, 0)  # 防止用户调整尺寸
        window.title('输入参数')
        Label(window, text='多个参数间用逗号隔开(位置索引/标签索引)', font=self.Text).pack(pady=7)
        Label(window, text=f"参数说明：{self.var[key]['example']}", font=('宋体', 9)).pack(pady=7)
        input_frame = Text(window, font=self.Text)
        input_frame.delete('1.0', 'end')
        input_frame.insert('end', self.var[key]['parameter'].get())
        input_frame.place(x=15, y=70, width=668, height=150)  # width宽 height高
        clear = Button(window, text='清  空', font=self.Text, command=lambda: clear_info(frame=input_frame))
        clear.place(x=15, y=230, width=80, height=30)
        okay = Button(window, text='确  认', font=self.Text, command=lambda: get_info(frame=input_frame))
        okay.place(x=603, y=230, width=80, height=30)

    def help_event(self):
        """打开帮助文件"""
        try:
            os.startfile(os.path.join(self.current_path, 'helps', 'help.pdf'))
        except FileNotFoundError:
            messagebox.showwarning(title='提 示', message='帮助文件不存在！')  # 消息提醒弹

    def reset_event(self):
        """重置所有设置"""
        if messagebox.askyesno(title='提 示', message='将会清空所有设置，是否继续？'):
            self.default_var()
            # 删除所有子元素
            for widget in self.root.winfo_children():
                widget.destroy()
            self.main()

    @staticmethod  # 不强制要求传递参数
    def version_event():
        """展示版本信息"""
        with open(os.path.abspath(__file__), 'r', encoding="utf-8") as F:
            Info = ''.join(F.readlines()[3:11]).replace('# *', '').replace(' *', '')
        messagebox.showinfo(title='版本信息', message=Info)  # 消息提醒弹

    def new_version_event(self):
        """检测到新版本信息"""

        def online_update_event(framework):
            """检查更新模块"""
            temp_path = os.path.join(self.current_path, 'temp')
            if not os.path.exists(temp_path):
                os.mkdir(temp_path)  # 创建相关文件夹
            progress = Progressbar(framework, orient="horizontal", length=100, mode="determinate")
            progress.place(x=28, y=500, width=530, height=10)
            label = Label(framework, text='', font=('宋体', 9))
            label.place(x=200, y=515, width=200, height=25)
            # noinspection PyBroadException
            try:
                # 第一步
                progress['value'] = 0  # 设置初始值为50%
                label.config(text='正在下载更新包，请勿关闭程序...')
                self.root.update()
                response = requests.get(self.update_url)
                with tempfile.TemporaryFile() as temp_file:
                    for index, data in enumerate(response.iter_content(1024)):
                        progress['value'] = int(index / 2) if (index / 2) <= 30 else 30  # 设置初始值为50%
                        self.root.update()
                        temp_file.write(data)
                    time.sleep(1)
                    # 第二步
                    progress['value'] = 30  # 设置初始值为50%
                    label.config(text='正在部署环境，请勿关闭程序......')
                    self.root.update()
                    ZF = zipfile.ZipFile(temp_file, mode='r')
                    zip_file_list = ZF.namelist()
                    for num, name in enumerate(zip_file_list):
                        ZF.extract(name, temp_path)  # 解压到zip目录文件下
                        progress['value'] = 30 + (60 - 30) / len(zip_file_list) * (num + 1)  # 设置初始值为50%
                        self.root.update()
                        time.sleep(0.5)
                    source_folder = os.path.join(temp_path, 'TBM-Intelligent-main')
                    for item_name in os.listdir(source_folder):
                        shutil.move(os.path.join(source_folder, item_name),
                                    os.path.join(temp_path, item_name))
                    shutil.rmtree(source_folder)
                    shutil.copy(os.path.join(self.current_path, 'temp', 'Update.py'),
                                os.path.join(self.current_path, 'Programs', 'Update.py'))
                    # 第三步
                    progress['value'] = 60  # 设置初始值为50%
                    label.config(text='正在校验更新包，请勿关闭程序...')
                    self.root.update()
                    time.sleep(1)
                    # 第四步
                    progress['value'] = 70  # 设置初始值为50%
                    label.config(text='正在更新组件，请勿关闭程序...')
                    self.root.update()
                    from Update import Update
                    time.sleep(1)
                    # 第五步
                    progress['value'] = 90  # 设置初始值为50%
                    label.config(text='正在清理冗余信息，请勿关闭程序...')
                    self.root.update()
                    shutil.rmtree(temp_path)  # 清空文件夹
                    time.sleep(1)
                    progress['value'] = 99  # 设置初始值为50%
                    label.config(text='更新即将完成，请勿关闭程序...')
                    self.root.update()
                    time.sleep(1)
                    progress['value'] = 100  # 设置初始值为50%
                    self.root.update()
                    label.place_forget()
                    progress.place_forget()
                    messagebox.showinfo(title='提示', message='更新程序成功，请重新启动程序！')  # 消息提醒弹
                    self.root.destroy()
                    sys.exit()
            except Exception:
                progress['value'] = 0  # 设置初始值为50%
                label.config(text='发生致命错误，更新失败！！！')
                self.root.update()
            finally:
                if os.path.exists(temp_path):
                    shutil.rmtree(temp_path)
                if os.path.exists(os.path.join(self.current_path, 'Programs', 'Update.py')):
                    os.remove(os.path.join(self.current_path, 'Programs', 'Update.py'))

        out = ''
        for index, info in enumerate(self.update['new-information']):
            out += f'{index + 1}.{info}\n'
        Info = f'新版本：v{self.update["new-version"]}\n' \
               f'包大小：{self.update["new-size"]}\n' \
               f'发布时间：{self.update["new-date"]}\n' \
               '\n' \
               '更新内容：\n' \
               f'{out}\n' \
               '\n' \
               '是否更新？'
        if messagebox.askyesno(title='发现新版本', message=Info):
            self.notebook.select(self.tab['update'])
            online_update_event(self.tab['update'])

    def check_update(self):
        """检查更新"""

        def format_file_size(size_in_bytes):
            for unit in ['B', 'KB', 'MB', 'GB']:
                if size_in_bytes < 1024.0:
                    return f"{size_in_bytes:.2f} {unit}"
                size_in_bytes /= 1024.0
            return f"{size_in_bytes:.2f} TB"

        temp_path = os.path.join(self.current_path, 'temp')
        if not os.path.exists(temp_path):
            os.mkdir(temp_path)  # 创建相关文件夹
        # noinspection PyBroadException
        try:
            response = requests.get(self.update_url)
            total_size = 0
            with tempfile.TemporaryFile() as temp_file:
                for index, data in enumerate(response.iter_content(1024)):
                    temp_file.write(data)
                    total_size += len(data)
                ZF = zipfile.ZipFile(temp_file, mode='r')
                for num, name in enumerate(ZF.namelist()):
                    ZF.extract(name, temp_path)  # 解压到zip目录文件下
                source_folder = os.path.join(temp_path, 'TBM-Intelligent-main')
                for item_name in os.listdir(source_folder):
                    shutil.move(os.path.join(source_folder, item_name),
                                os.path.join(temp_path, item_name))
                shutil.rmtree(source_folder)
                update_information = os.path.join(temp_path, 'Update_INF.ini')
                new_parser = configparser.ConfigParser()
                new_parser.read(update_information, encoding='utf-8')  # 读取文件
                new_version = new_parser.get('Update', 'new-version')
                new_size = format_file_size(total_size)
                new_date = new_parser.get('Update', 'new-modify')
                new_information = new_parser.get('Update', 'information').split('；')
                local_information = os.path.join(self.current_path, 'md5')
                local_parser = configparser.ConfigParser()
                local_parser.read(local_information, encoding='GBK')  # 读取文件
                local_version = local_parser.get('program', 'version')
                self.update = {'new-version': new_version, 'local-version': local_version, 'new-size': new_size,
                               'new-date': new_date, 'new-information': new_information}
                with zipfile.ZipFile(os.path.join(temp_path, 'Resources.zip'), "r") as zip_ref:
                    zip_ref.extract('Lib/Hashlib.lib', self.current_path)  # 解压到zip目录文件下
        except Exception as e:
            print(e)
            self.update = {'new-version': '0.0.0', 'local-version': '0.0.0', 'new-size': None,
                           'new-date': None, 'new-information': None}
        finally:
            if os.path.exists(temp_path):
                shutil.rmtree(temp_path)

    def ok_event(self):
        """确定"""
        self.apply_event()
        self.root.destroy()
        self.creative_config()
        for model in self.config.keys():
            if model != 'index' and self.config[model]['parameter'] is not None:
                self.config[model]['parameter'] = self.config[model]['parameter'].replace('，', ',')
                try:
                    self.config[model]['parameter'] = [int(x) for x in self.config[model]['parameter'].split(',')]
                except ValueError:
                    self.config[model]['parameter'] = [x for x in self.config[model]['parameter'].split(',')]

    def cancel_event(self):
        """取消"""
        self.root.destroy()
        sys.exit()

    def apply_event(self):
        """应用"""
        index_path = '--请选择--'
        for model in self.var.keys():
            temp = {}
            if model not in ['index', 'backup-recovery']:
                for key in self.var[model].keys():
                    if isinstance(self.var[model][key], dict):
                        func_temp = {}
                        for func_keys in self.var[model][key].keys():
                            func_temp[func_keys] = self.var[model][key][func_keys].get() if \
                                self.var[model][key][func_keys].get() not in ['--请选择--', 'None', ''] else None
                        temp[key] = func_temp
                    elif not isinstance(self.var[model][key], (str, list)):
                        temp[key] = self.var[model][key].get() if self.var[model][key].get() != '--请选择--' else None
                if self.var[model]['state'].get() and index_path == '--请选择--':
                    index_path = os.path.join(os.path.dirname(self.var[model]['output'].get()), 'index.csv')
                self.config[model] = temp
        self.var['index']['path'].set(index_path)
        self.config['index'] = index_path

    def bottom_button(self, framework):
        url = 'https://pan.baidu.com/s/1WIr67y1pNQCgEyUnuj004w?pwd=STBM'
        Button(framework, text='相关资源下载', command=lambda: web.open(url),
               font=self.Text, bd=0, fg='blue').place(x=15, y=710, width=100, height=25)
        Button(framework, text='确 定', command=lambda: self.ok_event(),
               font=self.Text).place(x=309, y=710, width=70, height=25)
        Button(framework, text='取 消', command=lambda: self.cancel_event(),
               font=self.Text).place(x=409, y=710, width=70, height=25)
        Button(framework, text='应 用', command=lambda: self.apply_event(),
               font=self.Text).place(x=509, y=710, width=70, height=25)

    def custom_function(self, key):
        """获取文本变量"""
        def default_custom_var():
            for model in self.var.keys():
                if model not in ['index', 'backup-recovery']:
                    for function in self.var[model]['custom-function'].keys():
                        self.var[model]['custom-function'][function].set(None)
            window.destroy()

        def select_folder(function):
            """获取输出路径"""
            newDir = askopenfilename(initialdir=self.current_path, title='选择自定义函数',
                                     filetypes=[("python文件", ".py")]).replace('/', '\\')
            None if not newDir else self.var[key]['custom-function'][function].set(newDir)
            self.custom_function_var[key][function].config(state='normal')  # 设置Entry组件的状态为正常
            self.custom_function_var[key][function].delete(0, 'end')
            self.custom_function_var[key][function].insert(0, self.var[key]['custom-function'][function].get())
            self.custom_function_var[key][function].config(state='readonly')  # 设置Entry组件的状态为只读

        height = 115 + 35 * len(self.var[key]['custom-function'].keys())
        window = Tk()
        window.geometry("700x%d+500+50" % height)
        window.resizable(0, 0)  # 防止用户调整尺寸
        window.title('自定义外部函数')
        group = LabelFrame(window, text="外部函数", labelanchor=N, font=self.Text)
        group.place(x=15, y=15, width=670, height=height - 70)
        self.custom_function_var.update({key: {}})
        for index, function in enumerate(self.var[key]['custom-function'].keys()):
            input_label = Label(group, text=function, foreground='black', font=self.Text)
            input_label.place(x=15, y=15 + index * 35, width=100, height=25)
            self.custom_function_var[key].update(
                {function: Entry(group, textvariable=self.var[key]['custom-function'][function], font=self.Text)})
            self.custom_function_var[key][function].delete(0, 'end')
            self.custom_function_var[key][function].insert(0, '--请选择--')
            self.custom_function_var[key][function].config(state='readonly')  # 设置Entry组件的状态为只读
            self.custom_function_var[key][function].place(x=115, y=15 + index * 35, width=460, height=25)
            button = Button(group, text='打开目录', font=self.Text, command=lambda t=function: select_folder(t))
            button.place(x=580, y=15 + index * 35, width=70, height=25)
        clear = Button(window, text='取  消', font=self.Text, command=lambda: default_custom_var())
        clear.place(x=15, y=height - 45, width=80, height=30)
        okay = Button(window, text='确  认', font=self.Text, command=lambda: window.destroy())
        okay.place(x=605, y=height - 45, width=80, height=30)
        window.mainloop()

    def model_cycle(self, notebook):

        def main(framework, state='normal'):

            def selection_changed():
                selected_option = combobox1.get()
                english_option = options[selected_option]
                self.var['cycle']['division-way'].set(english_option)

            options = {'刀盘转速': 'Rotate Speed', '推进速度': 'Advance Speed', '环号': 'Ring', '里程(每米)': 'Meter'}
            button = Checkbutton(framework, text="调 试", variable=self.var['cycle']['debug'],
                                 onvalue=True, offvalue=False, font=self.Text, state=state)
            button.place(x=490, y=15, width=70, height=25)
            # 基础设置
            group = LabelFrame(framework, text="基本设置", labelanchor=N, font=self.Text)
            group.place(x=10, y=50, width=570, height=150)
            input_label = Label(group, text="源文件:", state=state, foreground='black', font=self.Text)
            input_label.place(x=15, y=15, width=60, height=25)
            input_entry = Entry(group, textvariable=self.var['cycle']['input'],
                                state=(state if state == 'disabled' else 'readonly'), font=self.Text)
            input_entry.place(x=75, y=15, width=400, height=25)
            input_button = Button(group, text='打开目录', command=lambda: self.input_event(key='cycle'),
                                  state=state, font=self.Text)
            input_button.place(x=480, y=15, width=70, height=25)
            output_label = Label(group, text="输  出:", state=state, foreground='black', font=self.Text)
            output_label.place(x=15, y=50, width=60, height=25)
            output_entry = Entry(group, textvariable=self.var['cycle']['output'],
                                 state=(state if state == 'disabled' else 'readonly'), font=self.Text)
            output_entry.place(x=75, y=50, width=400, height=25)
            output_button = Button(group, text='另存目录', command=lambda: self.output_event(key='cycle'),
                                   state=state, font=self.Text)
            output_button.place(x=480, y=50, width=70, height=25)
            parm_label = Label(group, text="参  数:", state=state, foreground='black', font=self.Text)
            parm_label.place(x=15, y=85, width=60, height=25)
            parm_entry = Entry(group, textvariable=self.var['cycle']['parameter'],
                               state=(state if state == 'disabled' else 'readonly'), font=self.Text)
            parm_entry.place(x=75, y=85, width=400, height=25)
            parm_button = Button(group, text='更   改', command=lambda: self.parm_event(key='cycle'),
                                 state=state, font=self.Text)
            parm_button.place(x=480, y=85, width=70, height=25)
            # 高级设置
            group = LabelFrame(framework, text="高级设置", labelanchor=N, font=self.Text)
            group.place(x=10, y=225, width=570, height=215)
            label1 = Label(group, text='循环段划分依据', font=self.Text, state=state)
            label1.place(x=14, y=15, width=140, height=25)
            combobox1 = Combobox(group, values=self.var['cycle']['division-way-option'], state=state)
            combobox1.set({v: k for k, v in options.items()}[self.var['cycle']['division-way'].get()])
            combobox1.bind('<<ComboboxSelected>>', selection_changed)  # 绑定选择项变化的回调函数
            combobox1.place(x=160, y=15, width=310, height=25)
            label2_1 = Label(group, text='循环段时间间隔', font=self.Text, state=state)
            label2_1.place(x=14, y=50, width=140, height=25)
            entry2 = Entry(group, textvariable=self.var['cycle']['interval-time'], state=state, font=self.Text)
            entry2.place(x=160, y=50, width=310, height=25)
            label2_2 = Label(group, text=' s', font=self.Text, state=state)
            label2_2.place(x=475, y=50, width=70, height=25)
            label3_1 = Label(group, text='掘进长度下限值', font=self.Text, state=state)
            label3_1.place(x=14, y=85, width=140, height=25)
            entry3 = Entry(group, textvariable=self.var['cycle']['velocity-min'], state=state, font=self.Text)
            entry3.place(x=160, y=85, width=310, height=25)
            label3_2 = Label(group, text=' mm', font=self.Text, state=state)
            label3_2.place(x=475, y=85, width=70, height=25)
            label4_1 = Label(group, text='掘进速度下限值', font=self.Text, state=state)
            label4_1.place(x=14, y=120, width=140, height=25)
            entry4 = Entry(group, textvariable=self.var['cycle']['length-min'], state=state, font=self.Text)
            entry4.place(x=160, y=120, width=310, height=25)
            label4_2 = Label(group, text=' mm/min', font=self.Text, state=state)
            label4_2.place(x=475, y=120, width=70, height=25)
            label5_1 = Label(group, text='外部模块调用', font=self.Text, state=state)
            label5_1.place(x=14, y=155, width=140, height=25)
            button5_2 = Button(group, text='自定义...', command=lambda: self.custom_function('cycle'),
                               font=self.Text, bd=0, fg='blue', state=state)
            button5_2.place(x=160, y=155, width=310, height=25)
            # 程序说明
            group = LabelFrame(framework, text="模块说明", labelanchor=N, font=self.Text)
            group.place(x=10, y=465, width=570, height=110)
            label6_1 = Label(group, text=self.var['cycle']['description'], font=self.Text, state=state)
            label6_1.place(x=10, y=5, width=550, height=80)

        frame = Frame(self.root)  # 2 创建选项卡1的容器框架
        notebook.add(frame, text='\n 划   分 \n')  # 3 装入框架1到选项卡1
        self.tab.update({'cycle': frame})  # 3 装入框架1到选项卡1
        if self.var['cycle']['state'].get():
            main(framework=frame, state='normal')
        else:
            main(framework=frame, state='disabled')
        Radiobutton(frame, text="启 用", variable=self.var['cycle']['state'],
                    command=lambda: main(framework=frame, state='normal'),
                    value=True, font=self.Text).place(x=50, y=15, width=60, height=25)
        Radiobutton(frame, text="禁 用", variable=self.var['cycle']['state'],
                    command=lambda: main(framework=frame, state='disabled'),
                    value=False, font=self.Text).place(x=270, y=15, width=60, height=25)
        self.bottom_button(frame)

    def model_extract(self, notebook):

        def main(framework, state='normal'):
            button = Checkbutton(framework, text="调 试", variable=self.var['extract']['debug'],
                                 onvalue=True, offvalue=False, state=state, font=self.Text)
            button.place(x=490, y=15, width=70, height=25)
            # 基础设置
            group = LabelFrame(framework, text="基本设置", labelanchor=N, font=self.Text)
            group.place(x=10, y=50, width=570, height=150)
            input_label = Label(group, text="源文件:", state=state, foreground='black', font=self.Text)
            input_label.place(x=15, y=15, width=60, height=25)
            input_entry = Entry(group, textvariable=self.var['extract']['input'],
                                state=(state if state == 'disabled' else 'readonly'), font=self.Text)
            input_entry.place(x=75, y=15, width=400, height=25)
            input_button = Button(group, text='打开目录', command=lambda: self.input_event(key='extract'),
                                  state=state, font=self.Text)
            input_button.place(x=480, y=15, width=70, height=25)
            output_label = Label(group, text="输  出:", state=state, foreground='black', font=self.Text)
            output_label.place(x=15, y=50, width=60, height=25)
            output_entry = Entry(group, textvariable=self.var['extract']['output'],
                                 state=(state if state == 'disabled' else 'readonly'), font=self.Text)
            output_entry.place(x=75, y=50, width=400, height=25)
            output_button = Button(group, text='另存目录', command=lambda: self.output_event(key='extract'),
                                   state=state, font=self.Text)
            output_button.place(x=480, y=50, width=70, height=25)
            parm_label = Label(group, text="参  数:", state=state, foreground='black', font=self.Text)
            parm_label.place(x=15, y=85, width=60, height=25)
            parm_entry = Entry(group, textvariable=self.var['extract']['parameter'],
                               state=(state if state == 'disabled' else 'readonly'), font=self.Text)
            parm_entry.place(x=75, y=85, width=400, height=25)
            parm_button = Button(group, text='更   改', command=lambda: self.parm_event(key='extract'),
                                 state=state, font=self.Text)
            parm_button.place(x=480, y=85, width=70, height=25)
            # 高级设置
            group = LabelFrame(framework, text="高级设置", labelanchor=N, font=self.Text)
            group.place(x=10, y=225, width=570, height=75)
            label1_1 = Label(group, text='外部模块调用', font=self.Text, state=state)
            label1_1.place(x=14, y=15, width=140, height=25)
            button1_2 = Button(group, text='自定义...', command=lambda: self.custom_function('extract'),
                               font=self.Text, bd=0, fg='blue', state=state)
            button1_2.place(x=160, y=15, width=310, height=25)
            # 程序说明
            group = LabelFrame(framework, text="模块说明", labelanchor=N, font=self.Text)
            group.place(x=10, y=325, width=570, height=60)
            label2_1 = Label(group, text=self.var['extract']['description'], font=self.Text, state=state)
            label2_1.place(x=10, y=5, width=550, height=30)

        frame = Frame(self.root)  # 2 创建选项卡1的容器框架
        notebook.add(frame, text='\n 提   取 \n')  # 3 装入框架1到选项卡1
        self.tab.update({'extract': frame})  # 3 装入框架1到选项卡1
        if self.var['extract']['state'].get():
            main(framework=frame, state='normal')
        else:
            main(framework=frame, state='disabled')
        Radiobutton(frame, text="启 用", variable=self.var['extract']['state'],
                    command=lambda: main(framework=frame, state='normal'),
                    value=True, font=self.Text).place(x=50, y=15, width=60, height=25)
        Radiobutton(frame, text="禁 用", variable=self.var['extract']['state'],
                    command=lambda: main(framework=frame, state='disabled'),
                    value=False, font=self.Text).place(x=270, y=15, width=60, height=25)

        self.bottom_button(frame)

    def model_class(self, notebook):

        def main(framework, state='normal'):

            def class_A1():
                local_state = 'normal' if self.var['class']['id-a1'].get() else 'disabled'
                local_state = local_state if self.var['class']['state'].get() else 'disabled'
                label1 = Label(group2, text='掘进长度下限值', font=self.Text, state=local_state)
                label1.place(x=240, y=15, width=120, height=25)
                entry2 = Entry(group2, textvariable=self.var['class']['length-min'], state=local_state, font=self.Text)
                entry2.place(x=370, y=15, width=100, height=25)
                label3_1 = Label(group2, text=' mm', font=self.Text, state=local_state)
                label3_1.place(x=475, y=15, width=70, height=25)

            def class_B1():
                local_state = 'normal' if self.var['class']['id-b1'].get() else 'disabled'
                local_state = local_state if self.var['class']['state'].get() else 'disabled'
                label1 = Label(group2, text='推进速度上限值', font=self.Text, state=local_state)
                label1.place(x=240, y=50, width=120, height=25)
                entry2 = Entry(group2, textvariable=self.var['class']['velocity-max'],
                               state=local_state, font=self.Text)
                entry2.place(x=370, y=50, width=100, height=25)
                label3_1 = Label(group2, text=' mm/min', font=self.Text, state=local_state)
                label3_1.place(x=475, y=50, width=70, height=25)

            def class_B2():
                local_state = 'normal' if self.var['class']['id-b2'].get() else 'disabled'
                local_state = local_state if self.var['class']['state'].get() else 'disabled'
                label1 = Label(group2, text=' 参数恒定时间 ', font=self.Text, state=local_state)
                label1.place(x=240, y=85, width=120, height=25)
                entry2 = Entry(group2, textvariable=self.var['class']['constant-time'], state=local_state,
                               font=self.Text)
                entry2.place(x=370, y=85, width=100, height=25)
                label3_1 = Label(group2, text=' s', font=self.Text, state=local_state)
                label3_1.place(x=475, y=85, width=70, height=25)

            def class_C1():
                pass

            def class_C2():
                pass

            def class_D1():
                local_state = 'normal' if self.var['class']['id-d1'].get() else 'disabled'
                local_state = local_state if self.var['class']['state'].get() else 'disabled'
                label1 = Label(group2, text=' 工程项目类型 ', font=self.Text, state=local_state)
                label1.place(x=240, y=190, width=120, height=25)
                combobox1 = Combobox(group2, values=self.var['class']['project-option'], state=local_state,
                                     textvariable=self.var['class']['project'])
                combobox1.place(x=370, y=190, width=100, height=25)
                label3_1 = Label(group2, text='  ', font=self.Text, state=local_state)
                label3_1.place(x=475, y=190, width=70, height=25)

            def class_E1():
                local_state = 'normal' if self.var['class']['id-e1'].get() else 'disabled'
                local_state = local_state if self.var['class']['state'].get() else 'disabled'
                label1 = Label(group2, text='掘进数据缺失率', font=self.Text, state=local_state)
                label1.place(x=240, y=225, width=120, height=25)
                entry2 = Entry(group2, textvariable=self.var['class']['missing_ratio'],
                               state=local_state, font=self.Text)
                entry2.place(x=370, y=225, width=100, height=25)
                label3_1 = Label(group2, text=' %', font=self.Text, state=local_state)
                label3_1.place(x=475, y=225, width=70, height=25)

            button = Checkbutton(framework, text="调 试", variable=self.var['class']['debug'],
                                 onvalue=True, offvalue=False, state=state, font=self.Text)
            button.place(x=490, y=15, width=70, height=25)
            # 基础设置
            group1 = LabelFrame(framework, text="基本设置", labelanchor=N, font=self.Text)
            group1.place(x=10, y=50, width=570, height=150)
            input_label = Label(group1, text="源文件:", state=state, foreground='black', font=self.Text)
            input_label.place(x=15, y=15, width=60, height=25)
            input_entry = Entry(group1, textvariable=self.var['class']['input'],
                                state=(state if state == 'disabled' else 'readonly'), font=self.Text)
            input_entry.place(x=75, y=15, width=400, height=25)
            input_button = Button(group1, text='打开目录', command=lambda: self.input_event(key='class'),
                                  state=state, font=self.Text)
            input_button.place(x=480, y=15, width=70, height=25)
            output_label = Label(group1, text="输  出:", state=state, foreground='black', font=self.Text)
            output_label.place(x=15, y=50, width=60, height=25)
            output_entry = Entry(group1, textvariable=self.var['class']['output'],
                                 state=(state if state == 'disabled' else 'readonly'), font=self.Text)
            output_entry.place(x=75, y=50, width=400, height=25)
            output_button = Button(group1, text='另存目录', command=lambda: self.output_event(key='class'),
                                   state=state, font=self.Text)
            output_button.place(x=480, y=50, width=70, height=25)
            parm_label = Label(group1, text="参  数:", state=state, foreground='black', font=self.Text)
            parm_label.place(x=15, y=85, width=60, height=25)
            parm_entry = Entry(group1, textvariable=self.var['class']['parameter'],
                               state=(state if state == 'disabled' else 'readonly'), font=self.Text)
            parm_entry.place(x=75, y=85, width=400, height=25)
            parm_button = Button(group1, text='更   改', command=lambda: self.parm_event(key='class'),
                                 state=state, font=self.Text)
            parm_button.place(x=480, y=85, width=70, height=25)
            # 高级设置
            group2 = LabelFrame(framework, text="高级设置", labelanchor=N, font=self.Text)
            group2.place(x=10, y=225, width=570, height=320)  # 285
            class_A1()
            buttonA1 = Checkbutton(group2, text=" A1类异常(掘进长度过短)", variable=self.var['class']['id-a1'], onvalue=True,
                                   offvalue=False, font=self.Text, state=state, command=class_A1)
            buttonA1.place(x=20, y=15, width=200, height=25)
            class_B1()
            buttonB1 = Checkbutton(group2, text=" B1类异常(推进速度超限)", variable=self.var['class']['id-b1'], onvalue=True,
                                   offvalue=False, font=self.Text, state=state, command=class_B1)
            buttonB1.place(x=20, y=50, width=200, height=25)
            class_B2()
            buttonB2 = Checkbutton(group2, text=" B2类异常(数据传输异常)", variable=self.var['class']['id-b2'], onvalue=True,
                                   offvalue=False, font=self.Text, state=state, command=class_B2)
            buttonB2.place(x=20, y=85, width=200, height=25)
            class_C1()
            buttonC1 = Checkbutton(group2, text=" C1类异常(正弦波扭矩值)", variable=self.var['class']['id-c1'], onvalue=True,
                                   offvalue=False, font=self.Text, state=state, command=class_C1)
            buttonC1.place(x=20, y=120, width=200, height=25)
            class_C2()
            buttonC2 = Checkbutton(group2, text=" C2类异常(中途短暂停机)", variable=self.var['class']['id-c2'], onvalue=True,
                                   offvalue=False, font=self.Text, state=state, command=class_C2)
            buttonC2.place(x=20, y=155, width=200, height=25)
            class_D1()
            buttonD1 = Checkbutton(group2, text=" D1类异常(频繁调整速度)", variable=self.var['class']['id-d1'], onvalue=True,
                                   offvalue=False, font=self.Text, state=state, command=class_D1)
            buttonD1.place(x=20, y=190, width=200, height=25)
            class_E1()
            buttonE1 = Checkbutton(group2, text=" E1类异常(数据缺失过多)", variable=self.var['class']['id-e1'], onvalue=True,
                                   offvalue=False, font=self.Text, state=state, command=class_E1)
            buttonE1.place(x=20, y=225, width=200, height=25)
            label1_1 = Label(group2, text='外部模块调用', font=self.Text, state=state)
            label1_1.place(x=20, y=260, width=200, height=25)
            button1_2 = Button(group2, text='自定义...', command=lambda: self.custom_function('class'),
                               font=self.Text, bd=0, fg='blue', state=state)
            button1_2.place(x=240, y=260, width=300, height=25)
            # 程序说明
            group3 = LabelFrame(framework, text="模块说明", labelanchor=N, font=self.Text)
            group3.place(x=10, y=570, width=570, height=110)  # +25
            label3 = Label(group3, text=self.var['class']['description'], font=self.Text, anchor='w', state=state)
            label3.place(x=10, y=5, width=550, height=80)

        frame = Frame(self.root)  # 2 创建选项卡1的容器框架
        notebook.add(frame, text='\n 分   类 \n')  # 3 装入框架1到选项卡1
        self.tab.update({'class': frame})  # 3 装入框架1到选项卡1
        if self.var['class']['state'].get():
            main(framework=frame, state='normal')
        else:
            main(framework=frame, state='disabled')
        Radiobutton(frame, text="启 用", variable=self.var['class']['state'],
                    command=lambda: main(framework=frame, state='normal'),
                    value=True, font=self.Text).place(x=50, y=15, width=60, height=25)
        Radiobutton(frame, text="禁 用", variable=self.var['class']['state'],
                    command=lambda: main(framework=frame, state='disabled'),
                    value=False, font=self.Text).place(x=270, y=15, width=60, height=25)
        self.bottom_button(frame)

    def model_clean(self, notebook):

        def main(framework, state='normal'):

            def clean_A1():
                local_state = 'normal' if self.var['clean']['correct-a1'].get() else 'disabled'
                local_state = local_state if self.var['clean']['state'].get() else 'disabled'
                if self.var['clean']['correct-a1'].get():
                    label1 = Label(group2, text='未定义相关修正方法!', font=self.Text, fg='red', state=local_state)
                    label1.place(x=270, y=15, width=260, height=25)
                else:
                    label1 = Label(group2, text=' ', font=self.Text, state=local_state)
                    label1.place(x=270, y=15, width=260, height=25)

            def clean_B1():
                local_state = 'normal' if self.var['clean']['correct-b1'].get() else 'disabled'
                local_state = local_state if self.var['clean']['state'].get() else 'disabled'
                label1 = Label(group2, text='推进速度上限值', font=self.Text, state=local_state)
                label1.place(x=270, y=50, width=120, height=25)
                entry2 = Entry(group2, textvariable=self.var['clean']['velocity-max'],
                               state=local_state, font=self.Text)
                entry2.place(x=400, y=50, width=70, height=25)
                label3 = Label(group2, text=' mm/min', font=self.Text, state=local_state)
                label3.place(x=475, y=50, width=70, height=25)

            def clean_B2():
                local_state = 'normal' if self.var['clean']['correct-b2'].get() else 'disabled'
                local_state = local_state if self.var['clean']['state'].get() else 'disabled'
                if self.var['clean']['correct-b2'].get():
                    label1 = Label(group2, text='未定义相关修正方法!', font=self.Text, fg='red', state=local_state)
                    label1.place(x=270, y=85, width=260, height=25)
                else:
                    label1 = Label(group2, text=' ', font=self.Text, state=local_state)
                    label1.place(x=270, y=85, width=260, height=25)

            def clean_C1():
                local_state = 'normal' if self.var['clean']['correct-c1'].get() else 'disabled'
                local_state = local_state if self.var['clean']['state'].get() else 'disabled'
                if self.var['clean']['correct-c1'].get():
                    label1 = Label(group2, text='未定义相关修正方法!', font=self.Text, fg='red', state=local_state)
                    label1.place(x=270, y=120, width=260, height=25)
                else:
                    label1 = Label(group2, text=' ', font=self.Text, state=local_state)
                    label1.place(x=270, y=120, width=260, height=25)

            def clean_C2():
                local_state = 'normal' if self.var['clean']['correct-c2'].get() else 'disabled'
                local_state = local_state if self.var['clean']['state'].get() else 'disabled'
                if self.var['clean']['correct-c2'].get():
                    label1 = Label(group2, text='未定义相关修正方法!', font=self.Text, fg='red', state=local_state)
                    label1.place(x=270, y=155, width=260, height=25)
                else:
                    label1 = Label(group2, text=' ', font=self.Text, state=local_state)
                    label1.place(x=270, y=155, width=260, height=25)

            def clean_D1():
                local_state = 'normal' if self.var['clean']['correct-d1'].get() else 'disabled'
                local_state = local_state if self.var['clean']['state'].get() else 'disabled'
                if self.var['clean']['correct-d1'].get():
                    label1 = Label(group2, text='未定义相关修正方法!', font=self.Text, fg='red', state=local_state)
                    label1.place(x=270, y=190, width=260, height=25)
                else:
                    label1 = Label(group2, text=' ', font=self.Text, state=local_state)
                    label1.place(x=270, y=190, width=260, height=25)

            def clean_E1():
                local_state = 'normal' if self.var['clean']['correct-e1'].get() else 'disabled'
                local_state = local_state if self.var['clean']['state'].get() else 'disabled'
                if self.var['clean']['correct-e1'].get():
                    label1 = Label(group2, text='未定义相关修正方法!', font=self.Text, fg='red', state=local_state)
                    label1.place(x=270, y=225, width=260, height=25)
                else:
                    label1 = Label(group2, text=' ', font=self.Text, state=local_state)
                    label1.place(x=270, y=225, width=260, height=25)

            button = Checkbutton(framework, text="调 试", variable=self.var['clean']['debug'],
                                 onvalue=True, offvalue=False, state=state, font=self.Text)
            button.place(x=490, y=15, width=70, height=25)
            # 基础设置
            group1 = LabelFrame(framework, text="基本设置", labelanchor=N, font=self.Text)
            group1.place(x=10, y=50, width=570, height=150)
            input_label = Label(group1, text="源文件:", state=state, foreground='black', font=self.Text)
            input_label.place(x=15, y=15, width=60, height=25)
            input_entry = Entry(group1, textvariable=self.var['clean']['input'],
                                state=(state if state == 'disabled' else 'readonly'), font=self.Text)
            input_entry.place(x=75, y=15, width=400, height=25)
            input_button = Button(group1, text='打开目录', command=lambda: self.input_event(key='clean'),
                                  state=state, font=self.Text)
            input_button.place(x=480, y=15, width=70, height=25)
            output_label = Label(group1, text="输  出:", state=state, foreground='black', font=self.Text)
            output_label.place(x=15, y=50, width=60, height=25)
            output_entry = Entry(group1, textvariable=self.var['clean']['output'],
                                 state=(state if state == 'disabled' else 'readonly'), font=self.Text)
            output_entry.place(x=75, y=50, width=400, height=25)
            output_button = Button(group1, text='另存目录', command=lambda: self.output_event(key='clean'),
                                   state=state, font=self.Text)
            output_button.place(x=480, y=50, width=70, height=25)
            parm_label = Label(group1, text="参  数:", state=state, foreground='black', font=self.Text)
            parm_label.place(x=15, y=85, width=60, height=25)
            parm_entry = Entry(group1, textvariable=self.var['clean']['parameter'],
                               state=(state if state == 'disabled' else 'readonly'), font=self.Text)
            parm_entry.place(x=75, y=85, width=400, height=25)
            parm_button = Button(group1, text='更   改', command=lambda: self.parm_event(key='clean'),
                                 state=state, font=self.Text)
            parm_button.place(x=480, y=85, width=70, height=25)
            # 高级设置
            group2 = LabelFrame(framework, text="高级设置", labelanchor=N, font=self.Text)
            group2.place(x=10, y=225, width=570, height=320)
            clean_A1()
            buttonA1 = Checkbutton(group2, text=" 修正A1类异常(掘进长度过短)", variable=self.var['clean']['correct-a1'],
                                   onvalue=True, offvalue=False, font=self.Text, state=state, command=clean_A1)
            buttonA1.place(x=20, y=15, width=230, height=25)
            clean_B1()
            buttonB1 = Checkbutton(group2, text=" 修正B1类异常(推进速度超限)", variable=self.var['clean']['correct-b1'],
                                   onvalue=True, offvalue=False, font=self.Text, state=state, command=clean_B1)
            buttonB1.place(x=20, y=50, width=230, height=25)
            clean_B2()
            buttonB2 = Checkbutton(group2, text=" 修正B2类异常(数据传输异常)", variable=self.var['clean']['correct-b2'],
                                   onvalue=True, offvalue=False, font=self.Text, state=state, command=clean_B2)
            buttonB2.place(x=20, y=85, width=230, height=25)
            clean_C1()
            buttonC1 = Checkbutton(group2, text=" 修正C1类异常(正弦波扭矩值)", variable=self.var['clean']['correct-c1'],
                                   onvalue=True, offvalue=False, font=self.Text, state=state, command=clean_C1)
            buttonC1.place(x=20, y=120, width=230, height=25)
            clean_C2()
            buttonC2 = Checkbutton(group2, text=" 修正C2类异常(中途短暂停机)", variable=self.var['clean']['correct-c2'],
                                   onvalue=True, offvalue=False, font=self.Text, state=state, command=clean_C2)
            buttonC2.place(x=20, y=155, width=230, height=25)
            clean_D1()
            buttonD1 = Checkbutton(group2, text=" 修正D1类异常(频繁调整速度)", variable=self.var['clean']['correct-d1'],
                                   onvalue=True, offvalue=False, font=self.Text, state=state, command=clean_D1)
            buttonD1.place(x=20, y=190, width=230, height=25)
            clean_E1()
            buttonE1 = Checkbutton(group2, text=" 修正E1类异常(数据缺失过多)", variable=self.var['clean']['correct-e1'],
                                   onvalue=True, offvalue=False, font=self.Text, state=state, command=clean_E1)
            buttonE1.place(x=20, y=225, width=230, height=25)
            label1_1 = Label(group2, text='外部模块调用', font=self.Text, state=state)
            label1_1.place(x=20, y=260, width=200, height=25)
            button1_2 = Button(group2, text='自定义...', command=lambda: self.custom_function('clean'),
                               font=self.Text, bd=0, fg='blue', state=state)
            button1_2.place(x=240, y=260, width=300, height=25)
            group3 = LabelFrame(framework, text="模块说明", labelanchor=N, font=self.Text)
            group3.place(x=10, y=570, width=570, height=60)
            label2_1 = Label(group3, text=self.var['clean']['description'], font=self.Text, state=state)
            label2_1.place(x=10, y=5, width=550, height=30)

        frame = Frame(self.root)  # 2 创建选项卡1的容器框架
        notebook.add(frame, text='\n 修   正 \n')  # 3 装入框架1到选项卡1
        self.tab.update({'clean': frame})  # 3 装入框架1到选项卡1
        if self.var['clean']['state'].get():
            main(framework=frame, state='normal')
        else:
            main(framework=frame, state='disabled')
        Radiobutton(frame, text="启 用", variable=self.var['clean']['state'],
                    command=lambda: main(framework=frame, state='normal'),
                    value=True, font=self.Text).place(x=50, y=15, width=60, height=25)
        Radiobutton(frame, text="禁 用", variable=self.var['clean']['state'],
                    command=lambda: main(framework=frame, state='disabled'),
                    value=False, font=self.Text).place(x=270, y=15, width=60, height=25)

        self.bottom_button(frame)

    def model_merge(self, notebook):

        def main(framework, state='normal'):
            button = Checkbutton(framework, text="调 试", variable=self.var['merge']['debug'],
                                 onvalue=True, offvalue=False, state=state, font=self.Text)
            button.place(x=490, y=15, width=70, height=25)
            # 基础设置
            group = LabelFrame(framework, text="基本设置", labelanchor=N, font=self.Text)
            group.place(x=10, y=50, width=570, height=150)
            input_label = Label(group, text="源文件:", state=state, foreground='black', font=self.Text)
            input_label.place(x=15, y=15, width=60, height=25)
            input_entry = Entry(group, textvariable=self.var['merge']['input'],
                                state=(state if state == 'disabled' else 'readonly'), font=self.Text)
            input_entry.place(x=75, y=15, width=400, height=25)
            input_button = Button(group, text='打开目录', command=lambda: self.input_event(key='merge'),
                                  state=state, font=self.Text)
            input_button.place(x=480, y=15, width=70, height=25)
            output_label = Label(group, text="输  出:", state=state, foreground='black', font=self.Text)
            output_label.place(x=15, y=50, width=60, height=25)
            output_entry = Entry(group, textvariable=self.var['merge']['output'],
                                 state=(state if state == 'disabled' else 'readonly'), font=self.Text)
            output_entry.place(x=75, y=50, width=400, height=25)
            output_button = Button(group, text='另存目录', command=lambda: self.output_event(key='merge'),
                                   state=state, font=self.Text)
            output_button.place(x=480, y=50, width=70, height=25)
            parm_label = Label(group, text="参  数:", state=state, font=self.Text)
            parm_label.place(x=15, y=85, width=60, height=25)
            parm_entry = Entry(group, textvariable=self.var['merge']['parameter'],
                               state=(state if state == 'disabled' else 'readonly'), font=self.Text)
            parm_entry.place(x=75, y=85, width=400, height=25)
            parm_button = Button(group, text='更   改', command=lambda: self.parm_event(key='merge'),
                                 state=state, font=self.Text)
            parm_button.place(x=480, y=85, width=70, height=25)
            # 高级设置
            group = LabelFrame(framework, text="高级设置", labelanchor=N, font=self.Text)
            group.place(x=10, y=225, width=570, height=75)
            label1_1 = Label(group, text='外部模块调用', font=self.Text, state=state)
            label1_1.place(x=14, y=15, width=140, height=25)
            button1_2 = Button(group, text='自定义...', command=lambda: self.custom_function('merge'),
                               font=self.Text, bd=0, fg='blue', state=state)
            button1_2.place(x=160, y=15, width=310, height=25)
            # 程序说明
            group = LabelFrame(framework, text="模块说明", labelanchor=N, font=self.Text)
            group.place(x=10, y=325, width=570, height=60)
            label2_1 = Label(group, text=self.var['merge']['description'], font=self.Text, state=state)
            label2_1.place(x=10, y=5, width=550, height=30)

        frame = Frame(self.root)  # 2 创建选项卡1的容器框架
        notebook.add(frame, text='\n 合   并 \n')  # 3 装入框架1到选项卡1
        self.tab.update({'merge': frame})  # 3 装入框架1到选项卡1
        if self.var['merge']['state'].get():
            main(framework=frame, state='normal')
        else:
            main(framework=frame, state='disabled')
        Radiobutton(frame, text="启 用", variable=self.var['merge']['state'],
                    command=lambda: main(framework=frame, state='normal'),
                    value=True, font=self.Text).place(x=50, y=15, width=60, height=25)
        Radiobutton(frame, text="禁 用", variable=self.var['merge']['state'],
                    command=lambda: main(framework=frame, state='disabled'),
                    value=False, font=self.Text).place(x=270, y=15, width=60, height=25)
        self.bottom_button(frame)

    def model_split(self, notebook):

        def main(framework, state='normal'):

            def selection_changed():
                selected_option = combobox1.get()
                english_option = options[selected_option]
                self.var['split']['partition-method'].set(english_option)

            options = {'平均值': 'Average', '核密度估计': 'Kernel Density'}
            button = Checkbutton(framework, text="调 试", variable=self.var['split']['debug'],
                                 onvalue=True, offvalue=False, state=state, font=self.Text)
            button.place(x=490, y=15, width=70, height=25)
            # 基础设置
            group = LabelFrame(framework, text="基本设置", labelanchor=N, font=self.Text)
            group.place(x=10, y=50, width=570, height=150)
            input_label = Label(group, text="源文件:", state=state, foreground='black', font=self.Text)
            input_label.place(x=15, y=15, width=60, height=25)
            input_entry = Entry(group, textvariable=self.var['split']['input'],
                                state=(state if state == 'disabled' else 'readonly'), font=self.Text)
            input_entry.place(x=75, y=15, width=400, height=25)
            input_button = Button(group, text='打开目录', command=lambda: self.input_event(key='split'),
                                  state=state, font=self.Text)
            input_button.place(x=480, y=15, width=70, height=25)
            output_label = Label(group, text="输  出:", state=state, foreground='black', font=self.Text)
            output_label.place(x=15, y=50, width=60, height=25)
            output_entry = Entry(group, textvariable=self.var['split']['output'],
                                 state=(state if state == 'disabled' else 'readonly'), font=self.Text)
            output_entry.place(x=75, y=50, width=400, height=25)
            output_button = Button(group, text='另存目录', command=lambda: self.output_event(key='split'),
                                   state=state, font=self.Text)
            output_button.place(x=480, y=50, width=70, height=25)
            parm_label = Label(group, text="参  数:", state=state, font=self.Text)
            parm_label.place(x=15, y=85, width=60, height=25)
            parm_entry = Entry(group, textvariable=self.var['split']['parameter'],
                               state=(state if state == 'disabled' else 'readonly'), font=self.Text)
            parm_entry.place(x=75, y=85, width=400, height=25)
            parm_button = Button(group, text='更   改', command=lambda: self.parm_event(key='split'),
                                 state=state, font=self.Text)
            parm_button.place(x=480, y=85, width=70, height=25)
            # 高级设置
            group = LabelFrame(framework, text="高级设置", labelanchor=N, font=self.Text)
            group.place(x=10, y=225, width=570, height=145)
            label1 = Label(group, text='内部段划分方法', font=self.Text, state=state)
            label1.place(x=14, y=15, width=140, height=25)
            combobox1 = Combobox(group, values=self.var['split']['partition-method-option'], state=state)
            combobox1.set({v: k for k, v in options.items()}[self.var['split']['partition-method'].get()])
            combobox1.bind('<<ComboboxSelected>>', selection_changed)  # 绑定选择项变化的回调函数
            combobox1.place(x=160, y=15, width=310, height=25)
            label2_1 = Label(group, text=' 时间记录下限值', font=self.Text, state=state)
            label2_1.place(x=14, y=50, width=140, height=25)
            entry2 = Entry(group, textvariable=self.var['split']['time-min'], state=state, font=self.Text)
            entry2.place(x=160, y=50, width=310, height=25)
            label2_2 = Label(group, text=' s', font=self.Text, state=state)
            label2_2.place(x=475, y=50, width=70, height=25)
            label3_1 = Label(group, text='外部模块调用', font=self.Text, state=state)
            label3_1.place(x=14, y=85, width=140, height=25)
            button3_2 = Button(group, text='自定义...', command=lambda: self.custom_function('split'),
                               font=self.Text, bd=0, fg='blue', state=state)
            button3_2.place(x=160, y=85, width=310, height=25)
            # 程序说明
            group = LabelFrame(framework, text="模块说明", labelanchor=N, font=self.Text)
            group.place(x=10, y=395, width=570, height=100)
            label4_1 = Label(group, text=self.var['split']['description'], font=self.Text, state=state)
            label4_1.place(x=10, y=5, width=550, height=70)

        frame = Frame(self.root)  # 2 创建选项卡1的容器框架
        notebook.add(frame, text='\n 分   割 \n')  # 3 装入框架1到选项卡1
        self.tab.update({'split': frame})  # 3 装入框架1到选项卡1
        if self.var['split']['state'].get():
            main(framework=frame, state='normal')
        else:
            main(framework=frame, state='disabled')
        Radiobutton(frame, text="启 用", variable=self.var['split']['state'],
                    command=lambda: main(framework=frame, state='normal'),
                    value=True, font=self.Text).place(x=50, y=15, width=60, height=25)
        Radiobutton(frame, text="禁 用", variable=self.var['split']['state'],
                    command=lambda: main(framework=frame, state='disabled'),
                    value=False, font=self.Text).place(x=270, y=15, width=60, height=25)
        self.bottom_button(frame)

    def model_filter(self, notebook):

        def main(framework, state='normal'):
            button = Checkbutton(framework, text="调 试", variable=self.var['filter']['debug'],
                                 onvalue=True, offvalue=False, state=state, font=self.Text)
            button.place(x=490, y=15, width=70, height=25)
            # 基础设置
            group = LabelFrame(framework, text="基本设置", labelanchor=N, font=self.Text)
            group.place(x=10, y=50, width=570, height=150)
            input_label = Label(group, text="源文件:", state=state, foreground='black', font=self.Text)
            input_label.place(x=15, y=15, width=60, height=25)
            input_entry = Entry(group, textvariable=self.var['filter']['input'],
                                state=(state if state == 'disabled' else 'readonly'), font=self.Text)
            input_entry.place(x=75, y=15, width=400, height=25)
            input_button = Button(group, text='打开目录', command=lambda: self.input_event(key='filter'),
                                  state=state, font=self.Text)
            input_button.place(x=480, y=15, width=70, height=25)
            output_label = Label(group, text="输  出:", state=state, foreground='black', font=self.Text)
            output_label.place(x=15, y=50, width=60, height=25)
            output_entry = Entry(group, textvariable=self.var['filter']['output'],
                                 state=(state if state == 'disabled' else 'readonly'), font=self.Text)
            output_entry.place(x=75, y=50, width=400, height=25)
            output_button = Button(group, text='另存目录', command=lambda: self.output_event(key='filter'),
                                   state=state, font=self.Text)
            output_button.place(x=480, y=50, width=70, height=25)
            parm_label = Label(group, text="参  数:", state=state, font=self.Text)
            parm_label.place(x=15, y=85, width=60, height=25)
            parm_entry = Entry(group, textvariable=self.var['filter']['parameter'],
                               state=(state if state == 'disabled' else 'readonly'), font=self.Text)
            parm_entry.place(x=75, y=85, width=400, height=25)
            parm_button = Button(group, text='更   改', command=lambda: self.parm_event(key='filter'),
                                 state=state, font=self.Text)
            parm_button.place(x=480, y=85, width=70, height=25)
            # 高级设置
            group = LabelFrame(framework, text="高级设置", labelanchor=N, font=self.Text)
            group.place(x=10, y=225, width=570, height=75)
            label1_1 = Label(group, text='外部模块调用', font=self.Text, state=state)
            label1_1.place(x=14, y=15, width=140, height=25)
            button1_2 = Button(group, text='自定义...', command=lambda: self.custom_function('filter'),
                               font=self.Text, bd=0, fg='blue', state=state)
            button1_2.place(x=160, y=15, width=310, height=25)
            # 程序说明
            group = LabelFrame(framework, text="模块说明", labelanchor=N, font=self.Text)
            group.place(x=10, y=325, width=570, height=60)
            label2_1 = Label(group, text=self.var['filter']['description'], font=self.Text, state=state)
            label2_1.place(x=10, y=5, width=550, height=30)

        frame = Frame(self.root)  # 2 创建选项卡1的容器框架
        notebook.add(frame, text='\n 降   噪 \n')  # 3 装入框架1到选项卡1
        self.tab.update({'filter': frame})  # 3 装入框架1到选项卡1
        if self.var['filter']['state'].get():
            main(framework=frame, state='normal')
        else:
            main(framework=frame, state='disabled')
        Radiobutton(frame, text="启 用", variable=self.var['filter']['state'],
                    command=lambda: main(framework=frame, state='normal'),
                    value=True, font=self.Text).place(x=50, y=15, width=60, height=25)
        Radiobutton(frame, text="禁 用", variable=self.var['filter']['state'],
                    command=lambda: main(framework=frame, state='disabled'),
                    value=False, font=self.Text).place(x=270, y=15, width=60, height=25)
        self.bottom_button(frame)

    def model_plot(self, notebook):

        def main(framework, state='normal'):
            button = Checkbutton(framework, text="调 试", variable=self.var['plot']['debug'],
                                 onvalue=True, offvalue=False, state=state, font=self.Text)
            button.place(x=490, y=15, width=70, height=25)
            # 基础设置
            group = LabelFrame(framework, text="基本设置", labelanchor=N, font=self.Text)
            group.place(x=10, y=50, width=570, height=150)
            input_label = Label(group, text="源文件:", state=state, foreground='black', font=self.Text)
            input_label.place(x=15, y=15, width=60, height=25)
            input_entry = Entry(group, textvariable=self.var['plot']['input'],
                                state=(state if state == 'disabled' else 'readonly'), font=self.Text)
            input_entry.place(x=75, y=15, width=400, height=25)
            input_button = Button(group, text='打开目录', command=lambda: self.input_event(key='plot'),
                                  state=state, font=self.Text)
            input_button.place(x=480, y=15, width=70, height=25)
            output_label = Label(group, text="输  出:", state=state, foreground='black', font=self.Text)
            output_label.place(x=15, y=50, width=60, height=25)
            output_entry = Entry(group, textvariable=self.var['plot']['output'],
                                 state=(state if state == 'disabled' else 'readonly'), font=self.Text)
            output_entry.place(x=75, y=50, width=400, height=25)
            output_button = Button(group, text='另存目录', command=lambda: self.output_event(key='plot'),
                                   state=state, font=self.Text)
            output_button.place(x=480, y=50, width=70, height=25)
            parm_label = Label(group, text="参  数:", state=state, font=self.Text)
            parm_label.place(x=15, y=85, width=60, height=25)
            parm_entry = Entry(group, textvariable=self.var['plot']['parameter'],
                               state=(state if state == 'disabled' else 'readonly'), font=self.Text)
            parm_entry.place(x=75, y=85, width=400, height=25)
            parm_button = Button(group, text='更   改', command=lambda: self.parm_event(key='plot'),
                                 state=state, font=self.Text)
            parm_button.place(x=480, y=85, width=70, height=25)
            # 高级设置
            group = LabelFrame(framework, text="高级设置", labelanchor=N, font=self.Text)
            group.place(x=10, y=225, width=570, height=155)
            label1_2 = Label(group, text='宽', font=self.Text, state=state)
            label1_2.place(x=370, y=15, width=30, height=25)
            entry1_3 = Entry(group, textvariable=self.var['plot']['weight'], state=state, font=self.Text)
            entry1_3.place(x=400, y=15, width=60, height=25)
            entry1_4 = Label(group, text='mm', font=self.Text, state=state)
            entry1_4.place(x=460, y=15, width=30, height=25)
            label1_5 = Label(group, text='高', font=self.Text, state=state)
            label1_5.place(x=370, y=55, width=30, height=25)
            entry1_6 = Entry(group, textvariable=self.var['plot']['height'], state=state, font=self.Text)
            entry1_6.place(x=400, y=55, width=60, height=25)
            entry1_7 = Label(group, text='mm', font=self.Text, state=state)
            entry1_7.place(x=460, y=55, width=30, height=25)
            label2_1 = Label(group, text='分辨率', font=self.Text, state=state)
            label2_1.place(x=65, y=15, width=50, height=25)
            combobox2_2 = Combobox(group, values=self.var['plot']['dpi-option'], state=state,
                                   textvariable=self.var['plot']['dpi'])
            combobox2_2.place(x=120, y=15, width=60, height=25)
            label2_3 = Label(group, text=' dpi', font=self.Text, state=state)
            label2_3.place(x=180, y=15, width=30, height=25)
            label2_4 = Label(group, text='格  式', font=self.Text, state=state)
            label2_4.place(x=65, y=55, width=50, height=25)
            combobox2_5 = Combobox(group, values=self.var['plot']['format-option'], state=state,
                                   textvariable=self.var['plot']['format'])
            combobox2_5.place(x=120, y=55, width=60, height=25)
            label2_6 = Label(group, text=' ', font=self.Text, state=state)
            label2_6.place(x=180, y=55, width=70, height=25)
            label3_1 = Label(group, text='外部模块调用', font=self.Text, state=state)
            label3_1.place(x=65, y=95, width=115, height=25)
            button3_2 = Button(group, text='自定义...', command=lambda: self.custom_function('plot'),
                               font=self.Text, bd=0, fg='blue', state=state)
            button3_2.place(x=370, y=95, width=120, height=25)
            # 程序说明
            group = LabelFrame(framework, text="模块说明", labelanchor=N, font=self.Text)
            group.place(x=10, y=445, width=570, height=110)
            label5_1 = Label(group, text=self.var['plot']['description'], font=self.Text, state=state)
            label5_1.place(x=10, y=5, width=550, height=80)

        frame = Frame(self.root)  # 2 创建选项卡1的容器框架
        notebook.add(frame, text='\n 绘   图 \n')  # 3 装入框架1到选项卡1
        self.tab.update({'plot': frame})  # 3 装入框架1到选项卡1
        if self.var['plot']['state'].get():
            main(framework=frame, state='normal')
        else:
            main(framework=frame, state='disabled')
        Radiobutton(frame, text="启 用", variable=self.var['plot']['state'],
                    command=lambda: main(framework=frame, state='normal'),
                    value=True, font=self.Text).place(x=50, y=15, width=60, height=25)
        Radiobutton(frame, text="禁 用", variable=self.var['plot']['state'],
                    command=lambda: main(framework=frame, state='disabled'),
                    value=False, font=self.Text).place(x=270, y=15, width=60, height=25)
        self.bottom_button(frame)

    def model_report(self, notebook):

        def main(framework, state='normal'):

            def water_information():
                local_state = 'normal' if self.var['report']['watermark'].get() else 'disabled'
                local_state = local_state if self.var['report']['state'].get() else 'disabled'
                entry = Entry(group2, textvariable=self.var['report']['watermark-info'],
                              state=local_state, font=self.Text)
                entry.place(x=140, y=55, width=330, height=25)

            def input_event():
                newDir = askdirectory(initialdir=self.current_path, title='打开目录').replace('/', '\\')
                self.var['report']['plot-path'].set(newDir)

            def pic_input():
                local_state = 'normal' if self.var['report']['outer'].get() else 'disabled'
                local_state = local_state if self.var['report']['state'].get() else 'disabled'
                entry = Entry(group2, textvariable=self.var['report']['plot-path'], state=local_state, font=self.Text)
                entry.place(x=140, y=95, width=330, height=25)
                button2 = Button(group2, text='打开目录', command=input_event, state=local_state, font=self.Text)
                button2.place(x=480, y=95, width=70, height=25)

            button = Checkbutton(framework, text="调 试", variable=self.var['report']['debug'],
                                 onvalue=True, offvalue=False, state=state, font=self.Text)
            button.place(x=490, y=15, width=70, height=25)
            # 基础设置
            group1 = LabelFrame(framework, text="基本设置", labelanchor=N, font=self.Text)
            group1.place(x=10, y=50, width=570, height=150)
            input_label = Label(group1, text="源文件:", state=state, foreground='black', font=self.Text)
            input_label.place(x=15, y=15, width=60, height=25)
            input_entry = Entry(group1, textvariable=self.var['report']['input'],
                                state=(state if state == 'disabled' else 'readonly'), font=self.Text)
            input_entry.place(x=75, y=15, width=400, height=25)
            input_button = Button(group1, text='打开目录', command=lambda: self.input_event(key='report'),
                                  state=state, font=self.Text)
            input_button.place(x=480, y=15, width=70, height=25)
            output_label = Label(group1, text="输  出:", state=state, foreground='black', font=self.Text)
            output_label.place(x=15, y=50, width=60, height=25)
            output_entry = Entry(group1, textvariable=self.var['report']['output'],
                                 state=(state if state == 'disabled' else 'readonly'), font=self.Text)
            output_entry.place(x=75, y=50, width=400, height=25)
            output_button = Button(group1, text='另存目录', command=lambda: self.output_event(key='report'),
                                   state=state, font=self.Text)
            output_button.place(x=480, y=50, width=70, height=25)
            parm_label = Label(group1, text="参  数:", state=state, font=self.Text)
            parm_label.place(x=15, y=85, width=60, height=25)
            parm_entry = Entry(group1, textvariable=self.var['report']['parameter'],
                               state=(state if state == 'disabled' else 'readonly'), font=self.Text)
            parm_entry.place(x=75, y=85, width=400, height=25)
            parm_button = Button(group1, text='更   改', command=lambda: self.parm_event(key='report'),
                                 state=state, font=self.Text)
            parm_button.place(x=480, y=85, width=70, height=25)
            # 高级设置
            group2 = LabelFrame(framework, text="高级设置", labelanchor=N, font=self.Text)
            group2.place(x=10, y=225, width=570, height=195)
            button1_1 = Checkbutton(group2, text=" 添加封面", variable=self.var['report']['cover'],
                                    onvalue=True, offvalue=False, font=self.Text, state=state)
            button1_1.place(x=20, y=15, width=100, height=25)
            button1_2 = Checkbutton(group2, text=" 添加目录", variable=self.var['report']['content'],
                                    onvalue=True, offvalue=False, font=self.Text, state=state)
            button1_2.place(x=160, y=15, width=100, height=25)
            button1_3 = Checkbutton(group2, text=" 添加页眉", variable=self.var['report']['header'],
                                    onvalue=True, offvalue=False, font=self.Text, state=state)
            button1_3.place(x=300, y=15, width=100, height=25)
            button1_4 = Checkbutton(group2, text=" 添加页脚", variable=self.var['report']['footer'],
                                    onvalue=True, offvalue=False, font=self.Text, state=state)
            button1_4.place(x=440, y=15, width=100, height=25)
            water_information()
            button2_1 = Checkbutton(group2, text=" 添加水印", variable=self.var['report']['watermark'], onvalue=True,
                                    offvalue=False, font=self.Text, state=state, command=water_information)
            button2_1.place(x=20, y=55, width=100, height=25)
            pic_input()
            button3_1 = Checkbutton(group2, text=" 外部图片", variable=self.var['report']['outer'], onvalue=True,
                                    offvalue=False, font=self.Text, state=state, command=pic_input)
            button3_1.place(x=20, y=95, width=100, height=25)
            label4_1 = Label(group2, text='外部模块调用', font=self.Text, state=state)
            label4_1.place(x=14, y=135, width=140, height=25)
            button4_2 = Button(group2, text='自定义...', command=lambda: self.custom_function('report'),
                               font=self.Text, bd=0, fg='blue', state=state)
            button4_2.place(x=160, y=135, width=310, height=25)
            # 程序说明
            group3 = LabelFrame(framework, text="模块说明", labelanchor=N, font=self.Text)
            group3.place(x=10, y=445, width=570, height=80)
            label5_1 = Label(group3, text=self.var['report']['description'], font=self.Text, state=state)
            label5_1.place(x=10, y=5, width=550, height=50)

        frame = Frame(self.root)  # 2 创建选项卡1的容器框架
        notebook.add(frame, text='\n 报   表 \n')  # 3 装入框架1到选项卡1
        self.tab.update({'report': frame})  # 3 装入框架1到选项卡1
        if self.var['report']['state'].get():
            main(framework=frame, state='normal')
        else:
            main(framework=frame, state='disabled')
        Radiobutton(frame, text="启 用", variable=self.var['report']['state'],
                    command=lambda: main(framework=frame, state='normal'),
                    value=True, font=self.Text).place(x=50, y=15, width=60, height=25)
        Radiobutton(frame, text="禁 用", variable=self.var['report']['state'],
                    command=lambda: main(framework=frame, state='disabled'),
                    value=False, font=self.Text).place(x=270, y=15, width=60, height=25)
        self.bottom_button(frame)

    def model_backup_recovery(self, notebook):

        def backup_folder():
            name = f'backup TBM PreProcess {datetime.today().strftime("%Y-%m-%d")}.tar.gz'
            newDir = asksaveasfilename(initialfile=name, initialdir=self.current_path,
                                       title='选择文件', filetypes=[("压缩文件", ".tar.gz")]).replace('/', '\\')
            None if not newDir else self.var['backup-recovery']['backup'].set(newDir)

        def backup_event(framework):
            # noinspection PyBroadException
            try:
                if self.var['backup-recovery']['backup'].get() != '--未选择任何文件--':
                    with tarfile.open(self.var['backup-recovery']['backup'].get(), "w:") as tar:
                        tar.add(os.path.join(self.current_path, 'config', 'config.ini'), arcname='config.ini')
                    progress = Progressbar(framework, orient="horizontal", length=100, mode="determinate")
                    progress.place(x=28, y=500, width=530, height=10)
                    label = Label(framework, text='', font=('宋体', 9))
                    label.place(x=200, y=515, width=200, height=25)
                    progress['value'] = 0  # 设置初始值为50%
                    for value, key in zip(range(50, 101, 50), ['正在准备备份配置，请稍候...', '备份配置即将完成...']):
                        progress['value'] = value  # 设置初始值为50%
                        label.config(text=key)
                        self.root.update()
                        time.sleep(1)
                    label.place_forget()
                    progress.place_forget()
                    messagebox.showinfo(title='提示', message='备份配置完成！')  # 消息提醒弹
                else:
                    messagebox.showinfo(title='提示', message='未选择任何文件！')  # 消息提醒弹
            except Exception:
                messagebox.showwarning(title='警告', message='发生致命错误，备份配置失败！')  # 消息提醒弹

        def recovery_folder():
            newDir = askopenfilename(initialdir=self.current_path, title='选择文件',
                                     filetypes=[("压缩文件", ".tar.gz")]).replace('/', '\\')
            None if not newDir else self.var['backup-recovery']['recovery'].set(newDir)

        def recovery_event(framework):
            # noinspection PyBroadException
            try:
                if self.var['backup-recovery']['recovery'].get() != '--未选择任何文件--':
                    config_path = os.path.join(self.current_path, 'config')
                    tarfile.open(self.var['backup-recovery']['recovery'].get()).extractall(config_path)
                    progress = Progressbar(framework, orient="horizontal", length=100, mode="determinate")
                    progress.place(x=28, y=500, width=530, height=10)
                    label = Label(framework, text='', font=('宋体', 9))
                    label.place(x=200, y=515, width=200, height=25)
                    progress['value'] = 0  # 设置初始值为50%
                    for value, key in zip(range(50, 101, 50), ['正在准备还原配置，请稍候...', '还原配置即将完成...']):
                        progress['value'] = value  # 设置初始值为50%
                        label.config(text=key)
                        self.root.update()
                        time.sleep(1)
                    label.place_forget()
                    progress.place_forget()
                    self.get_config()
                    messagebox.showinfo(title='提示', message='还原配置成功！')  # 消息提醒弹
                    # 删除所有子元素
                    for widget in self.root.winfo_children():
                        widget.destroy()
                    self.main()
                else:
                    messagebox.showinfo(title='提示', message='未选择任何文件')  # 消息提醒弹
            except Exception:
                messagebox.showwarning(title='警告', message='发生致命错误，还原配置失败！')  # 消息提醒弹

        def reset_event(framework):
            # noinspection PyBroadException
            try:
                if messagebox.askyesno(title='提 示', message='将会清空所有设置，是否继续？'):
                    progress = Progressbar(framework, orient="horizontal", length=100, mode="determinate")
                    progress.place(x=28, y=500, width=530, height=10)
                    label = Label(framework, text='还原配置:', font=('宋体', 9))
                    label.place(x=200, y=515, width=200, height=25)
                    progress['value'] = 0  # 设置初始值为50%
                    for value, key in zip(range(25, 101, 25), ['正在准备重置，请稍候...', '正在进行重置，请勿关闭程序...',
                                                               '正在清理数据...', '重置即将完成...']):
                        progress['value'] = value  # 设置初始值为50%
                        label.config(text=key)
                        self.root.update()
                        time.sleep(1)
                    label.place_forget()
                    progress.place_forget()
                    self.default_var()
                    messagebox.showinfo(title='', message='程序重置完成，点击确定重启！')
                    # 删除所有子元素
                    for widget in self.root.winfo_children():
                        widget.destroy()
                    self.main()
            except Exception:
                messagebox.showwarning(title='警告', message='发生致命错误，程序重置失败！')  # 消息提醒弹

        def local_update_folder():
            newDir = askopenfilename(title='选择文件', filetypes=[("压缩文件", ".zip")]).replace('/', '\\')
            None if not newDir else self.var['backup-recovery']['update'].set(newDir)

        def local_update_event(framework):
            if self.var['backup-recovery']['update'].get() != '--未选择任何文件--':
                progress = Progressbar(framework, orient="horizontal", length=100, mode="determinate")
                progress.place(x=28, y=500, width=530, height=10)
                label = Label(framework, text='', font=('宋体', 9))
                label.place(x=200, y=515, width=200, height=25)
                temp_path = os.path.join(self.current_path, 'temp')
                memory_file = io.BytesIO()
                # noinspection PyBroadException
                try:
                    # 第一步
                    progress['value'] = 0  # 设置初始值为50%
                    label.config(text='正在解压数据，请勿关闭程序...')
                    self.root.update()
                    if not os.path.exists(temp_path):
                        os.mkdir(temp_path)  # 创建相关文件夹
                    zipfile.ZipFile(self.var['backup-recovery']['update'].get(), mode='r').extractall(temp_path)
                    shutil.copy(os.path.join(self.current_path, 'temp', 'Update.py'),
                                os.path.join(self.current_path, 'Programs', 'Update.py'))
                    progress['value'] = 30  # 设置初始值为50%
                    label.config(text='正在更新组件，请勿关闭程序...')
                    self.root.update()
                    time.sleep(1)
                    # 第二步
                    from Update import Update
                    progress['value'] = 70  # 设置初始值为50%
                    label.config(text='正在更新组件，请勿关闭程序...')
                    self.root.update()
                    time.sleep(1)
                    # 第三步
                    shutil.rmtree(temp_path)  # 清空文件夹
                    progress['value'] = 90  # 设置初始值为50%
                    label.config(text='正在清理冗余信息，请勿关闭程序...')
                    self.root.update()
                    time.sleep(1)
                    progress['value'] = 99  # 设置初始值为50%
                    label.config(text='更新即将完成，请勿关闭程序...')
                    self.root.update()
                    time.sleep(1)
                    progress['value'] = 100  # 设置初始值为50%
                    self.root.update()
                    label.place_forget()
                    progress.place_forget()
                    messagebox.showinfo(title='提示', message='更新程序成功，请重新启动程序！')  # 消息提醒弹
                    self.root.destroy()
                    sys.exit()
                except Exception:
                    label.place_forget()
                    progress.place_forget()
                    messagebox.showwarning(title='警告', message='更新文件非法，更新失败！')  # 消息提醒弹
                finally:
                    if os.path.exists(temp_path):
                        shutil.rmtree(temp_path)
                    if os.path.exists(os.path.join(self.current_path, 'Programs', 'Update.py')):
                        os.remove(os.path.join(self.current_path, 'Programs', 'Update.py'))
                    memory_file.close()
            else:
                messagebox.showwarning(title='警告', message='未选择更新文件！')  # 消息提醒弹

        def online_update_event(framework):
            """检查更新模块"""
            temp_path = os.path.join(self.current_path, 'temp')
            if not os.path.exists(temp_path):
                os.mkdir(temp_path)  # 创建相关文件夹
            progress = Progressbar(framework, orient="horizontal", length=100, mode="determinate")
            progress.place(x=28, y=500, width=530, height=10)
            label = Label(framework, text='', font=('宋体', 9))
            label.place(x=200, y=515, width=200, height=25)
            # noinspection PyBroadException
            try:
                # 第一步
                progress['value'] = 0  # 设置初始值为50%
                label.config(text='正在下载更新包，请勿关闭程序...')
                self.root.update()
                response = requests.get(self.update_url)
                with tempfile.TemporaryFile() as temp_file:
                    for index, data in enumerate(response.iter_content(1024)):
                        progress['value'] = int(index / 2) if (index / 2) <= 30 else 30  # 设置初始值为50%
                        self.root.update()
                        temp_file.write(data)
                    time.sleep(1)
                    # 第二步
                    progress['value'] = 30  # 设置初始值为50%
                    label.config(text='正在部署环境，请勿关闭程序......')
                    self.root.update()
                    ZF = zipfile.ZipFile(temp_file, mode='r')
                    zip_file_list = ZF.namelist()
                    for num, name in enumerate(zip_file_list):
                        ZF.extract(name, temp_path)  # 解压到zip目录文件下
                        progress['value'] = 30 + (60 - 30) / len(zip_file_list) * (num + 1)  # 设置初始值为50%
                        self.root.update()
                        time.sleep(0.5)
                    source_folder = os.path.join(temp_path, 'TBM-Intelligent-main')
                    for item_name in os.listdir(source_folder):
                        shutil.move(os.path.join(source_folder, item_name),
                                    os.path.join(temp_path, item_name))
                    shutil.rmtree(source_folder)
                    shutil.copy(os.path.join(self.current_path, 'temp', 'Update.py'),
                                os.path.join(self.current_path, 'Programs', 'Update.py'))
                    # 第三步
                    progress['value'] = 60  # 设置初始值为50%
                    label.config(text='正在校验更新包，请勿关闭程序...')
                    self.root.update()
                    time.sleep(1)
                    # 第四步
                    progress['value'] = 70  # 设置初始值为50%
                    label.config(text='正在更新组件，请勿关闭程序...')
                    self.root.update()
                    from Update import Update
                    time.sleep(1)
                    # 第五步
                    progress['value'] = 90  # 设置初始值为50%
                    label.config(text='正在清理冗余信息，请勿关闭程序...')
                    self.root.update()
                    shutil.rmtree(temp_path)  # 清空文件夹
                    time.sleep(1)
                    progress['value'] = 99  # 设置初始值为50%
                    label.config(text='更新即将完成，请勿关闭程序...')
                    self.root.update()
                    time.sleep(1)
                    progress['value'] = 100  # 设置初始值为50%
                    self.root.update()
                    label.place_forget()
                    progress.place_forget()
                    messagebox.showinfo(title='提示', message='更新程序成功，请重新启动程序！')  # 消息提醒弹
                    self.root.destroy()
                    sys.exit()
            except Exception:
                progress['value'] = 0  # 设置初始值为50%
                label.config(text='发生致命错误，更新失败！！！')
                self.root.update()
            finally:
                if os.path.exists(temp_path):
                    shutil.rmtree(temp_path)
                if os.path.exists(os.path.join(self.current_path, 'Programs', 'Update.py')):
                    os.remove(os.path.join(self.current_path, 'Programs', 'Update.py'))

        def main(framework):
            # 备份升级
            group1 = LabelFrame(framework, text="备份/恢复", labelanchor=N, font=self.Text)
            group1.place(x=10, y=15, width=570, height=190)
            # 备份配置
            label1_1 = Label(group1, text='备份配置:', font=self.Text)
            label1_1.place(x=15, y=15, width=75, height=25)
            entry1_2 = Entry(group1, textvariable=self.var['backup-recovery']['backup'], font=self.Text)
            entry1_2.place(x=95, y=15, width=375, height=25)
            button1_3 = Button(group1, text='选择路径', command=lambda: backup_folder(), font=self.Text)
            button1_3.place(x=480, y=15, width=70, height=25)
            button1_4 = Button(group1, text='生成备份', command=lambda: backup_event(framework=framework),
                               background="#24BDDC", foreground="white", font=self.Text, bd=1)
            button1_4.place(x=250, y=50, width=70, height=25)
            # 还原配置
            label2_1 = Label(group1, text='还原配置:', font=self.Text)
            label2_1.place(x=15, y=95, width=75, height=25)
            entry2_2 = Entry(group1, textvariable=self.var['backup-recovery']['recovery'], font=self.Text)
            entry2_2.place(x=95, y=95, width=375, height=25)
            button1_3 = Button(group1, text='选择文件', command=lambda: recovery_folder(), font=self.Text)
            button1_3.place(x=480, y=95, width=70, height=25)
            button1_4 = Button(group1, text='上传备份', command=lambda: recovery_event(framework=framework),
                               background="#24BDDC", foreground="white", font=self.Text, bd=1)
            button1_4.place(x=250, y=130, width=70, height=25)
            # 重置
            group2 = LabelFrame(framework, text="重  置", labelanchor=N, font=self.Text)
            group2.place(x=10, y=230, width=570, height=70)
            button2_1 = Button(group2, text='执行重置', command=lambda: reset_event(framework=framework),
                               background="#E0AD1E", foreground="white", font=self.Text, bd=1)
            button2_1.place(x=250, y=15, width=70, height=25)
            # 升级
            group3 = LabelFrame(framework, text="升  级", labelanchor=N, font=self.Text)
            group3.place(x=10, y=330, width=570, height=110)
            label3_1 = Label(group3, text='固件文件:', font=self.Text)
            label3_1.place(x=15, y=15, width=75, height=25)
            entry3_2 = Entry(group3, textvariable=self.var['backup-recovery']['update'], font=self.Text)
            entry3_2.place(x=95, y=15, width=375, height=25)
            button3_3 = Button(group3, text='选择路径', command=lambda: local_update_folder(), font=self.Text)
            button3_3.place(x=480, y=15, width=70, height=25)
            button3_4 = Button(group3, text='本地更新', command=lambda: local_update_event(framework=framework),
                               background="#24BDDC", foreground="white", font=self.Text, bd=1)
            button3_4.place(x=150, y=50, width=70, height=25)
            button3_5 = Button(group3, text='联网更新', command=lambda: online_update_event(framework=framework),
                               background="#24BDDC", foreground="white", font=self.Text, bd=1)
            button3_5.place(x=350, y=50, width=70, height=25)

        frame = Frame(self.root)  # 2 创建选项卡1的容器框架
        notebook.add(frame, text='\n备份/升级\n')  # 3 装入框架1到选项卡1
        self.tab.update({'update': frame})  # 3 装入框架1到选项卡1
        main(framework=frame)
        self.bottom_button(frame)


class Loading(object):

    def __init__(self):
        self.root = Tk()
        self.var = {'total-sum': 0, 'total-count': 0, 'detail-sum': 0, 'detail-count': 0,
                    'stop': False, 'pause': False, 'time-list': 0.0, 'time-temp': 0.0}
        self.time_start = time.time()
        self.label_cpu_use = Label(self.root, text='88%', font=('Arial', 18))
        self.label_ram_use = Label(self.root, text='88%', font=('Arial', 18))
        self.label_time_use = Label(self.root, text='88:88:88', font=('Arial', 18))
        self.total_progbar = ttk.Progressbar(self.root, orient='horizontal', length=400, mode='determinate')
        self.label_total = Label(self.root, text='总任务 (-/-)', font=('Arial', 11), anchor="nw", width=200)
        self.detail_progbar = ttk.Progressbar(self.root, orient='horizontal', length=400, mode='determinate')
        self.label_detail = Label(self.root, text='子任务 (-/-)', font=('Arial', 11), anchor="nw")
        self.label_time = Label(self.root, text='预计剩余时间: --', font=('Arial', 11), anchor="nw")
        self.button_pause = Button(self.root, text='暂 停', command=self.__pause__)
        self.button_cancel = Button(self.root, text='取 消', command=self.__cancel__)
        self.text_box = Text(self.root)

    def __update_base_information__(self):
        system_state = self.__get_system_information__()
        self.label_cpu_use.config(text=f'{int(system_state[0])}%')
        self.label_ram_use.config(text=f'{int(system_state[1])}%')
        self.label_time_use.config(text=system_state[2])
        self.var['time-list'] = system_state[3]

    def __update_total_progress__(self):
        if self.total_progbar['value'] <= 100:
            if self.var['total-sum'] != 0:
                self.total_progbar['value'] = self.var['total-count'] / self.var['total-sum'] * 100
                self.label_total.config(text=f"总任务 ({self.var['total-count']}/{self.var['total-sum']})", width=200)

    def __update_detail_progress__(self):
        if self.detail_progbar['value'] <= 100:
            if self.var['detail-sum'] != 0:
                self.detail_progbar['value'] = self.var['detail-count'] / self.var['detail-sum'] * 100
                self.label_detail.config(text=f"子任务 ({self.var['detail-count']}/{self.var['detail-sum']})", width=200)

    def __update_time_progress__(self):
        time_remain = ((self.var['time-list'] / (self.var['detail-count'] + 1)) *
                       (self.var['detail-sum'] + 1 - self.var['detail-count'])) * \
                      (self.var['total-sum'] + 1 - self.var['total-count'] + 1)
        if time_remain >= 3600:
            time_remain = f'{time_remain / 3600:.1f}小时'
        elif time_remain >= 60:
            time_remain = f'{time_remain / 60:.1f}分钟'
        else:
            time_remain = f'{int(time_remain)}秒'
        if self.var['pause']:
            self.label_time.config(text=f'暂停中', fg="red")
            self.button_pause.config(text=f'继续')
        else:
            self.label_time.config(text=f'预计剩余时间: {time_remain}', fg="black")
            self.button_pause.config(text=f'暂停')

    def __get_system_information__(self):
        cpu_use = psutil.cpu_percent()  # CPU占用
        mem_use = psutil.Process(os.getpid()).memory_percent()  # 内存占用
        time_use = time.time() - self.time_start
        hours = int(time_use // 3600)
        minutes = int((time_use % 3600) // 60)
        seconds = int(time_use % 60)
        time_use_str = f"{hours:02d}:{minutes:02d}:{seconds:02d}"
        return cpu_use, mem_use, time_use_str, time_use

    def __cancel__(self):
        self.var['stop'] = True
        self.root.quit()
        sys.exit()

    def __pause__(self):
        self.var['pause'] = False if self.var['pause'] else True
        self.__update_time_progress__()
        if self.var['pause']:
            self.var['time-temp'] = time.time()
        else:
            self.time_start += time.time() - self.var['time-temp']

    def __timer__(self):
        while not self.var['stop']:
            # noinspection PyBroadException
            try:
                if self.var['total-sum'] == 0 and self.var['detail-sum'] == 0:
                    self.show_info(key=f"未开启任何功能模块，程序即将退出！")
                while self.var['pause']:
                    time.sleep(1)
                self.__update_base_information__()
                self.__update_time_progress__()
                if (self.var['total-count'] >= self.var['total-sum']) and \
                        (self.var['detail-count'] >= self.var['detail-sum']):
                    system_state = self.__get_system_information__()
                    self.show_info(key=f"数据预处理完成，耗时 {(system_state[3] / 60):.1f} min！")
                time.sleep(1)
            except Exception:
                pass

    def update(self, key, value=0):
        if key == 'total-sum':
            self.var['total-sum'] = value
        elif key == 'total-count':
            self.var['total-count'] += 1
            if self.var['total-count'] <= self.var['total-sum']:
                self.var['detail-count'] = 0
            self.__update_total_progress__()
        elif key == 'detail-sum':
            self.var['detail-sum'] = value
        elif key == 'detail-count':
            self.var['detail-count'] += 1
            self.__update_detail_progress__()

    def get_pause(self):
        return self.var['pause']

    def show_info(self, key, type='info'):
        if type in ['info', 'warning', 'error']:
            if type == 'info':
                messagebox.showinfo("提 示", key)
            elif type == 'warning':
                messagebox.showwarning("警 告", key)
            elif type == 'error':
                messagebox.showerror("错 误", key)
            self.__cancel__()
        else:
            if type == 'message':
                self.text_box.delete('1.0', 'end')
                self.text_box.insert('end', key)

    def Windows(self):
        self.root.geometry('570x330+500+300')
        self.root.title('数据预处理')
        self.root.resizable(0, 0)  # 防止用户调整尺寸
        self.root.protocol("WM_DELETE_WINDOW", self.__cancel__)
        # 创建CPU画布
        label_cpu = Label(self.root, text='CPU', font=('Arial', 18))
        label_cpu.place(x=30, y=10, width=70, height=62)
        canvas = Canvas(self.root, width=100, height=50)
        canvas.place(x=90, y=10, width=100, height=100)
        canvas.create_rectangle(10, 10, 70, 50, outline='#7D7979', width=1)
        self.label_cpu_use = Label(self.root, text='88%', font=('Arial', 18))
        self.label_cpu_use.place(x=101, y=21, width=59, height=39)
        # 创建RAM画布
        label_ram = Label(self.root, text='RAM', font=('Arial', 18))
        label_ram.place(x=190, y=10, width=70, height=62)
        canvas = Canvas(self.root, width=100, height=50)
        canvas.place(x=250, y=10, width=100, height=100)
        canvas.create_rectangle(10, 10, 70, 50, outline='#7D7979', width=1)
        self.label_ram_use = Label(self.root, text='88%', font=('Arial', 18))
        self.label_ram_use.place(x=261, y=21, width=59, height=39)
        # 创建时间画布
        label_time = Label(self.root, text='Time', font=('Arial', 18))
        label_time.place(x=330, y=10, width=110, height=62)
        canvas = Canvas(self.root, width=180, height=50)
        canvas.place(x=410, y=10, width=180, height=100)
        canvas.create_rectangle(10, 10, 126, 50, outline='#7D7979', width=1)
        self.label_time_use = Label(self.root, text='88:88:88', font=('Arial', 18))
        self.label_time_use.place(x=421, y=21, width=115, height=39)
        # 创建整体进度条
        self.label_total = Label(self.root, text='总任务 (-/-)', font=('Arial', 11), anchor="nw", width=200)
        self.label_total.place(x=40, y=90, width=400, height=25, anchor="nw")
        self.total_progbar.place(x=40, y=120, width=485, height=25)
        # 创建细节进度条
        self.label_detail = Label(self.root, text='子任务 (-/-)', font=('Arial', 11), anchor="nw")
        self.label_detail.place(x=40, y=150, width=200, height=25, anchor="nw")
        self.detail_progbar.place(x=40, y=180, width=485, height=25)
        # 创建剩余时间
        self.label_time = Label(self.root, text='预计剩余时间: --', font=('Arial', 11), anchor="nw")
        self.label_time.place(x=40, y=220, width=250, height=25)
        # 创建暂停按钮
        self.button_pause.place(x=350, y=220, width=70, height=25)
        # 创建取消按钮
        self.button_cancel.place(x=455, y=220, width=70, height=25)
        # 创建消息显示框
        self.text_box = Text(self.root)
        self.text_box.place(x=40, y=260, width=485, height=50)
        # 进入消息循环
        self.root.mainloop()

    def run(self):
        threading.Thread(target=self.__timer__).start()


def run(models):
    for model in models:
        if model['run']:
            model['model'].main()


if __name__ == "__main__":
    print('-> \033[0;32mOperating System: %s  Current Program: %s\033[0m' % (sys.platform, os.path.basename(__file__)))
    CONF = MESSAGE().config  # 调用窗口获取输入输出路径及相关参数，完成对程序的配置
    total_mission = sum((model['state'] if isinstance(model, dict) else False) for model in CONF.values())
    loading = Loading()
    loading.update(key='total-sum', value=total_mission)
    loading.run()
    target_cycle = TBM_CYCLE(input_path=CONF['cycle']['input'], out_path=CONF['cycle']['output'],
                             index_path=CONF['index'], parameter=CONF['cycle']['parameter'],
                             division=CONF['cycle']['division-way'], interval_time=CONF['cycle']['interval-time'],
                             V_min=CONF['cycle']['velocity-min'], L_min=CONF['cycle']['length-min'],
                             debug=CONF['cycle']['debug'], custom_functions=CONF['cycle']['custom-function'],
                             loading=loading)
    target_extract = TBM_EXTRACT(input_path=CONF['extract']['input'], out_path=CONF['extract']['output'],
                                 index_path=CONF['index'], key_parm=CONF['extract']['parameter'],
                                 debug=CONF['extract']['debug'], custom_functions=CONF['extract']['custom-function'],
                                 loading=loading)
    target_class = TBM_CLASS(input_path=CONF['class']['input'], out_path=CONF['class']['output'],
                             index_path=CONF['index'], parameter=CONF['class']['parameter'],
                             project_type=CONF['class']['project'], L_min=CONF['class']['length-min'],
                             V_max=CONF['class']['velocity-max'], constant_time=CONF['class']['constant-time'],
                             missing_ratio=CONF['class']['missing_ratio'], debug=CONF['class']['debug'],
                             functions={'A1': CONF['class']['id-a1'], 'B1': CONF['class']['id-b1'],
                                        'B2': CONF['class']['id-b2'], 'C1': CONF['class']['id-c1'],
                                        'C2': CONF['class']['id-c2'], 'D1': CONF['class']['id-d1'],
                                        'E1': CONF['class']['id-e1']},
                             custom_functions=CONF['class']['custom-function'], loading=loading)
    target_clean = TBM_CLEAN(input_path=CONF['clean']['input'], out_path=CONF['clean']['output'],
                             index_path=CONF['index'], parameter=CONF['clean']['parameter'],
                             V_max=CONF['clean']['velocity-max'], debug=CONF['clean']['debug'],
                             functions={'A1': CONF['clean']['correct-a1'], 'B1': CONF['clean']['correct-b1'],
                                        'B2': CONF['clean']['correct-b2'], 'C1': CONF['clean']['correct-c1'],
                                        'C2': CONF['clean']['correct-c2'], 'D1': CONF['clean']['correct-d1'],
                                        'E1': CONF['clean']['correct-e1']},
                             custom_functions=CONF['clean']['custom-function'], loading=loading)
    target_merge = TBM_MERGE(input_path=CONF['merge']['input'], out_path=CONF['merge']['output'],
                             index_path=CONF['index'], parameter=CONF['merge']['parameter'],
                             debug=CONF['merge']['debug'], custom_functions=CONF['merge']['custom-function'],
                             loading=loading)
    target_split = TBM_SPLIT(input_path=CONF['split']['input'], out_path=CONF['split']['output'],
                             index_path=CONF['index'], parameter=CONF['split']['parameter'],
                             partition=CONF['split']['partition-method'], min_time=CONF['split']['time-min'],
                             debug=CONF['split']['debug'], custom_functions=CONF['split']['custom-function'],
                             loading=loading)
    target_filter = TBM_FILTER(input_path=CONF['filter']['input'], out_path=CONF['filter']['output'],
                               index_path=CONF['index'], parameter=CONF['filter']['parameter'],
                               debug=CONF['filter']['debug'], custom_functions=CONF['filter']['custom-function'],
                               loading=loading)
    target_plot = TBM_PLOT(input_path=CONF['plot']['input'], out_path=CONF['plot']['output'],
                           index_path=CONF['index'], parameter=CONF['plot']['parameter'],
                           height=CONF['plot']['height'], weight=CONF['plot']['weight'],
                           dpi=CONF['plot']['dpi'], Format=CONF['plot']['format'],
                           debug=CONF['plot']['debug'], custom_functions=CONF['plot']['custom-function'],
                           loading=loading)
    target_report = TBM_REPORT(input_path=CONF['report']['input'], out_path=CONF['report']['output'],
                               index_path=CONF['index'], parameter=CONF['report']['parameter'],
                               input_pic=CONF['report']['plot-path'], cover=CONF['report']['cover'],
                               content=CONF['report']['content'], header=CONF['report']['header'],
                               footer=CONF['report']['footer'], watermark=CONF['report']['watermark'],
                               pic_outer=CONF['report']['outer'], watermark_info=CONF['report']['watermark-info'],
                               debug=CONF['report']['debug'], custom_functions=CONF['report']['custom-function'],
                               loading=loading)
    params = [{'run': CONF['cycle']['state'], 'model': target_cycle},
              {'run': CONF['extract']['state'], 'model': target_extract},
              {'run': CONF['class']['state'], 'model': target_class},
              {'run': CONF['clean']['state'], 'model': target_clean},
              {'run': CONF['merge']['state'], 'model': target_merge},
              {'run': CONF['split']['state'], 'model': target_split},
              {'run': CONF['filter']['state'], 'model': target_filter},
              {'run': CONF['plot']['state'], 'model': target_plot},
              {'run': CONF['report']['state'], 'model': target_report}]
    threading.Thread(target=run, args=(params,)).start()
    loading.Windows()
