#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ************************************************************************
# * Software:  TBM Pre-process                                           *
# * Version:  1.0.7                                                      *
# * Date:  2024-06-24 22:27:58                                           *
# * Last  update: 2024-03-08 20:00:00                                    *
# * License:  LGPL v1.0                                                  *
# * Maintain  address:  https://pan.baidu.com/s/1WIr67y1pNQCgEyUnuj004w  *
# * Maintain  code:  STBM                                                *
# * Email: jgliu1001@163.com                                             *
# ************************************************************************

import math
import traceback
import copy
import datetime
import time
import os
import sys
import shutil
import numpy as np
import pandas as pd
import psutil
import scipy
import statsmodels.nonparametric.api as SMNP
from scipy import fft
from scipy import signal
from scipy.fftpack import fft
from functools import reduce
from numpy import ndarray
from pandas import Series, DataFrame


class TBM_SPLIT(object):
    """
    内部段分割模块，完成从循环段提取上升段稳定段和下降段的功能
    ****必选参数：原始数据存放路径（input_path），若不传入输入路径，程序则抛出异常并终止运行；
                生成数据保存路径（out_path），若不传入输出路径，程序则抛出异常并终止运行；
                索引文件保存路径（index_path），若不传入输出路径，程序则抛出异常并终止运行；
                关键参数名称（par_name），若不传入参数，程序则抛出异常并终止运行；
    ****可选参数：内部段划分方法（partition）， 统计平均值'Average'， 核密度估计'kernel density'；
                时间记录下限值（单位：s）（min_time），默认为200s；
                程序调试/修复选项（debug），默认为关闭状态；
                直接运行程序（Run）， 默认为开启状态；
    """
    global math, traceback, copy, datetime, time, os, sys, shutil, np, pd, psutil, scipy, SMNP, fft, signal, reduce, ndarray, Series, DataFrame
    if getattr(sys, 'frozen', False):
        ROOT_DIRECTORY = os.path.dirname(sys.executable)  # 获取可执行文件所在文件夹路径
    else:
        ROOT_DIRECTORY = os.path.dirname(os.path.abspath(sys.argv[0]))
    SUB_FOLDERS = {'空推段': 'Free running', '上升段': 'Loading', '稳定段': 'Boring',
                   '上升和稳定段': 'Loading and Boring', '循环段': 'Boring cycle'}  # 默认子文件夹
    PARAMETERS = ['桩号', '日期', '推进位移', '刀盘转速', '推进速度', '刀盘扭矩',
                  '总推力', '刀盘贯入度', '刀盘转速设定值', '推进速度设定值']  # 默认参数示例
    CUSTOM_FUNCTIONS = {'split': None}
    RAW_INDEX = pd.DataFrame()  # 保存原始索引数据
    NEW_INDEX = pd.DataFrame()  # 保存新的索引数据

    def __init__(self, input_path=None, out_path=None, index_path=None, parameter=None,
                 partition='Kernel Density', min_time=200, custom_functions=None,
                 debug=False, Run=False, loading=None):
        """初始化必要参量"""
        self.input = input_path  # 初始化输入路径
        self.out = out_path  # 初始化输出路径
        self.index = index_path  # 初始化索引文件路径
        self.parm = parameter  # 初始化程序处理过程中需要用到的参数
        """初始化可选参量"""
        self.partition = partition  # 内部段划分方法
        self.min_time = min_time  # 最小掘进时长(s)
        self.custom_functions = self.CUSTOM_FUNCTIONS if custom_functions is None else custom_functions  # 数据清理功能
        self.debug = debug  # 调试/修复程序
        self.loading = loading  # 进度条
        """初始化程序内部参量"""
        self.class_name = self.__class__.__name__  # 获取当前模块名称
        self.Time_val = []  # 初始化程序运行花费时间
        self.show_parm = True  # 将输入参数大音出来，便于进行核对
        None if not Run else self.main()  # 运行主程序

    def __create_split_Dir__(self) -> None:  # 规定返回值无类型限定/无返回值
        """如果是第一次生成，需要创建相关文件夹，如果文件夹存在，则清空"""
        if not os.path.exists(self.out):  # 若保存内部段分割后数据的文件夹不存在
            os.mkdir(self.out)  # 创建相关文件夹
        else:  # 若保存内部段分割后数据的文件夹存在
            shutil.rmtree(self.out)  # 清空文件夹
            os.mkdir(self.out)  # 创建相关文件夹
        for index, name in enumerate(list(self.SUB_FOLDERS.keys())):  # 创建子文件夹
            self.SUB_FOLDERS[name] = '%d-' % (index + 1) + self.SUB_FOLDERS[name]  # 子文件夹前面添加编号
            sub_folder_path = os.path.join(self.out, self.SUB_FOLDERS[name])  # 子文件夹路径
            if not os.path.exists(sub_folder_path):
                os.mkdir(sub_folder_path)  # 创建子文件夹

    def __check_parm__(self) -> None:  # 规定返回值无类型限定/无返回值
        """检查传入参数是否正常"""
        info = None
        try:
            if not self.input:  # 检查必要参数
                info = f'Error in x00602,\n' \
                       f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                       f'The input folder is not defined, Please check!!!'
            elif not self.out:  # 检查必要参数
                info = f'Error in x00603,\n' \
                       f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                       f'The output folder is not defined, Please check!!!'
            elif not self.index:  # 检查必要参数
                info = f'Error in x00604,\n' \
                       f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                       f'The index path is not defined, Please check!!!'
            elif not self.parm or self.parm == ['']:  # 检查必要参数
                info = f'Error in x00605,\n' \
                       f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                       f'The parameters is not defined, Please check!!!'
            elif len(self.parm) < len(self.PARAMETERS):  # 检查必要参数
                info = f'Error in x00606,\n' \
                       f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                       f'The number of parameters is insufficient, Please check!!!'
            elif not os.path.exists(self.input):  # 检查必要参数
                info = f'Error in x00607,\n' \
                       f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                       f'The input folder path does not exist, Please check!!!'
            elif len(os.listdir(self.input)) <= 0:
                info = f'Error in x00608,\n' \
                       f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                       f'No file is found in <{self.input}>, Please check!!!'
        except Exception as e:
            info = f'Error in x00600,\n' \
                   f'Module({self.class_name}) initialization failed, Detail error are as follows: \n{e}!!!'
        finally:
            if info is not None:
                if self.loading is not None:
                    self.loading.set_message(message=info, type='error')
                else:
                    print(f'-> {self.class_name} \033[0;31m{info}\033[0m')
                sys.exit()  # 抛出异常并终止程序

    def __check_index__(self, all_location: list) -> None:
        """
        判断数据中是否存在重复列名，若存在重复列名，则需要输入位置索引
        :param all_location: 原始数据的所有标签名称
        :return: 无
        """
        info = None
        try:
            if reduce(lambda x, y: x * y, [type(name) == str for name in self.parm]):  # 判断是否为标签类型索引(名称)
                all_location = [name.split('.')[0] for name in all_location]  # 获取原始数据的标签名称
                mark = max([all_location.count(now_name) for now_name in self.parm])  # 检查标签名称中是否重复
                index = [all_location.index(now_name) for now_name in self.parm]
                if mark > 1:  # 标签名称不重复
                    info = f'Error in x00609,\n' \
                           f'Module({self.class_name}) initialization failed, Detail error are as follows:\n' \
                           f'Label index(loc) is not available, Please enter location index(iloc),\n' \
                           f'Location index(iloc) may be {index}, You can verify that!!!'
                    if self.loading is not None:
                        self.loading.set_message(message=info, type='warning')
                    else:
                        print(f'-> {self.class_name}\033[0;31m{index}\033[0m')
                    sys.exit()
            if self.show_parm:  # 将输入参数打印出来，便于进行核对
                self.show_parm = False
                if self.loading is not None:
                    self.loading.set_message(message='-> %s 参数名称: %s' %
                                               (self.class_name, [all_location[i] for i in self.parm]), type='text')
                else:
                    print('-> %s \033[0;33m参数名称: %s \033[0m' %
                          (self.class_name, [all_location[i] for i in self.parm]))
        except Exception as e:
            info = f'Error in x00600,\n' \
                   f'Module({self.class_name}) initialization failed, Detail error are as follows: \n{e}!!!'
        finally:
            if info is not None:
                if self.loading is not None:
                    self.loading.set_message(message=info, type='error')
                else:
                    print(f'-> {self.class_name} \033[0;31m{info}\033[0m')
                sys.exit()  # 抛出异常并终止程序

    def __prepare_custom_function__(self, option='add') -> None:
        """准备自定义函数"""
        custom_function_temp = os.path.join(self.ROOT_DIRECTORY, 'custom')
        if option == 'add':
            info = None
            try:
                for key in self.custom_functions.keys():
                    if self.custom_functions[key] is not None:
                        if not os.path.exists(custom_function_temp):
                            os.mkdir(custom_function_temp)  # 创建相关文件夹
                        shutil.copyfile(str(self.custom_functions[key]),
                                        os.path.join(custom_function_temp, key + '.py'))
            except Exception as e:
                for key in self.custom_functions.keys():
                    self.custom_functions[key] = None
                info = f'Warning in x00610,\n' \
                       f'Description failed to initialize the custom module, Detail error are as follows: \n{e}!!!'
            finally:
                if info is not None:
                    if self.loading is not None:
                        self.loading.set_message(message=info, type='warning')
                    else:
                        print(f'-> {self.class_name} \033[0;33m{info}\033[0m')
        elif option == 'del':
            if os.path.exists(custom_function_temp):
                shutil.rmtree(custom_function_temp)  # 清空文件夹

    def __write_index__(self, info: dict) -> None:  # 规定_Num_为整型(int)，info为列表(list)，返回值返回值无类型限定
        """
        向索引文件写入数据
        :param info: 待写入的信息，其中至少含有{‘name’：‘’}，name为循环段名称
        :return: 无
        """
        # noinspection PyBroadException
        try:
            if self.debug:  # 若为调试模式，则不向索引文件写入内容
                return None
            if self.RAW_INDEX.empty:  # 索引文件行位置记录
                if os.path.isfile(self.index):
                    self.RAW_INDEX = pd.read_csv(self.index, index_col=0, encoding='gb2312')  # 读取索引文件
                    for name in list(info.keys())[1:]:  # 删除已经存在的与内部段划分有关的列
                        if name in list(self.RAW_INDEX):
                            self.RAW_INDEX = self.RAW_INDEX.drop(name, axis=1)
                    self.NEW_INDEX = pd.DataFrame(columns=list(info.keys())[1:])  # 保存新的索引数据
            local_Num = int(info['循环段'][:5])  # 当前文件编号
            while self.NEW_INDEX.shape[0] + 1 < local_Num:  # 对中间缺失数据用空值进行处理
                index_Num = self.NEW_INDEX.shape[0] + 1  # 索引记录编号
                self.NEW_INDEX.loc[index_Num] = ['' for _ in list(info.keys())[1:]]
            self.NEW_INDEX.loc[local_Num] = [info[name] for name in list(info.keys())[1:]]  # 新的索引文件记录
            after_index = pd.concat([self.RAW_INDEX, self.NEW_INDEX], axis=1)  # 合并
            after_index.to_csv(self.index, encoding='gb2312')  # 保存索引记录
        except Exception as e:
            if self.loading is not None:
                self.loading.set_message(message=f'-> {self.class_name} {e}', type='message')
            else:
                print(f'-> {self.class_name} \033[0;31m{e}\033[0m')

    def __segment_save__(self, data: DataFrame, _key_: dict) -> None:  # 规定_name_为字符型（str），_key_为字典类型（dict）
        """
        对已经分割好的循环段文件进行保存
        :param data: 循环段数据（DataFrame）
        :param _key_: 内部段划分信息， 示例：_key_：{‘name’：‘’，‘rise’：‘’，‘steadyS’：‘’，‘steadyE’：‘’}
        :return: 无
        """
        # noinspection PyBroadException
        try:
            if _key_['上升段起点'] != 'Unknown':
                save_path = os.path.join(self.out, self.SUB_FOLDERS['空推段'], _key_['循环段'])  # 数据保存路径
                select_data = data.iloc[:_key_['上升段起点'], :]
                select_data.to_csv(save_path, index=False, encoding='gb2312')  # 保存各阶段的数据
            if _key_['上升段起点'] != 'Unknown' and _key_['稳定段起点'] != 'Unknown':
                save_path = os.path.join(self.out, self.SUB_FOLDERS['上升段'], _key_['循环段'])  # 数据保存路径
                select_data = data.iloc[_key_['上升段起点']:_key_['稳定段起点'], :]
                select_data.to_csv(save_path, index=False, encoding='gb2312')  # 保存各阶段的数据
            if _key_['稳定段起点'] != 'Unknown' and _key_['稳定段终点'] != 'Unknown':
                save_path = os.path.join(self.out, self.SUB_FOLDERS['稳定段'], _key_['循环段'])  # 数据保存路径
                select_data = data.iloc[_key_['稳定段起点']:_key_['稳定段终点'], :]
                select_data.to_csv(save_path, index=False, encoding='gb2312')  # 保存各阶段的数据
            if _key_['上升段起点'] != 'Unknown' and _key_['稳定段终点'] != 'Unknown':
                save_path = os.path.join(self.out, self.SUB_FOLDERS['上升和稳定段'], _key_['循环段'])  # 数据保存路径
                select_data = data.iloc[_key_['上升段起点']:_key_['稳定段终点'], :]
                select_data.to_csv(save_path, index=False, encoding='gb2312')  # 保存各阶段的数据
            if True:
                save_path = os.path.join(self.out, self.SUB_FOLDERS['循环段'], _key_['循环段'])  # 数据保存路径
                select_data = data
                select_data.to_csv(save_path, index=False, encoding='gb2312')  # 保存各阶段的数据
        except Exception as e:
            if self.loading is not None:
                self.loading.set_message(message=f'-> {self.class_name} {e}', type='message')
            else:
                print(f'-> {self.class_name} \033[0;31m{e}\033[0m')

    def __get_RS_index_average__(self, data: dict) -> dict:
        """
        获取空推、上升、稳定、下降的关键点--(统计平均值)
        :param data: {'name'：循环段名称（str）, 'data'：循环段数据（DataFrame）}
        :return: {'上升段起点': 上升段起点位置索引, '稳定段起点': 稳定段起点位置索引, '稳定段终点': 稳定段终点位置索引}
        """
        # noinspection PyBroadException
        try:
            if data['data'].shape[0] < self.min_time:
                RS_index = {'上升段起点': 0, '稳定段起点': 0, '稳定段终点': 0}
                return RS_index
            T_mean = data['data'].iloc[:, self.parm[5]].mean()
            mid_start_value = min(data['data'].iloc[0:int(data['data'].shape[0] / 3), self.parm[9]])  # 找前1/3的v_set最小值
            mid_point_start = 0  # 中点位置索引
            while data['data'].iloc[mid_point_start, self.parm[9]] > mid_start_value:
                mid_point_start += 1
            V_set_mean = data['data'].iloc[mid_point_start:-1, self.parm[9]].mean()  # 第一次求均值，用于索引中点
            mid_point = mid_point_start
            while data['data'].iloc[mid_point, self.parm[9]] < V_set_mean:
                if mid_point > 0.7 * data['data'].shape[0]:
                    mid_point = int(data['data'].shape[0] * 0.2)
                else:
                    while data['data'].iloc[mid_point, self.parm[9]] < V_set_mean or \
                            data['data'].iloc[mid_point + 30, self.parm[9]] < V_set_mean:
                        mid_point += 1  # #############有修改
            steadyE = data['data'].shape[0] - 1  # 稳定段结束位置索引
            while data['data'].iloc[steadyE, self.parm[5]] <= T_mean:  # 判断稳定段结束点
                steadyE -= 1
            if mid_point and mid_point <= 0.7 * data['data'].shape[0]:
                rise = mid_point  # 上升段开始位置处索引
                while abs(data['data'].iloc[rise, self.parm[7]]) > 0 and rise > 10:  # 刀盘贯入度度索引（self.parm[7]） ########
                    rise -= 1
                steadyS = mid_point
                V_set_ = data['data'].iloc[mid_point_start:steadyE, self.parm[9]]  # #改改改改改改改改改改改改改改改
                if steadyS + 60 < steadyE:
                    while V_set_[steadyS] - V_set_.mean() <= 0 or \
                            (max(V_set_[steadyS:steadyS + 60]) - min(V_set_[steadyS:steadyS + 60]) >= 0.02 * V_set_[
                                steadyS]):
                        steadyS += 1
                if steadyE - steadyS > 300:
                    steady_V_set_mean = V_set_.iloc[steadyS:steadyS + 300].mean()
                    steady_V_set_mean = min(0.95 * steady_V_set_mean, steady_V_set_mean - 3)
                else:
                    steady_V_set_mean = V_set_.iloc[steadyS:steadyE].mean()
                    steady_V_set_mean = min(0.95 * steady_V_set_mean, steady_V_set_mean - 3)
                while V_set_.iloc[steadyS] < steady_V_set_mean:  # 稳定段开始位置处的均值是否大于整个稳定段推进速度均值
                    steadyS += 1
                RS_index = {'上升段起点': rise, '稳定段起点': steadyS, '稳定段终点': steadyE}
            else:
                RS_index = {'上升段起点': 0, '稳定段起点': 0, '稳定段终点': 0}
        except Exception:
            RS_index = {'上升段起点': 0, '稳定段起点': 0, '稳定段终点': 0}
        return RS_index

    def __get_RS_index_kernel__(self, data: dict) -> dict:
        """
        获取空推、上升、稳定、下降的关键点--(核密度估计)
        :param data: {'name'：循环段名称（str）, 'data'：循环段数据（DataFrame）}
        :return: {'上升段起点': 上升段起点位置索引, '稳定段起点': 稳定段起点位置索引, '稳定段终点': 稳定段终点位置索引}
        """

        def get_index(Data, ratio, Type='head'):
            raw_V, filter_V = copy.deepcopy(Data).values, scipy.signal.savgol_filter(Data, 19, 2)
            start, finish, Rise, Steady = 0, 0, 0, 0
            for row in range(3, len(raw_V) - 3):
                if max(raw_V[row - 3:row - 1]) <= 0.1 and raw_V[row] > 0.1:
                    Rise = start = row
                if raw_V[row] > 0.1 and max(raw_V[row + 1:row + 3]) <= 0.1 or row == len(raw_V) - 4:
                    Steady = finish = row
                if finish - start > ratio * len(raw_V) and finish - start >= 200:
                    kde = SMNP.KDEUnivariate(filter_V[Rise:Steady])  # 核密度估计
                    kde.fit(kernel='gau', bw="scott", fft=True, gridsize=200, cut=3)  # 核密度估计
                    new_KDE_mean_before = KDE_mean = float(kde.support[np.where(kde.density == np.max(kde.density))])
                    if Type == 'head':
                        while 0.8 * new_KDE_mean_before <= KDE_mean:
                            new_KDE_mean_before, Steady_before = KDE_mean, Steady
                            value = np.int64(filter_V > 0.95 * KDE_mean)
                            for i in range(Rise, len(value) - 50):
                                if filter_V[i] >= KDE_mean and sum(value[i:i + 50]) > 20 and 1.0 / 1.2 * max(
                                        filter_V[i:i + 50]) < KDE_mean < 1.0 / 0.8 * min(filter_V[i:i + 50]):
                                    Steady = i
                                    break
                            if Steady - Rise >= 200:
                                kde_new = SMNP.KDEUnivariate(filter_V[Rise:Steady])  # 核密度估计
                                kde_new.fit(kernel='gau', bw="scott", fft=True, gridsize=200, cut=3)  # 核密度估计
                                KDE_mean = float(kde_new.support[np.where(kde_new.density == np.max(kde_new.density))])
                            if Steady >= Steady_before or new_KDE_mean_before == KDE_mean:
                                break
                        return Rise, Steady
                    if Type == 'final':
                        for index, value in enumerate(filter_V[:Steady]):
                            if value >= 0.5 * KDE_mean:
                                return 0, index
            return 0, 0

        # noinspection PyBroadException
        try:
            rise, steadyS = get_index(data['data'].iloc[:, self.parm[4]], ratio=0.1, Type='head')
            _, steadyE = get_index(data['data'].iloc[::-1, self.parm[4]], ratio=0.05, Type='final')
            RS_index = {'上升段起点': rise, '稳定段起点': steadyS, '稳定段终点': data['data'].shape[0] - steadyE}
        except Exception:
            RS_index = {'上升段起点': 0, '稳定段起点': 0, '稳定段终点': 0}
        return RS_index

    def __custom_get_RS__(self, data: dict) -> dict:
        """自定义获取空推、上升、稳定、下降的关键点模块，若定义了相关功能，则优先运行此功能，若未定义相关功能，则运行默认模块
        :param data: {'name'：循环段名称（str）, 'data'：循环段数据（DataFrame）}
        :return: {'上升段起点': 上升段起点位置索引, '稳定段起点': 稳定段起点位置索引, '稳定段终点': 稳定段终点位置索引}
        """
        if self.custom_functions['split'] is not None:
            info = None
            try:
                from custom.split import function
                return function(data)
            except Exception as e:
                info = f'Warning in x00611,\n' \
                       f'Custom module call failed, default module will be used, Detail error are as follows: \n{e}!!!'
            finally:
                if info is not None:
                    if self.loading is not None:
                        self.loading.set_message(message=info, type='warning')
                    else:
                        print(f'-> {self.class_name} \033[0;33m{info}\033[0m')

    def __show_info__(self, use_time: float, file_num: int, file_sum: int) -> None:
        """
        实时输出程序运行状况
        :param use_time: 处理每个循环段数据花费的时间
        :param file_num: 当前的循环段编号
        :param file_sum: 总的循环段数量
        :return: 无
        """
        if self.debug:  # 若为调试模式，则不向索引文件写入内容
            return None
        cpu_percent = psutil.cpu_percent()  # CPU占用
        mem_percent = psutil.Process(os.getpid()).memory_percent()  # 内存占用
        self.Time_val.append(use_time)  # 对每个时间差进行保存，用于计算平均时间
        mean_time = sum(self.Time_val) / len(self.Time_val)  # 计算平均时间
        sum_time = round(sum(self.Time_val) / 3600, 3)  # 计算程序执行的总时间
        remain_time = round((mean_time * (file_sum - file_num - 1)) / 3600, 3)  # 预计剩余时间计算
        print('\r   [第%d个 / 共%d个]  ' % (file_num + 1, file_sum),
              '[所用时间%ds / 平均时间%ds]  ' % (int(use_time), int(mean_time)),
              '[CPU占用: %5.2f%% / 内存占用: %5.2f%%]  ' % (cpu_percent, mem_percent),
              '[累积运行时间: %6.3f小时 / 预计剩余时间: %6.3f小时]' % (sum_time, remain_time), end='')
        if file_num + 1 >= file_sum:
            print('\r-> %s \033[0;32mData_Split completed, which took %6.3f hours\033[0m' % (self.class_name, sum_time))

    @staticmethod  # 不强制要求传递参数
    def __detail__(name=None, data=None, key=None, Parm=None, debug=False):
        """展示程序细节信息"""
        if debug:
            Divide = []
            print("\033[0;33m{:·^100}\033[0m".format(name))
            for num, information in enumerate(key):
                if isinstance(information, int):
                    Divide.append(information)
                print('\033[0;33m%9s\033[0m' % information, end='')
            print('')
            x = [i for i in range(data.shape[0])]  # 'Time'
            plt.figure(figsize=(14, 7), dpi=120)  # 设置画布大小（10cm x 8cm）及分辨率（dpi=120）
            for parm, color in zip(Parm, ['b', 'g', 'r', 'y']):
                plt.plot(x, data.iloc[:, parm], label="%s" % list(data)[parm], color=color)
            plt.legend()
            plt.xlabel("时间/s", fontsize=15)
            for color, information in zip(['g', 'r', 'y', 'b'], Divide):
                if isinstance(information, int):
                    plt.axvline(x=int(information), c=color, ls="-.")
            plt.show()
            plt.close()
            print("\033[0;33m{:·^100}\033[0m".format(name))

    def main(self) -> None:  # 规定返回值无类型限定/无返回值
        """对数据进行整体和细部分割"""
        # noinspection PyBroadException
        try:
            self.__check_parm__()  # 检查参数是否正常
            self.__create_split_Dir__()  # 创建相关文件夹
            self.__prepare_custom_function__(option='add')  # 准备自定义函数
            all_file = os.listdir(self.input)  # 获取输入文件夹下的所有文件名，并将其保存
            self.loading.set_process(key='detail-sum', value=len(all_file)) if self.loading is not None else None
            self.loading.set_process(key='total-count', file='SPLIT') if self.loading is not None else None
            all_file.sort(key=lambda x: int(x[:5]))  # 对读取的文件列表进行重新排序
            for num, file in enumerate(all_file):  # 遍历每个文件
                while self.loading is not None and self.loading.get_state():
                    time.sleep(1)
                time_S = time.time()  # 记录程序执行开始时间
                local_csv_path = os.path.join(self.input, file)  # 当前数据文件路径
                try:  # 尝试采用编码'gb2312'读取数据
                    data = pd.read_csv(local_csv_path, encoding='gb2312')  # 读取循环段文件
                except UnicodeDecodeError:  # 尝试采用默认编码' UTF-8 '读取数据
                    data = pd.read_csv(local_csv_path)  # 读取循环段文件
                self.__check_index__(list(data))  # 检查参数是否重复
                rise_steady = self.__custom_get_RS__({'name': file, 'data': data})  # 调用自定义函数，获取空推、上升、稳定、下降的变化点
                if rise_steady is None:  # 优先调用自定义模块，若自定义模块未定义，则调用默认模块
                    if self.partition == 'Average':  # 使用统计平均值模块进行划分
                        rise_steady = self.__get_RS_index_average__({'name': file, 'data': data})  # 调用函数，获取空推、上升、稳定、下降的变化点
                    if self.partition == 'Kernel Density':  # 使用核密度估计模块进行划分
                        rise_steady = self.__get_RS_index_kernel__({'name': file, 'data': data})  # 调用函数，获取空推、上升、稳定、下降的变化点
                RS_Index = {'循环段': file, '上升段起点': 'Unknown', '稳定段起点': 'Unknown', '稳定段终点': 'Unknown'}
                if rise_steady['稳定段起点'] - rise_steady['上升段起点'] >= 30:
                    RS_Index['上升段起点'], RS_Index['稳定段起点'] = rise_steady['上升段起点'], rise_steady['稳定段起点']
                if rise_steady['稳定段终点'] - rise_steady['稳定段起点'] >= 50:
                    RS_Index['稳定段起点'], RS_Index['稳定段终点'] = rise_steady['稳定段起点'], rise_steady['稳定段终点']
                self.__segment_save__(data, RS_Index)  # 数据保存
                self.__write_index__(RS_Index)  # 索引文件中内容写入
                self.__detail__(name=file, data=data, debug=self.debug, Parm=[self.parm[4]],
                                key=['上升段起点:', RS_Index['上升段起点'], '稳定段起点:', RS_Index['稳定段起点'],
                                     '稳定段终点:', RS_Index['稳定段终点']])  # DEBUG
                time_F = time.time()  # 记录程序执行结束时间
                if self.loading is not None:
                    self.loading.set_process(key='detail-count', file=file)
                else:
                    self.__show_info__(use_time=time_F - time_S, file_num=num, file_sum=len(all_file))
        except Exception:
            if self.loading is not None:
                self.loading.set_message(message=traceback.format_exc(), type='error')
            else:
                print(f'-> {self.class_name} \033[0;31m{traceback.format_exc()}\033[0m')
        finally:
            self.__prepare_custom_function__(option='del')


if __name__ == "__main__":
    TBM_SPLIT(input_path=r'D:\17339902814\OneDrive\桌面\test\merge',
              out_path=r'D:\17339902814\OneDrive\桌面\test\split',
              index_path=r'D:\17339902814\OneDrive\桌面\test\index.csv',
              parameter=[0, 1, 23, 5, 7, 2, 8, 3, 4, 6, 1],
              partition='Average',
              Run=True)
