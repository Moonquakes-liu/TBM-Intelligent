# -*- coding: utf-8 -*-
from numpy import ndarray


def function(data: dict) -> ndarray:
    """
    巴特沃斯滤波器
    :param data: 循环段数据（DataFrame）
    :return: 滤波后的循环段数据（DataFrame）
    """
    print('custom-filteer')
    return None
