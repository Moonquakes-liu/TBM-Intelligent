# -*- coding: utf-8 -*-
from pandas import Series, DataFrame


def function(cycle: DataFrame) -> str:
    """判断数据类型是不是__C1_sine__ (循环段刀盘扭矩出现正弦波扭矩)
    :param cycle: 循环段数据（DataFrame）
    :return: 异常类型（'Normal'/'C1'）
    """
    print('custom-class-C1')
    return 'Normal'
