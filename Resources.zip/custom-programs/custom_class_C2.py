# -*- coding: utf-8 -*-
from pandas import Series, DataFrame


def function(cycle: DataFrame) -> str:
    """判断数据类型是不是__C2_shutdown__ (循环段内机器发生短暂停机)
    :param cycle: 循环段数据（DataFrame）
    :return: 异常类型（'Normal'/'C2'）
    """
    print('custom-class-C2')
    return 'Normal'
