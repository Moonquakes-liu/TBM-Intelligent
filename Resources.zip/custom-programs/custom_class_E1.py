# -*- coding: utf-8 -*-
from pandas import Series, DataFrame


def function(cycle: DataFrame) -> str:
    """判断数据类型是不是__E1_missing_ratio__ (循环段内数据缺失过多)
    :param cycle: 循环段数据（DataFrame）
    :return: 异常类型（'Normal'/'E'）"""
    print('custom-class-E1')
    return 'Normal'
