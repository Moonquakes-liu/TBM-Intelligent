# -*- coding: utf-8 -*-
from pandas import Series, DataFrame


def function(cycle: DataFrame) -> DataFrame:
    """判断数据类型是不是__D1_adjust_setting__ (循环段内多次调整推进速度设定值)
    :param cycle: 循环段数据（DataFrame）
    :return: 修正后循环段数据（DataFrame）
    """
    print('custom-clean-D1')
    return DataFrame()
