# -*- coding: utf-8 -*-
from pandas import Series, DataFrame


def function(cycle: DataFrame) -> str:
    """
    判断数据类型是不是__A1_premature__ (循环段掘进长度过短 L<0.3m)
    :param cycle: 循环段数据（DataFrame）
    :return: 异常类型（'Normal'/'A'）
    """
    print('custom-class-A1')
    return 'Normal'
