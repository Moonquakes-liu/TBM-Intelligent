# -*- coding: utf-8 -*-
from pandas import Series, DataFrame
from matplotlib import pyplot as plt, pyplot


def function(data: DataFrame, _key_: dict) -> pyplot:  # 规定_key_为字典类型（dict）,返回值为绘制好的plt
    """
    完成掘进参数的绘图
    :param data: 循环段数据（DataFrame）
    :param _key_: 内部段划分信息
    :return: 绘制好的图片
    """
    print('custom-plot')
    return None
