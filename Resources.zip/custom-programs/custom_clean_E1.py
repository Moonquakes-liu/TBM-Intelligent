# -*- coding: utf-8 -*-
from pandas import Series, DataFrame


def function(cycle: DataFrame) -> DataFrame:
    """
    判断数据类型是不是__E1_missing_ratio__ (循环段内数据缺失过多)
    :param cycle: 循环段数据（DataFrame）
    :return : 修正后循环段数据（DataFrame）
    """
    print('custom-clean-E1')
    return DataFrame()
