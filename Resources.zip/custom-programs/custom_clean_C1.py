# -*- coding: utf-8 -*-
from pandas import Series, DataFrame


def function(cycle: DataFrame) -> DataFrame:
    """判断数据类型是不是__C1_sine__ (循环段刀盘扭矩出现正弦波扭矩)
    :param cycle: 循环段数据（DataFrame）
    :return: 修正后循环段数据（DataFrame）
    """
    print('custom-clean-C1')
    return DataFrame()
