# -*- coding: utf-8 -*-
from pandas import Series, DataFrame


def function(cycle: DataFrame) -> DataFrame:
    """判断数据类型是不是__B2_constant__ (循环段数据传输异常 刀盘推力连续5s不发生变化)
    :param cycle: 循环段数据（DataFrame）
    :return: 修正后循环段数据（DataFrame）
    """
    print('custom-clean-B2')
    return DataFrame()
