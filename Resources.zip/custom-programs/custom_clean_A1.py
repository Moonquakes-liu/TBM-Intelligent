# -*- coding: utf-8 -*-
from pandas import Series, DataFrame


def function(cycle: DataFrame) -> DataFrame:
    """
    判断数据类型是不是__A1_premature__ (循环段掘进长度过短 L<0.3m)
    :param cycle: 循环段数据（DataFrame）
    :return: 修正后循环段数据（DataFrame）
    """
    print('custom-clean-A1')
    return DataFrame()
