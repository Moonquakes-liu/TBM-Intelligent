# -*- coding: utf-8 -*-
from pandas import Series, DataFrame


def function(cycle: DataFrame) -> DataFrame:
    """判断数据类型是不是__B1_markAndModify__ (循环段速度值超限 V>120mm/min)
    :param cycle: 循环段数据（DataFrame）
    :return: 修正后循环段数据（DataFrame）
    """
    print('custom-clean-B1')
    return DataFrame()
